import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../model/terms_model.dart';
import '../repo/terms_repo.dart';
import '../widget/helper.dart';
class SignupTerms extends StatefulWidget {
  const SignupTerms({super.key});

  @override
  State<SignupTerms> createState() => _SignupTermsState();
}

class _SignupTermsState extends State<SignupTerms> {
  Rx<TermsModel> dataTerms = TermsModel().obs;
  Rx<RxStatus> statusOfTerms = RxStatus.empty().obs;
  termsDataGet() {
    termsRepo().then((value) {
      log("response.body.....    ${value}");
      dataTerms.value = value;
      if (value.success == true) {
        statusOfTerms.value = RxStatus.success();
        //   showToast(value.message);
        print("1${value.message.toString()}");
      } else {
        showToast(value.message);
        print("2${value.message.toString()}");
        statusOfTerms.value = RxStatus.error();
      }
    });
  }

  void initState() {
    super.initState();
    termsDataGet();
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: Color(0xff75D051),
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: Icon(
            Icons.arrow_back_ios,
            color: Colors.white,
          ),
        ),
        title: Text(
          "Terms & Conditions",
          style: GoogleFonts.roboto(
              fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white),
        ),
      ),
      body: SafeArea(
        child: Obx(
              () {
            return statusOfTerms.value.isSuccess
                ? Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [

                    Html(
                      data:dataTerms.value.pagedata![0].content,
                      style: {'body':Style(color: Colors.black,fontSize: FontSize(14),fontWeight: FontWeight.w400,lineHeight: LineHeight(1.6),
                          fontFamily: GoogleFonts.roboto().fontFamily)},
                    ),

                  ],
                ),
              ),
            )
                : const Center(
              child: CircularProgressIndicator(),
            );
          },
        ),
      ),
    );
  }
}
