class NotificationModel {
  List<Announcements>? announcements;
  String? message;
  bool? success;
  int? page;
  int? limit;

  NotificationModel(
      {this.announcements, this.message, this.success, this.page, this.limit});

  NotificationModel.fromJson(Map<String, dynamic> json) {
    if (json['announcements'] != null) {
      announcements = <Announcements>[];
      json['announcements'].forEach((v) {
        announcements!.add(new Announcements.fromJson(v));
      });
    }
    message = json['message'];
    success = json['success'];
    page = json['page'];
    limit = json['limit'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.announcements != null) {
      data['announcements'] =
          this.announcements!.map((v) => v.toJson()).toList();
    }
    data['message'] = this.message;
    data['success'] = this.success;
    data['page'] = this.page;
    data['limit'] = this.limit;
    return data;
  }
}

class Announcements {
  String? sId;
  String? title;
  String? description;
  String? customLinks;
  String? createdAt;
  int? iV;

  Announcements(
      {this.sId,
        this.title,
        this.description,
        this.customLinks,
        this.createdAt,
        this.iV});

  Announcements.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    title = json['title'];
    description = json['description'];
    customLinks = json['customLinks'];
    createdAt = json['createdAt'];
    iV = json['__v'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['title'] = this.title;
    data['description'] = this.description;
    data['customLinks'] = this.customLinks;
    data['createdAt'] = this.createdAt;
    data['__v'] = this.iV;
    return data;
  }
}
