class TermsModel {
  List<Pagedata>? pagedata;
  String? message;
  bool? success;

  TermsModel({this.pagedata, this.message, this.success});

  TermsModel.fromJson(Map<String, dynamic> json) {
    if (json['pagedata'] != null) {
      pagedata = <Pagedata>[];
      json['pagedata'].forEach((v) {
        pagedata!.add(new Pagedata.fromJson(v));
      });
    }
    message = json['message'];
    success = json['success'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.pagedata != null) {
      data['pagedata'] = this.pagedata!.map((v) => v.toJson()).toList();
    }
    data['message'] = this.message;
    data['success'] = this.success;
    return data;
  }
}

class Pagedata {
  String? name;
  String? title;
  String? content;

  Pagedata({this.name, this.title, this.content});

  Pagedata.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    title = json['title'];
    content = json['content'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    data['title'] = this.title;
    data['content'] = this.content;
    return data;
  }
}
