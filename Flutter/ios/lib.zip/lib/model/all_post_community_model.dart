import 'package:get/get_rx/src/rx_types/rx_types.dart';

class ModelAllCommunity {
  List<Post>? post;
  String? message;
  bool? success;

  ModelAllCommunity({this.post, this.message, this.success});

  ModelAllCommunity.fromJson(Map<String, dynamic> json) {
    if (json['post'] != null) {
      post = <Post>[];
      json['post'].forEach((v) {
        post!.add(new Post.fromJson(v));
      });
    }
    message = json['message'];
    success = json['success'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.post != null) {
      data['post'] = this.post!.map((v) => v.toJson()).toList();
    }
    data['message'] = this.message;
    data['success'] = this.success;
    return data;
  }
}

class Post {
  String? sId;
  String? userId;
  String? name;
  String? caption;
  String? message;
  String? postimage;
  int? likeCount;
  List<Null>? likes;
  List<Null>? comments;
  String? createdAt;
  String? updatedAt;
  int? iV;
  RxBool? liked ;
  // bool  liked;
  String? profileImageUrl;
  String? title;


  Post(
      {this.sId,
        this.userId,
        this.name,
        this.caption,
        this.message,
        this.postimage,
        this.likeCount,
        this.likes,
        this.comments,
        this.createdAt,
        this.updatedAt,
        this.iV,
        this.liked,
        this.title,
       this. profileImageUrl

      });

  Post.fromJson(Map<String, dynamic> json) {
    sId = json['_id'];
    userId = json['userId'];
    name = json['name'];
    caption = json['caption'];
    message = json['message'];
    postimage = json['postimage'];
    likeCount = json['likeCount'];
    createdAt = json['createdAt'];
    updatedAt = json['updatedAt'];
    iV = json['__v'];
    // liked = json['liked'];
    liked = (json['liked'] != null && json['liked'] is bool) ? RxBool(json['liked']) : RxBool(false);
    title = json['title'];
    profileImageUrl = json['profileImageUrl'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['_id'] = this.sId;
    data['userId'] = this.userId;
    data['name'] = this.name;
    data['caption'] = this.caption;
    data['message'] = this.message;
    data['postimage'] = this.postimage;
    data['likeCount'] = this.likeCount;
    data['createdAt'] = this.createdAt;
    data['updatedAt'] = this.updatedAt;
    data['__v'] = this.iV;
    // data['liked'] = this.liked;
    data['liked'] = this.liked?.value;
    data['title'] = this.title;
    data['profileImageUrl'] = this.profileImageUrl;
    return data;
  }
}
