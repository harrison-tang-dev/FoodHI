class ModelBarcodeScanner {
  dynamic code;
  Product? product;
  dynamic status;
  dynamic statusVerbose;

  ModelBarcodeScanner(
      {this.code, this.product, this.status, this.statusVerbose});

  ModelBarcodeScanner.fromJson(Map<String, dynamic> json) {
    code = json['code'];
    product =
    json['product'] != null ? new Product.fromJson(json['product']) : null;
    status = json['status'];
    statusVerbose = json['status_verbose'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['code'] = this.code;
    if (this.product != null) {
      data['product'] = this.product!.toJson();
    }
    data['status'] = this.status;
    data['status_verbose'] = this.statusVerbose;
    return data;
  }
}

class Product {
  Nutriments? nutriments;
  NutriscoreData? nutriscoreData;
  dynamic nutritionGrades;
  dynamic productName;
  dynamic ecoscoreGrade;
  dynamic ecoscoreScore;

  Product(
      {this.nutriments,
        this.nutriscoreData,
        this.nutritionGrades,
        this.productName,
         this.ecoscoreGrade, this.ecoscoreScore,
      });


    Product.fromJson(Map<String, dynamic> json) {
      nutriments = json['nutriments'] != null ? new Nutriments.fromJson(json['nutriments']) : null;
      nutriscoreData = json['nutriscore_data'] != null ? new NutriscoreData.fromJson(json['nutriscore_data']) : null;
      nutritionGrades = json['nutrition_grades'];
      productName = json['product_name'];
      ecoscoreGrade = json['ecoscore_grade']; // Ensure this field exists in the API response
      ecoscoreScore = json['ecoscore_score'];// Cast tags to List<String>
    }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    if (this.nutriments != null) {
      data['nutriments'] = this.nutriments!.toJson();
    }
    if (this.nutriscoreData != null) {
      data['nutriscore_data'] = this.nutriscoreData!.toJson();
    }

    data['nutrition_grades'] = this.nutritionGrades;
    data['product_name'] = this.productName;

    data['ecoscore_grade'] = this.ecoscoreGrade;
    data['ecoscore_score'] = this.ecoscoreScore;
    return data;
  }
}


class Nutriments {
  dynamic carbohydrates;
  dynamic carbohydrates100g;
  dynamic carbohydratesUnit;
  dynamic carbohydratesValue;
  dynamic energy;
  dynamic energyKcal;
  dynamic energyKcal100g;
  dynamic energyKcalUnit;
  dynamic sugars;
  dynamic sugars100g;
  dynamic sugarsUnit;
  dynamic sugarsValue;
  dynamic sodium;
  dynamic sodium100g;
  String? sodiumUnit;
  dynamic sodiumValue;

  Nutriments(
      {this.carbohydrates,
        this.carbohydrates100g,
        this.carbohydratesUnit,
        this.carbohydratesValue,
        this.energy,
        this.energyKcal,
        this.energyKcal100g,
        this.energyKcalUnit,
        this.sugars,
        this.sugars100g,
        this.sugarsUnit,
        this.sugarsValue,
        this.sodium100g

      });

  Nutriments.fromJson(Map<String, dynamic> json) {
    carbohydrates = json['carbohydrates'];
    carbohydrates100g = json['carbohydrates_100g'];
    carbohydratesUnit = json['carbohydrates_unit'];
    carbohydratesValue = json['carbohydrates_value'];
    energy = json['energy'];
    energyKcal = json['energy-kcal'];
    energyKcal100g = json['energy-kcal_100g'];
    energyKcalUnit = json['energy-kcal_unit'];
    sugars = json['sugars'];
    sugars100g = json['sugars_100g'];
    sugarsUnit = json['sugars_unit'];
    sugarsValue = json['sugars_value'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['carbohydrates'] = this.carbohydrates;
    data['carbohydrates_100g'] = this.carbohydrates100g;
    data['carbohydrates_unit'] = this.carbohydratesUnit;
    data['carbohydrates_value'] = this.carbohydratesValue;
    data['energy'] = this.energy;
    data['energy-kcal'] = this.energyKcal;
    data['energy-kcal_100g'] = this.energyKcal100g;
    data['energy-kcal_unit'] = this.energyKcalUnit;
    data['sugars'] = this.sugars;
    data['sugars_100g'] = this.sugars100g;
    data['sugars_unit'] = this.sugarsUnit;
    data['sugars_value'] = this.sugarsValue;
    return data;
  }
}

class NutriscoreData {
  dynamic energy;
  dynamic energyPoints;
  dynamic energyValue;
  dynamic sugarsPoints;
  dynamic sugarsValue;

  NutriscoreData(
      {this.energy,
        this.energyPoints,
        this.energyValue,
        this.sugarsPoints,
        this.sugarsValue});

  NutriscoreData.fromJson(Map<String, dynamic> json) {
    energy = json['energy'];
    energyPoints = json['energy_points'];
    energyValue = json['energy_value'];
    sugarsPoints = json['sugars_points'];
    sugarsValue = json['sugars_value'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['energy'] = this.energy;
    data['energy_points'] = this.energyPoints;
    data['energy_value'] = this.energyValue;
    data['sugars_points'] = this.sugarsPoints;
    data['sugars_value'] = this.sugarsValue;
    return data;
  }
}
