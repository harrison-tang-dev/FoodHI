import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:Safeplate/widget/Api_url.dart';
import 'package:Safeplate/widget/helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import '../model/update_profile_model.dart';

Future<UpdateProfileModel> updateProfileRepo(
    {countrycode,
      image,
      name,email,phoneNumber,
     postcode, aboutme,weight,
      unit,
      ft,
      unit2,
      age,
      allergy,
      gender,health,
      other,

      required BuildContext context}) async {
  OverlayEntry loader = NewHelper.overlayLoader(context);
  Overlay.of(context).insert(loader);

  var map = <String, String>{};

  // map["file"]=image.toString();
  map["name"]=name.toString();
  map["countryCode"]=countrycode.toString();
  map["email"]=email.toString();
  map["phonenumber"]=phoneNumber.toString();
  map["postcode"]=postcode.toString();
  map["aboutme"]=aboutme.toString();
  map["Age"]=age.toString();
  map["gender"]=gender.toString();
  map["health_conditions"]=health.toString();
  map["weight"]=weight.toString();
  map["Unit"]=unit.toString();
  map["ft"]=ft.toString();
  map["Unit2"]=unit2.toString();
  map["allergies"]=allergy.toString();
  map["others"]=other.toString();

  File imagePath=image??File("");



  log("Login Data map$map");
 try {

   var request = http.MultipartRequest('PATCH', Uri.parse(ApiUrl.updateProfile));
   request.headers.addAll(await  getAuthHeader());
   request.fields.addAll(map);

   if (imagePath.path != "") {
     request.files.add(await multipartFile("file", imagePath));
   }

   log(request.fields.toString());
   log(request.files.toString());
   log(ApiUrl.updateProfile);

   final response = await request.send();
   NewHelper.hideLoader(loader);
   log(response.statusCode.toString());
   log(map.toString());
   log("file path:::${imagePath.toString()}");



   String recievedResponse = await response.stream.bytesToString();
   log(recievedResponse);
   if (response.statusCode == 200 || response.statusCode == 201) {
     NewHelper.hideLoader(loader);
     return UpdateProfileModel.fromJson(jsonDecode(recievedResponse));
   } else {
     NewHelper.hideLoader(loader);
     return UpdateProfileModel.fromJson(jsonDecode(recievedResponse));
   }

 }
  catch (e) {
    NewHelper.hideLoader(loader);
    print('eorror');
    throw Exception(e.toString());
  }
}

          ///Multipart File working for images///
Future<http.MultipartFile> multipartFile(String? fieldName, File file1) async {
  return http.MultipartFile(
    fieldName ?? 'file',
    http.ByteStream(Stream.castFrom(file1.openRead())),
    await file1.length(),
    filename: file1.path.split('/').last,
  );
}






/// image to add in function///
/*
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:Safeplate/widget/Api_url.dart';
import 'package:Safeplate/widget/helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../model/create_post_model.dart';
import '../model/login_model.dart';

Future<CreatePostCommunity> createCommunityRepo(
    {required image,required title,required name, required message, required caption, required BuildContext context}) async {
  OverlayEntry loader = NewHelper.overlayLoader(context);
  Overlay.of(context).insert(loader);

  var map = <String, String>{};
  // map['file'] = File(image);
  map['name'] = name;
  map['title'] = title;
  map['message'] = message;
  map['caption'] = caption;
  // http.MultipartFile.fromPath('file', images!.path ?? "");
  // map['file'] = http.MultipartFile.fromPath(images);
  // request.files.add(await http.MultipartFile.fromPath('file', _image!.path));
  File imagePath=image??File("");

  log("Create Community Data map$map");
  try {

    var request = http.MultipartRequest('POST', Uri.parse(ApiUrl.createCommunity));
    request.headers.addAll(await  getAuthHeader());
    request.fields.addAll(map);
    if (imagePath.path != "") {
      request.files.add(await multipartFile("file", imagePath));
    }

    log(request.fields.toString());
    log(request.files.toString());
    log(ApiUrl.updateProfile);

    final response = await request.send();
    NewHelper.hideLoader(loader);
    log(response.statusCode.toString());
    log(map.toString());
    log("file path:::${imagePath.toString()}");



    String recievedResponse = await response.stream.bytesToString();
    log(recievedResponse);
    if (response.statusCode == 200 || response.statusCode == 201) {
      NewHelper.hideLoader(loader);
      return CreatePostCommunity.fromJson(jsonDecode(recievedResponse));
    } else {
      NewHelper.hideLoader(loader);
      return CreatePostCommunity.fromJson(jsonDecode(recievedResponse));
    }


  }
  catch (e) {
    NewHelper.hideLoader(loader);
    print('eorror');
    throw Exception(e.toString());
  }
}
Future<http.MultipartFile> multipartFile(String? fieldName, File file1) async {
  return http.MultipartFile(
    fieldName ?? 'file',
    http.ByteStream(Stream.castFrom(file1.openRead())),
    await file1.length(),
    filename: file1.path.split('/').last,
  );
}

 */