import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:Safeplate/widget/Api_url.dart';
import 'package:Safeplate/widget/helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;

import '../model/family_member_edit_model.dart';

Future<FamilyMemberEditModel> familyMemberEditRepo(
    {email, name, image,countryCode,
      relationship, phonenumber,
      required BuildContext context}) async {
  OverlayEntry loader = NewHelper.overlayLoader(context);
  Overlay.of(context).insert(loader);

  var map = <String, String>{};
  map['email'] = email;
  map['name'] = name;
  map['relationship'] = relationship;
  map['phonenumber'] = phonenumber;
  map['countryCode'] = countryCode;

  File imagePath = image ?? File("");



  log("Login Data map$map");
  try {

    var request = http.MultipartRequest('PATCH', Uri.parse(ApiUrl.editFamilyMember));
    request.headers.addAll(await  getAuthHeader());
    request.fields.addAll(map);

    if (imagePath.path != "") {
      request.files.add(await multipartFile("file", imagePath));
    }

    log(request.fields.toString());
    log(request.files.toString());
    log(ApiUrl.editFamilyMember);

    final response = await request.send();
    NewHelper.hideLoader(loader);
    log(response.statusCode.toString());
    log(map.toString());
    log("file path:::${imagePath.toString()}");



    String recievedResponse = await response.stream.bytesToString();
    log(recievedResponse);
    if (response.statusCode == 200 || response.statusCode == 201) {
      NewHelper.hideLoader(loader);
      return FamilyMemberEditModel.fromJson(jsonDecode(recievedResponse));
    } else {
      NewHelper.hideLoader(loader);
      return FamilyMemberEditModel.fromJson(jsonDecode(recievedResponse));
    }

  }
  catch (e) {
    NewHelper.hideLoader(loader);
    print('eorror');
    throw Exception(e.toString());
  }
}




Future<http.MultipartFile> multipartFile(String? fieldName, File file1) async {
  return http.MultipartFile(
    fieldName ?? 'file',
    http.ByteStream(Stream.castFrom(file1.openRead())),
    await file1.length(),
    filename: file1.path.split('/').last,
  );
}
