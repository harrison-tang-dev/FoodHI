import 'dart:convert';
import 'package:Safeplate/widget/Api_url.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import '../model/common_model.dart';
import '../widget/helper.dart';

Future<CommonModel> deleteNotificationRepo(
    {required String id, required BuildContext context}) async {
  OverlayEntry loader = NewHelper.overlayLoader(context);
  Overlay.of(context).insert(loader);
  var map = <String, dynamic>{};
  map["announcementId"] = id;

  try {
    http.Response response = await http.delete(
      Uri.parse(ApiUrl.notificationGet),
      body: jsonEncode(map),
      headers: await getAuthHeader(),
    );

    if (response.statusCode == 200) {
      NewHelper.hideLoader(loader);
      print(jsonDecode(response.body));
      return CommonModel.fromJson(jsonDecode(response.body));
    } else {
      NewHelper.hideLoader(loader);
      print(jsonDecode(response.body));
      return CommonModel(
          message: jsonDecode(response.body)["message"], success: false);
    }
  } catch (e) {
    NewHelper.hideLoader(loader);
    return CommonModel(message: e.toString(), success: false);
  }
}
