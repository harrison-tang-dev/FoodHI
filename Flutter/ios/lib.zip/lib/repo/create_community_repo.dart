import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:Safeplate/widget/Api_url.dart';
import 'package:Safeplate/widget/helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import '../model/create_post_model.dart';
import '../model/login_model.dart';

Future<CreatePostCommunity> createCommunityRepo(
    {required image,
      required title,required name, required message, required caption, required BuildContext context}) async {
  OverlayEntry loader = NewHelper.overlayLoader(context);
  Overlay.of(context).insert(loader);

  var map = <String, String>{};
  map['name'] = name;
  map['title'] = title;
  map['message'] = message;
  map['caption'] = caption;

  File imagePath = image ?? File("");

  log("Create Community Data map$map");
  try {

    var request =
        http.MultipartRequest('POST', Uri.parse(ApiUrl.createCommunity));
    request.headers.addAll(await getAuthHeader());
    request.fields.addAll(map);

    if (imagePath.path != "") {
      request.files.add(await multipartFile("file", imagePath));
    }

    log(request.fields.toString());
    log(request.files.toString());

    final response = await request.send();
    NewHelper.hideLoader(loader);
    log(response.statusCode.toString());
    log(map.toString());
    log("file path:::${imagePath.toString()}");

    String recievedResponse = await response.stream.bytesToString();
    log(recievedResponse);
    if (response.statusCode == 200 ||
        response.statusCode == 201 ||
        response.statusCode == 400) {
      NewHelper.hideLoader(loader);

      return CreatePostCommunity.fromJson(jsonDecode(recievedResponse));
    } else if (response.statusCode == 422 ||
        response.statusCode == 401 ||
        response.statusCode == 409) {
      NewHelper.hideLoader(loader);
      showToast(CreatePostCommunity.fromJson(jsonDecode(recievedResponse))
          .message
          .toString());

      throw Exception(jsonDecode(recievedResponse));
    } else {
      print(
          "abc${CreatePostCommunity.fromJson(jsonDecode(recievedResponse)).message.toString()}");
      NewHelper.hideLoader(loader);
      throw Exception(jsonDecode(recievedResponse));
    }
  } catch (e) {
    throw Exception(e.toString());
  }
}


Future<http.MultipartFile> multipartFile(String? fieldName, File file1) async {
  return http.MultipartFile(
    fieldName ?? 'file',
    http.ByteStream(Stream.castFrom(file1.openRead())),
    await file1.length(),
    filename: file1.path.split('/').last,
  );
}