import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:Safeplate/widget/Api_url.dart';
import 'package:Safeplate/widget/helper.dart';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as http;
import '../model/addnew_family_model.dart';

Future<AddNewFamilyMemberModel> addFamilyMemberRepo(
    {countryCode,image,name, email, phonenumber, images,relationship, required BuildContext context}) async {
  OverlayEntry loader = NewHelper.overlayLoader(context);
  Overlay.of(context).insert(loader);

  var map = <String, String>{};
  map['name'] = name;
  map['email'] = email;
  map['phonenumber'] = phonenumber;
  map['relationship'] = relationship;
  map['countryCode'] = countryCode;

  File imagePath = image ?? File("");
  log("ADD Family Data map$map");
  try {

    var request =
    http.MultipartRequest('POST', Uri.parse(ApiUrl.addFamilyMember));
    request.headers.addAll(await getAuthHeader());
    request.fields.addAll(map);

    if (imagePath.path != "") {
      request.files.add(await multipartFile("file", imagePath));
    }

    log(request.fields.toString());
    log(request.files.toString());

    final response = await request.send();
    NewHelper.hideLoader(loader);
    log(response.statusCode.toString());
    log(map.toString());
    log("file path:::${imagePath.toString()}");

    String recievedResponse = await response.stream.bytesToString();
    log(recievedResponse);
    if (response.statusCode == 200 ||
        response.statusCode == 201 ||
        response.statusCode == 400) {
      NewHelper.hideLoader(loader);

      return AddNewFamilyMemberModel.fromJson(jsonDecode(recievedResponse));
    } else if (response.statusCode == 422 ||
        response.statusCode == 401 ||
        response.statusCode == 409) {
      NewHelper.hideLoader(loader);
      showToast(AddNewFamilyMemberModel.fromJson(jsonDecode(recievedResponse))
          .message
          .toString());

      throw Exception(jsonDecode(recievedResponse));
    } else {
      print(
          "abc${AddNewFamilyMemberModel.fromJson(jsonDecode(recievedResponse)).message.toString()}");
      NewHelper.hideLoader(loader);
      throw Exception(jsonDecode(recievedResponse));
    }
  } catch (e) {
    throw Exception(e.toString());
  }
}


Future<http.MultipartFile> multipartFile(String? fieldName, File file1) async {
  return http.MultipartFile(
    fieldName ?? 'file',
    http.ByteStream(Stream.castFrom(file1.openRead())),
    await file1.length(),
    filename: file1.path.split('/').last,
  );
}

