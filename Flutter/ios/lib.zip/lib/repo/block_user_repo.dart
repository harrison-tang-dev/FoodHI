import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:Safeplate/model/common_model.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../model/like_post_model.dart';
import '../widget/Api_url.dart';
import '../widget/helper.dart';

Future<CommonModel> blockUserRepo({required dynamic id}) async {


  var map = <String, dynamic>{};
  map['comment_user_id '] = id;
  print("object${id}");
  try {
    // var url =ApiUrl.blockUser ;
    http.Response response = await http.post(
        Uri.parse(ApiUrl.blockUser),
      body: jsonEncode(map),
      headers: await getAuthHeader(),
    );

    if (response.statusCode == 200) {
      log('Response Body: ${response.body}');
      return CommonModel.fromJson(jsonDecode(response.body));
    } else {
      throw Exception(response.body);
    }
  } catch (e) {
    throw Exception(e.toString());
  }
}
