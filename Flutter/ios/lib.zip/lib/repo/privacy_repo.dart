import 'package:http/http.dart' as http;
import 'dart:convert';
import '../model/terms_model.dart';
import '../widget/Api_url.dart';


Future<TermsModel> privacyRepo() async {

  try {
    http.Response response = await http.get(
      Uri.parse( ApiUrl.privacyPolicy),
      headers: await getAuthHeader(),
    );

    if (response.statusCode == 200) {
      print(jsonDecode(response.body));
      return TermsModel.fromJson(jsonDecode(response.body));
    } else {
      print(jsonDecode(response.body));
      return TermsModel(
          message: jsonDecode(response.body)["message"],
          success: false,
          pagedata: null);
    }
  } catch (e) {
    return TermsModel(message: e.toString(), success: false, pagedata: null);
  }
}