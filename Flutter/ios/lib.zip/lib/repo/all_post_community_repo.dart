import 'dart:developer';
import 'package:http/http.dart' as http;
import 'dart:convert';
import '../model/all_post_community_model.dart';
import '../widget/Api_url.dart';
Future<ModelAllCommunity> allPostRepo(
    _count, int pageSize
    ) async {
  var urls =ApiUrl.getAllPost;
  print("CCCCCCCCCCCCCCCCC${_count}");
  log("response. urls ...    $urls$_count");
  final response = await http.get(
    Uri.parse('$urls$_count'),
    headers: await getAuthHeader(),);
  log("response....    ${response.body}");
  if (response.statusCode == 200) {
    log("Help Center Repository...${response.body}");
    return ModelAllCommunity.fromJson(jsonDecode(response.body));
  } else {
    throw Exception(response.body);
  }

}
