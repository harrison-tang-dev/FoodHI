import 'dart:convert';
import '../model/notification_model.dart';
import '../widget/Api_url.dart';
import 'package:http/http.dart' as http;

Future<NotificationModel> notificationRepo() async {

  try {
    http.Response response = await http.get(
      Uri.parse(ApiUrl.notificationGet),
      headers: await getAuthHeader(),
    );

    if (response.statusCode == 200) {
      print(jsonDecode(response.body));
      return NotificationModel.fromJson(jsonDecode(response.body));
    } else {
      print(jsonDecode(response.body));
      return NotificationModel(
          message: jsonDecode(response.body)["message"],
          success: false,
          announcements: null);
    }
  } catch (e) {
    return NotificationModel(message: e.toString(), success: false, announcements: null);
  }
}