import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

import '../model/like_post_model.dart';
import '../widget/Api_url.dart';
import '../widget/helper.dart';

Future<LikePostModel> addToLike({required String productId}) async {


  var map = <String, dynamic>{};

  try {
    var url =ApiUrl.likePost ;
    http.Response response = await http.post(
      Uri.parse('$url$productId'),
      body: jsonEncode(map),
        headers: await getAuthHeader(),
    );

    if (response.statusCode == 200) {
      log('Response Body: ${response.body}');
      return LikePostModel.fromJson(jsonDecode(response.body));
    } else {
      throw Exception(response.body);
    }
  } catch (e) {
    throw Exception(e.toString());
  }
}
