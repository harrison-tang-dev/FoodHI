import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:Safeplate/repo/sign_up_repo.dart';
import 'package:Safeplate/resources/dimension.dart';
import 'package:Safeplate/screen/login_screen.dart';
import 'package:Safeplate/screen/signup_otp.dart';
import 'package:Safeplate/widget/custom_textfield.dart';
import 'package:Safeplate/widget/helper.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:form_field_validator/form_field_validator.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../signup_terms.dart';

import '../repo/social_login_apple.dart';
import '../repo/social_login_repo.dart';
import '../signup_terms.dart';
import 'BottomNavBar/bottomnavbar.dart';

class SignUpScreen extends StatefulWidget {
  const SignUpScreen({super.key});

  static var route = "/signUpScreen";

  @override
  State<SignUpScreen> createState() => _SignUpScreenState();
}

class _SignUpScreenState extends State<SignUpScreen> {
  final _formKey = GlobalKey<FormState>();
  bool showValidation = false;

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController passwordController = TextEditingController();
  TextEditingController confirmController = TextEditingController();
  String? countryCode;
  var obscureText1 = true;
  bool? _isValue = false;
  final RxStatus status = RxStatus.loading();

  final GoogleSignIn _googleSignIn = GoogleSignIn();

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    return Scaffold(
      extendBody: false,
      resizeToAvoidBottomInset: false,
      body: SafeArea(
        child: Stack(
          children: <Widget>[
            Container(
               height: 500.0, // Specify the height here
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage("assets/images/Login.png"),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            Positioned(
              child: Padding(
                padding: EdgeInsets.symmetric(
                    horizontal: AddSize.padding16, vertical: Get.height * 0.06),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(
                      "Sign Up",
                      style: GoogleFonts.roboto(
                          fontSize: 24,
                          fontWeight: FontWeight.w500,
                          color: const Color(0xff283841)),
                    ),
                    SizedBox(
                      height: AddSize.size16,
                    ),
                    // Text(
                    //   "Access the leading healthy eating APP today",
                    //   style: GoogleFonts.roboto(
                    //       height:1.5,
                    //       fontSize: 14,
                    //       fontWeight: FontWeight.w400,
                    //       color: const Color(0xff466148)),
                    // )
                  ],
                ),
              ),
            ),
            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                height: size.height * .74,
                // width: G,
                //  jnecdkjewfcnewk
                // height:Get.height*0.78,
                // height: 640,
                //   height: Get.height*0.7,
                padding: EdgeInsets.symmetric(
                    horizontal: AddSize.padding18, vertical: AddSize.size18),
                margin: EdgeInsets.only(top: AddSize.size30),
                decoration: const BoxDecoration(
                    color: Color(0xff75D051),
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(20),
                        topRight: Radius.circular(20))),
                child: SingleChildScrollView(
                  child: Form(
                    key: _formKey,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.only(left: 5),
                          child: Text(
                            "Name",
                            style: GoogleFonts.roboto(
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                              color: const Color(0xffFAFAFA),
                            ),
                          ),
                        ),

                        SizedBox(
                          height: AddSize.size12,
                        ),
                        CommonTextFieldWidget(
                          textInputAction: TextInputAction.next,
                          keyboardType: TextInputType.name,
                          hint: 'Enter Your Name',
                          controller: nameController,
                          validator: (value) {
                            if (value!.trim().isEmpty) {
                              return 'Name is required'.tr;
                            } else if (value.length >= 30) {
                              return 'Name cannot exceed 30 characters'.tr;
                            } else if (RegExp(
                                    r'(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])')
                                .hasMatch(value)) {
                              return 'Name is not accept in emoji'.tr;
                            }
                            return null;
                          },
                        ),
                        SizedBox(
                          height: AddSize.size20,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5),
                          child: Text(
                            "Email",
                            style: GoogleFonts.roboto(
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                              color: const Color(0xffFAFAFA),
                            ),
                          ),
                        ),

                        SizedBox(
                          height: AddSize.size12,
                        ),
                        CommonTextFieldWidget(
                          textInputAction: TextInputAction.next,
                          hint: 'Enter Your Email',
                          controller: emailController,
                          keyboardType: TextInputType.emailAddress,
                          validator: (value) {
                            if (value!.isEmpty ||
                                !RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
                                    .hasMatch(value)) {
                              return "Email is required";
                            } else {
                              return null;
                            }
                          },
                        ),
                        SizedBox(
                          height: AddSize.size20,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5),
                          child: Text(
                            "Phone Number (Optional)",
                            style: GoogleFonts.roboto(
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                              color: const Color(0xffFAFAFA),
                            ),
                          ),
                        ),

                        SizedBox(
                          height: AddSize.size12,
                        ),
                        IntlPhoneField(
                          decoration: InputDecoration(
                            // suffixStyle: TextStyle(color: Colors.white),
                            // labelStyle: TextStyle(color: Colors.white),
                            // hoverColor: Colors.white,
                            // iconColor: Colors.white,
                            prefixIconColor: Colors.black,
                            // suffixIconColor: Colors.white,



                            hintText: 'Enter Your Phone Number',
                            focusColor:
                            Color(0xff181818),
                            hintStyle: GoogleFonts.roboto(
                              color: Color(0xff181818),
                              // color: Colors.red,
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                            ),
                            filled: true,
                            fillColor: Colors.white,
                            contentPadding: const EdgeInsets.symmetric(
                                horizontal: 18, vertical: 18),
                            focusedBorder: OutlineInputBorder(
                              borderSide: const BorderSide(color: Colors.white),
                              borderRadius: BorderRadius.circular(10.0),
                            ),
                            enabledBorder: const OutlineInputBorder(
                                borderSide: BorderSide(color: Colors.white),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(10.0))),
                            border: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: Color(0xFFD8DCDD), width: 3.0),
                                borderRadius: BorderRadius.circular(15.0)),
                          ),
                          controller: phoneController,
                          onCountryChanged: (country) {
                            countryCode = country.code;
                            log("numbeeee${country.code}");
                          },
                          initialCountryCode: countryCode,
                          onChanged: (phone) {
                            log("45454545454545${phone.completeNumber}");

                            setState(() {});
                          },

                          validator: (value) {
                            if (value == null || value.number.isEmpty) {
                              return "Phone number is required";
                            } else if (value.number.length != 15) {
                              return 'Number must be exactly 15 digits';
                            }
                            return null;
                          },
                        ),

                        SizedBox(
                          height: AddSize.size20,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5),
                          child: Text(
                            "Password",
                            style: GoogleFonts.roboto(
                              fontSize: 15,
                              fontWeight: FontWeight.w500,
                              color: const Color(0xffFAFAFA),
                            ),
                          ),
                        ),

                        SizedBox(
                          height: AddSize.size12,
                        ),
                        CommonTextFieldWidget(
                          textInputAction: TextInputAction.next,
                          hint: 'Enter Your Password',
                          obscureText: obscureText1,
                          suffix: GestureDetector(
                              onTap: () {
                                setState(() {
                                  obscureText1 = !obscureText1;
                                });
                              },
                              child: obscureText1
                                  ? const Icon(
                                      Icons.visibility_off,
                                      color: Colors.grey,
                                    )
                                  : const Icon(
                                      Icons.visibility,
                                      color: Color(0xFF53B176),
                                    )),
                          controller: passwordController,
                          // validator: (value) {
                          //   if (value == null || value.number.isEmpty) {
                          //     return "Phone Number is required";
                          //   } else if (value.number.length != 15) {
                          //     return 'Number must be exactly 15 digits';
                          //   }
                          //   return null;
                          // },
                          validator: MultiValidator([
                            RequiredValidator(
                                errorText:
                                    'Password is required'),
                            MinLengthValidator(8,
                                errorText:
                                    'Password must be minimum 8 characters with \n1 Capital letter & 1 numerical.'),
                            PatternValidator(r'^(?=.*[A-Z])(?=.*\d).{8,}$',
                                // r"^[a-zA-Z]{8,10}$",
                                errorText:
                                    'Password must be minimum 8 characters with \n1 Capital letter & 1 numerical.')
                          ]),
                        ),
                        SizedBox(
                          height: AddSize.size10,
                        ),
                        Row(
                          children: [
                            Transform.scale(
                              scale: 1,
                              child: Checkbox(
                                  materialTapTargetSize:
                                      MaterialTapTargetSize.shrinkWrap,
                                  visualDensity: VisualDensity.compact,
                                  autofocus: true,
                                  side: BorderSide(
                                      color: showValidation == false
                                          ? const Color(0xffFBB742)
                                          : Colors.red,
                                      width: 2),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(5)),
                                  activeColor: const Color(0xffFBB742),
                                  value: _isValue,
                                  onChanged: (bool? value) {
                                    setState(() {


                                      _isValue = value;
                                    });
                                  }),
                            ), GestureDetector(
                              onTap: (){
                                Get.to(()=>SignupTerms());
                              },
                              child: Text("Terms And Conditions",
                                    style: GoogleFonts.roboto(
                                        color: Colors.white,
                                        fontSize: 14,
                                        fontWeight: FontWeight.w400)),
                            ),

                          ],
                        ),
                        SizedBox(
                          height: AddSize.size25,
                        ),
                        ElevatedButton(
                            onPressed: () async {
                              if (_formKey.currentState!.validate()) {
                                signRepo(
                                        countryCode: countryCode,
                                        name: nameController.text,
                                        password: passwordController.text,
                                        email: emailController.text,
                                        phonenumber: phoneController.text,
                                        termscondition: true,
                                        context: context)
                                    .then((value) {
                                  if (value.success == true) {
                                    print("data");
                                    // showToast(value.message);
                                    Get.to(SignupOtp(
                                        email:
                                            emailController.text.toString()));
                                    // Get.toNamed(SignupOtp.route, arguments: emailController.text);
                                    print(
                                        "emailController${emailController.text}");

                                    //  Get.toNamed(LoginScreen.route);
                                  } else {
                                    print("data>>>>>>>");
                                    showToast(value.message);
                                  }
                                });
                              }
                            },
                            style: ElevatedButton.styleFrom(
                              minimumSize:
                                  Size(AddSize.screenWidth, AddSize.size50),
                              backgroundColor: const Color(0xffFBB742),
                              elevation: 0,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12)),
                            ),
                            child: Text("Sign Up".toUpperCase(),
                                style: GoogleFonts.roboto(
                                    fontWeight: FontWeight.w700,
                                    color: Colors.white,
                                    letterSpacing: .5,
                                    fontSize: 20))),
                        SizedBox(height: AddSize.size40),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Expanded(
                              child: Divider(
                                thickness: 1,
                                color: Color(0xffF3F0EB),
                              ),
                            ),
                            SizedBox(
                              width: AddSize.size25,
                            ),
                            const Expanded(
                                child: Text("Or Login With",
                                    style: TextStyle(
                                        fontWeight: FontWeight.w400,
                                        color: Colors.white,
                                        fontSize: 14))),
                            const Expanded(
                              child: Divider(
                                thickness: 1,
                                color: Color(0xffF3F0EB),
                              ),
                            ),
                          ],
                        ),
                        SizedBox(height: AddSize.size40),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            GestureDetector(
                              onTap: () {
                                signInWithGoogle();
                              },
                              child: Container(
                                padding: EdgeInsets.symmetric(
                                    horizontal: 32,
                                    vertical: AddSize.padding12),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Center(
                                  child: Image(
                                      image: const AssetImage(
                                          "assets/icons/google.png")),
                                ),
                              ),
                            ),
                            SizedBox(
                              width: 30,
                            ),
                            Platform.isIOS
                                ? GestureDetector(
                                    onTap: () {
                                      loginWithApple();
                                    },
                                    child: Container(
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 30,
                                          vertical: AddSize.padding10),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      child: Center(
                                        child: Image(
                                            image: const AssetImage(
                                                "assets/icons/apple.png")),
                                      ),
                                    ),
                                  )
                                : const SizedBox()
                          ],
                        ),
                        SizedBox(
                          height: AddSize.size50,
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            RichText(
                              overflow: TextOverflow.clip,
                              textAlign: TextAlign.end,
                              textDirection: TextDirection.rtl,
                              softWrap: true,
                              maxLines: 1,
                              textScaleFactor: 1,
                              text: TextSpan(
                                text: 'Already have an account? ',
                                style: GoogleFonts.roboto(
                                    fontWeight: FontWeight.w400, fontSize: 18),
                                children: <TextSpan>[
                                  TextSpan(
                                    text: 'Login',
                                    style: GoogleFonts.roboto(
                                        fontWeight: FontWeight.w400,
                                        color: const Color(0xffFBB742),
                                        fontSize: 18),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () {
                                        // Handle the navigation
                                        Get.toNamed(LoginScreen.route);
                                      },
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                        // SizedBox(
                        //   height: AddSize.size30,
                        // ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  signInWithGoogle() async {
    await GoogleSignIn().signOut();
    final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
    final GoogleSignInAuthentication googleAuth =
        await googleUser!.authentication;
    final credential = GoogleAuthProvider.credential(
      idToken: googleAuth.idToken,
      accessToken: googleAuth.accessToken,
    );
    await FirebaseAuth.instance.signInWithCredential(credential).then((value) {
      socialRepo(token: value.credential!.accessToken!, context: context)
          .then((value) async {
        if (value.success == true) {
          SharedPreferences pref = await SharedPreferences.getInstance();
          pref.setString("cookie", jsonEncode(value.accessToken));
          pref.setString("email", jsonEncode(value.data!.email));
          pref.setString("name", jsonEncode(value.data!.name));
          pref.setString("refreshToken", jsonEncode(value.refreshtoken));
          showToast(value.message);
          Get.offAllNamed(
            BottomNavbar.route,
          );
        } else {
          showToast(value.message);
        }
      });
    });
  }

  //
  loginWithApple() async {
    try {
      final appleProvider =
          AppleAuthProvider().addScope("email").addScope("FullName");
      await FirebaseAuth.instance
          .signInWithProvider(appleProvider)
          .then((value) async {
        log("access token${value.credential!.accessToken}");
        socialRepoLogin(token: value.credential!.accessToken, context: context)
            .then((value1) async {
          if (value1.success == true) {
            SharedPreferences pref = await SharedPreferences.getInstance();
            pref.setString('cookie', jsonEncode(value1.accessToken));
            pref.setString('email', jsonEncode(value1.data!.email));
            pref.setString('name', jsonEncode(value1.data!.name));
            pref.setString('refreshToken', jsonEncode(value1.refreshtoken));
            showToast(value1.message);
            Get.offAllNamed(
              BottomNavbar.route,
            );
          } else {
            showToast(value1.message);
          }
        });
      });
    } catch (e) {
      print("object${e}");
    }
  }
}
