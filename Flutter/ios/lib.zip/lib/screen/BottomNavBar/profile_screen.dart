import 'dart:developer';
import 'dart:io';
import 'package:Safeplate/resources/dimension.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:Safeplate/widget/custom_textfield.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:multi_select_flutter/dialog/multi_select_dialog_field.dart';
import 'package:multi_select_flutter/multi_select_flutter.dart';
import '../../controller/profile_controller.dart';
import '../../repo/update_profile_repo.dart';
import '../../widget/helper.dart';
import 'bottomnavbar.dart';

List<dynamic>? cropTypesdropdownvalue;

class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});
  static var route = "/profileScreen";

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _formKey1 = GlobalKey<FormState>();
  final profileController = Get.put(ProfileController());

  File? _image;
  final ImagePicker _picker = ImagePicker();

  var tempValues;



  Future<void> _pickImageFromGallery() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    } else {
      log('No image selected.');
    }
  }

  Future<void> _pickImageFromCamera() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    } else {
      log('No image selected.');
    }
  }
  final TextEditingController _otherController = TextEditingController();
  final Map<String, bool> selectedAllergies = {};

  @override
  void initState() {
    profileController.getProfile();
    super.initState();
  }


  @override
  void dispose() {
    _otherController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        Get.offAllNamed(BottomNavbar.route);
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          toolbarHeight: 80,
          titleSpacing: 0,
          elevation: 0,
          backgroundColor: const Color(0xff75D051),
          leading: IconButton(
            onPressed: () {
              Get.offAllNamed(BottomNavbar.route);
              // Get.back();
            },
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
          ),
          title: Text(
            "My Profile",
            style: GoogleFonts.roboto(
                fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white),
          ),
        ),
        body: Obx(() {
          return profileController.statusOfProfile.value.isSuccess
              ? Form(
                  key: _formKey1,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                        vertical: 20, horizontal: 20),
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Stack(
                                children: [
                                  Container(
                                      height: AddSize.size30 * 3,
                                      width: AddSize.size30 * 3,
                                      clipBehavior: Clip.antiAlias,
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(70),
                                      ),
                                      child: profileController.image == null ||
                                              profileController.image == ''
                                          ? Image.asset(
                                              "assets/icons/addimage.png",
                                              fit: BoxFit.cover,
                                            )
                                          : _image == null
                                              ? Image.network(
                                                  "${profileController.image}",
                                                  fit: BoxFit.cover,
                                                )
                                              : Image.file(
                                                  _image!,
                                                  fit: BoxFit.cover,
                                                )
                                      ),
                                  Positioned(
                                      right: 0,
                                      top: 5,
                                      child: Container(
                                        height: 30,
                                        width: AddSize.size30,
                                        decoration: BoxDecoration(
                                            // image:  _image == null
                                            //        ? Image.asset("assets/icons/addimage.png",fit: BoxFit.cover,)
                                            //        : Image.file(_image!,fit: BoxFit.cover,),
                                            border:
                                                Border.all(color: Colors.white),
                                            color: Colors.black,
                                            borderRadius:
                                                BorderRadius.circular(50)),
                                        child: Center(
                                          child: GestureDetector(
                                            onTap: () {
                                              showDialog(
                                                context: context,
                                                builder:
                                                    (BuildContext context) {
                                                  return Dialog(
                                                    elevation: 0,
                                                    shape:
                                                        RoundedRectangleBorder(
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              12),
                                                    ),
                                                    child: Padding(
                                                      padding: const EdgeInsets
                                                          .symmetric(
                                                          horizontal: 26,
                                                          vertical: 18),
                                                      child: Column(
                                                        crossAxisAlignment:
                                                            CrossAxisAlignment
                                                                .start,
                                                        mainAxisSize:
                                                            MainAxisSize.min,
                                                        children: <Widget>[
                                                          Text(
                                                            "Choose Any One:",
                                                            style: GoogleFonts
                                                                .roboto(
                                                                    fontSize:
                                                                        16,
                                                                    fontWeight:
                                                                        FontWeight
                                                                            .w500,
                                                                    color: Colors
                                                                        .black),
                                                          ),
                                                          SizedBox(
                                                            height: Get.height *
                                                                0.04,
                                                          ),
                                                          Padding(
                                                            padding:
                                                                const EdgeInsets
                                                                    .symmetric(
                                                                    horizontal:
                                                                        16),
                                                            child: Row(
                                                              mainAxisAlignment:
                                                                  MainAxisAlignment
                                                                      .spaceBetween,
                                                              children: [
                                                                InkWell(
                                                                  onTap: () {
                                                                    _pickImageFromCamera();
                                                                    Get.back();
                                                                  },
                                                                  child: Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .center,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .center,
                                                                    children: [
                                                                      // Icon(Icons.camera_rear),
                                                                      Image
                                                                          .asset(
                                                                        "assets/icons/camera.png",
                                                                        height:
                                                                            24,
                                                                        width:
                                                                            24,
                                                                      ),
                                                                      Text(
                                                                        "Camera",
                                                                        style: GoogleFonts.roboto(
                                                                            fontSize:
                                                                                15,
                                                                            fontWeight:
                                                                                FontWeight.w400,
                                                                            color: Colors.black),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                ),
                                                                InkWell(
                                                                  onTap: () {
                                                                    _pickImageFromGallery();
                                                                    Get.back();
                                                                  },
                                                                  child: Column(
                                                                    crossAxisAlignment:
                                                                        CrossAxisAlignment
                                                                            .center,
                                                                    mainAxisAlignment:
                                                                        MainAxisAlignment
                                                                            .center,
                                                                    children: [
                                                                      Image
                                                                          .asset(
                                                                        "assets/icons/gallery.png",
                                                                        height:
                                                                            24,
                                                                        width:
                                                                            24,
                                                                      ),
                                                                      Text(
                                                                        "Gallery",
                                                                        style: GoogleFonts.roboto(
                                                                            fontSize:
                                                                                15,
                                                                            fontWeight:
                                                                                FontWeight.w400,
                                                                            color: Colors.black),
                                                                      ),
                                                                    ],
                                                                  ),
                                                                )
                                                              ],
                                                            ),
                                                          ),
                                                          SizedBox(
                                                            height: Get.height *
                                                                0.04,
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  );
                                                },
                                              );
                                            },
                                            child: const Icon(
                                              Icons.edit_outlined,
                                              color: Colors.white,
                                              size: 20,
                                            ),
                                          ),
                                        ),
                                      )),
                                ],
                              ),
                              const SizedBox(
                                width: 30,
                              ),
                              Text(
                                profileController.nameController.text
                                    .toString(),
                                style: GoogleFonts.roboto(
                                    fontSize: 20, fontWeight: FontWeight.w600),
                              )
                            ],
                          ),
                          const SizedBox(
                            height: 30,
                          ),
                          Text(
                            "Name",
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.w500, fontSize: 15),
                          ),
                          const SizedBox(
                            height: 12,
                          ),
                          EditProfileTextFieldWidget(
                            hint: "Enter Your Name",
                            controller: profileController.nameController,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Name is required";
                              } else {
                                return null;
                              }
                            },
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          Text(
                            "Email",
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.w500, fontSize: 15),
                          ),
                          const SizedBox(
                            height: 12,
                          ),
                          EditProfileTextFieldWidget(
                            hint: "Enter Your Email",
                            controller: profileController.emailController,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Email is required";
                              } else {
                                return null;
                              }
                            },
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          Text(
                            "Phone Number (Optional)",
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.w500, fontSize: 15),
                          ),
                          const SizedBox(
                            height: 12,
                          ),
                          IntlPhoneField(
                            decoration: InputDecoration(
                              hintText: 'Enter Your Phone Number',
                              focusColor: Colors.black,
                              hintStyle: const TextStyle(
                                  height: 1.5,
                                  color: Color(0xff181818),
                                  fontSize: 14,
                                  fontWeight: FontWeight.w400),
                              // labelText: label,
                              // labelStyle: TextStyle(color:Colors.black, fontSize: AddSize.font14),
                              filled: true,
                              fillColor: Colors.transparent,
                              contentPadding: const EdgeInsets.symmetric(
                                  horizontal: 20, vertical: 20),
                              // .copyWith(top: maxLines! > 4 ? AddSize.size18 : 0),

                              focusedBorder: OutlineInputBorder(
                                borderSide:
                                    const BorderSide(color: Color(0xffAFAFAF)),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              enabledBorder: const OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Color(0xffAFAFAF)),
                                  borderRadius:
                                      BorderRadius.all(Radius.circular(10))),
                              border: OutlineInputBorder(
                                  borderSide: const BorderSide(
                                      color: Color(0xffAFAFAF), width: 3.0),
                                  borderRadius: BorderRadius.circular(10)),
                              // suffixIcon: suffix,
                              // prefixIcon: prefix
                            ),
                            controller: profileController.phoneNumberController,
                            onCountryChanged: (country) {
                              profileController.countryCountry = country.code;

                              log("numbeeee${country.code}");
                            },
                            initialCountryCode:
                                profileController.countryCountry,

                            // Default to India
                            onChanged: (phone) {
                              // Handle phone number changes
                              log("45454545454545${phone.completeNumber}");

                              setState(() {}); // +91 1234567890
                            },
                            // validator: (value) {
                            //   if (value == null || value.number.isEmpty) {
                            //     return "Phone Number is required";
                            //   } else if (value.number.length != 15) {
                            //     return 'Number must be exactly 15 digits';
                            //   }
                            //   return null;
                            // },
                          ),
                          const SizedBox(
                            height: 10,
                          ),
                          Text(
                            "Post Code",
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.w500, fontSize: 15),
                          ),
                          const SizedBox(
                            height: 12,
                          ),
                          EditProfileTextFieldWidget(
                            hint: "Enter Post Code",
                            controller: profileController.postcodeController,
                            validator: (value) {
                              if (value!.isEmpty
                                  // || RegExp(r'^(?:\+?88|0088)?01[13-9]\d{8}$').hasMatch(value)
                                  ) {
                                return "Post Code is required";
                              }
                              return null;
                            },
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          Text(
                            "About Me",
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.w500, fontSize: 15),
                          ),
                          const SizedBox(
                            height: 12,
                          ),
                          EditProfileTextFieldWidget(
                            maxLines: 5,
                            hint: "Tell us more about you",
                            controller: profileController.aboutController,
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Weight",
                                      style: GoogleFonts.roboto(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 15),
                                    ),
                                    const SizedBox(
                                      height: 12,
                                    ),
                                    EditProfileTextFieldWidget(
                                      controller: profileController.weightController,
                                      hint: 'Enter Your Weight',

                                      validator: (value) {
                                        if (value!.isEmpty

                                            ) {
                                          return "Weight is required";
                                        } else if (value.length > 3) {
                                          return 'Please correct weight '.tr;
                                        }
                                        return null;
                                      },
                                      keyboardType: TextInputType.number,
                                    )
                                  ],
                                ),
                              ),
                              const SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Unit",
                                      style: GoogleFonts.roboto(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 15),
                                    ),
                                    const SizedBox(
                                      height: 12,
                                    ),
                                    DropdownButtonFormField<String>(
                                      value: profileController.selectUnit,
                                      icon:
                                          const Icon(Icons.keyboard_arrow_down),
                                      decoration: InputDecoration(
                                        enabledBorder: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                                color: Color(0xffAFAFAF)),
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        focusedBorder: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                                color: Color(0xffAFAFAF)),
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                        disabledBorder: OutlineInputBorder(
                                            borderSide: const BorderSide(
                                                color: Color(0xffAFAFAF)),
                                            borderRadius:
                                                BorderRadius.circular(10)),
                                      ),
                                      items: profileController.unitItems
                                          .map((String item) {
                                        return DropdownMenuItem<String>(
                                          value: item,
                                          child: Text(item),
                                        );
                                      }).toList(),
                                      onChanged: (String? newValue) {
                                        setState(() {
                                          profileController.selectUnit =
                                              newValue!;
                                        });
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          Row(
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Height",
                                      style: GoogleFonts.roboto(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 15),
                                    ),
                                    const SizedBox(
                                      height: 12,
                                    ),
                                    EditProfileTextFieldWidget(
                                      controller: profileController.fitController,
                                      hint: 'Enter Your Height',
                                      validator: (value) {
                                        if (value!.isEmpty
                                            // || RegExp(r'^(?:\+?88|0088)?01[13-9]\d{8}$').hasMatch(value)
                                            ) {
                                          return "Height is required";
                                        } else if (value.length > 6) {
                                          return 'Please correct height '.tr;
                                        }
                                        return null;
                                      },
                                      keyboardType: TextInputType.number,
                                    )
                                  ],
                                ),
                              ),
                              SizedBox(
                                width: 10,
                              ),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      "Unit",
                                      style: GoogleFonts.roboto(
                                          fontWeight: FontWeight.w500,
                                          fontSize: 15),
                                    ),
                                    const SizedBox(
                                      height: 12,
                                    ),
                                    SizedBox(
                                      height: 58,
                                      child: DropdownButtonFormField<String>(
                                        value: profileController.selectUnit1,
                                        icon: Icon(Icons.keyboard_arrow_down),
                                        decoration: InputDecoration(
                                          enabledBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Color(0xffAFAFAF)),
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                          focusedBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Color(0xffAFAFAF)),
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                          disabledBorder: OutlineInputBorder(
                                              borderSide: BorderSide(
                                                  color: Color(0xffAFAFAF)),
                                              borderRadius:
                                                  BorderRadius.circular(10)),
                                          // border: OutlineInputBorder(
                                          //   ),
                                        ),
                                        items: profileController.unitItems1
                                            .map((String item) {
                                          return DropdownMenuItem<String>(
                                            value: item,
                                            child: Text(item),
                                          );
                                        }).toList(),
                                        onChanged: (String? newValue) {
                                          setState(() {
                                            profileController.selectUnit1 =
                                                newValue!;
                                          });
                                        },
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          Text(
                            "Age",
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.w500, fontSize: 15),
                          ),
                          const SizedBox(
                            height: 12,
                          ),
                          EditProfileTextFieldWidget(
                            hint: "Enter Your Age",
                            keyboardType: TextInputType.number,
                            controller: profileController.ageController,
                            validator: (value) {
                              if (value!.isEmpty
                                  // || RegExp(r'^(?:\+?88|0088)?01[13-9]\d{8}$').hasMatch(value)
                                  ) {
                                return "Age is required";
                              } else if (value.length > 2) {
                                return 'please correct age '.tr;
                              }
                              return null;
                            },
                          ),
                          const SizedBox(
                            height: 12,
                          ),
                          Text(
                            // "Gender",
                            "Biological Gender",
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.w500, fontSize: 15),
                          ),
                          const SizedBox(
                            height: 12,
                          ),
                          DropdownButtonFormField<String>(
                            value: profileController.chooseGender,
                            icon: Icon(Icons.keyboard_arrow_down),
                            decoration: InputDecoration(
                              isDense: true,
                              enabledBorder: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Color(0xffAFAFAF)),
                                  borderRadius: BorderRadius.circular(10)),
                              focusedBorder: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Color(0xffAFAFAF)),
                                  borderRadius: BorderRadius.circular(10)),
                              disabledBorder: OutlineInputBorder(
                                  borderSide:
                                      BorderSide(color: Color(0xffAFAFAF)),
                                  borderRadius: BorderRadius.circular(10)),
                            ),
                            items: profileController.selectGender
                                .map((String item) {
                              return DropdownMenuItem<String>(
                                value: item,
                                child: Text(item),
                              );
                            }).toList(),
                            onChanged: (String? newValue) {
                              setState(() {
                                profileController.chooseGender = newValue!;
                              });
                            },
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          Text(
                            "Health Conditions",
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.w500, fontSize: 15),
                          ),
                          const SizedBox(
                            height: 12,
                          ),
                          EditProfileTextFieldWidget(
                            hint: "Enter Your Health Conditions",
                            controller: profileController.heathController,
                            validator: (value) {
                              if (value!.isEmpty) {
                                return "Health Conditions is required";
                              } else {
                                return null;
                              }
                            },
                          ),
                          const SizedBox(
                            height: 25,
                          ),
                          Text(
                            "Allergies",
                            style: GoogleFonts.roboto(
                                fontWeight: FontWeight.w500, fontSize: 15),
                          ),
                          const SizedBox(
                            height: 12,
                          ),


                          MultiSelectDialogField<dynamic>(
                            items: profileController.allergies.map((dynamic item) => MultiSelectItem<dynamic>(item, item)).toList(),
                            initialValue: [],
                            dialogHeight: 400,
                            dialogWidth: 200,///cropTypesdropdown!.join(',')
                            title: Text("Allergies"),
                            selectedColor: Colors.blue,
                            decoration: const BoxDecoration(
                                borderRadius: BorderRadius.all(Radius.circular(10)),
                                border: Border.fromBorderSide(BorderSide(
                                    color: Colors.grey
                                ),)
                            ),
                            buttonIcon: const Icon(
                              Icons.keyboard_arrow_down,
                              color: Colors.grey,
                            ),
                            buttonText:profileController.selectedAllergies.isEmpty ?  const Text(
                              "Select Items",
                              style: TextStyle(
                                color: Colors.grey,
                                fontSize: 16,
                              ),
                            ):Text(profileController.selectedAllergies.join(', '),softWrap: true,overflow: TextOverflow.ellipsis),
                            onConfirm: ( values) {

                              tempValues = values;


                                if(values.contains("Other")){
                                  handleOtherAllergy();
                                }
                                else{

                                profileController.selectedAllergies = values;

                                print('Selected values: $values');}
                              setState(() {
                              });

                            },
                          ),
                          const SizedBox(
                            height: 35,
                          ),
                          ElevatedButton(
                              onPressed: () async {
                                print(
                                    "SDWASFFEWSDFSFWRFW =>${profileController.selectUnit}");
                                print("selected itemssss =>${profileController.selectedAllergies.join(",")}");

                                if (_formKey1.currentState!.validate()) {
                                  updateProfileRepo(
                                          countrycode: profileController.countryCountry,
                                          image: _image,
                                          name: profileController
                                              .nameController.text,
                                          email: profileController
                                              .emailController.text,
                                          age: profileController
                                              .ageController.text,
                                          phoneNumber: profileController
                                              .phoneNumberController.text,
                                          aboutme: profileController
                                              .aboutController.text,
                                          health: profileController
                                              .heathController.text,
                                          weight: profileController
                                              .weightController.text,
                                          ft: profileController
                                              .fitController.text,
                                          // ini: profileController
                                          //     .inchController.text,
                                          postcode: profileController
                                              .postcodeController.text,
                                          unit: profileController.selectUnit,
                                          unit2: profileController.selectUnit1,
                                          gender:
                                              profileController.chooseGender,
                                          allergy: profileController.selectedAllergies.join(","),
                                          other: "",
                                          context: context)
                                      .then((value) async {
                                    if (value.success == true) {
                                      print("data1${value.message}");
                                      showToast(value.message);
                                      profileController.getProfile();
                                    } else {
                                      print("data2${value.message}");
                                      showToast(value.message);

                                    }
                                  });
                                }
                                // updateProfileRepo(
                                //         name: profileController.nameController.text,
                                //         email: profileController.emailController.text,
                                //         age: profileController.ageController.text,
                                //         phoneNumber: profileController.phoneNumberController.text,
                                //         aboutme:profileController.aboutController.text ,
                                //         health: profileController.heathController.text,
                                //         weight: profileController.weightController.text,
                                //         ft: profileController.fitController.text,
                                //         ini: profileController.inchController.text,
                                //         postcode: profileController.postcodeController.text,
                                //         unit: profileController.selectUnit,
                                //         unit2: profileController.selectUnit1,
                                //         gender: profileController.chooseGender,
                                //         context: context)
                                //     .then((value) async {
                                //   if (value.success == true) {
                                //     print("data1${value.message}");
                                //     showToast(value.message);
                                //     profileController.getProfile();
                                //   } else {
                                //     print("data2${value.message}");
                                //     showToast(value.message);
                                //   }
                                // });

                                ///
                                // Get.toNamed(HomeScreen.route);
                              },
                              style: ElevatedButton.styleFrom(
                                minimumSize:
                                    Size(AddSize.screenWidth, AddSize.size50),
                                backgroundColor: Color(0xffFBB742),
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12)),
                              ),
                              child: Text("Update".toUpperCase(),
                                  style: GoogleFonts.roboto(
                                      fontWeight: FontWeight.w700,
                                      color: Colors.white,
                                      letterSpacing: .5,
                                      fontSize: 20))),
                          const SizedBox(
                            height: 80,
                          ),
                        ],
                      ),
                    ),
                  ),
                )
              : const Center(child: CircularProgressIndicator());
        }),
      ),
    );
  }



  void handleOtherAllergy() async {
    final TextEditingController _otherController = TextEditingController();
    final String? userInput = await Get.dialog<String>(
      AlertDialog(
        title: Text("Specify Other Allergy"),
        content: TextFormField(
          controller: _otherController,
          decoration: InputDecoration(hintText: "Enter other allergy"),
        ),
        actions: <Widget>[
          TextButton(
            child: Text("OK"),
            onPressed: () {
              profileController.selectedAllergies.clear() ;
              for(var item in tempValues){
                profileController.selectedAllergies.add(item.toString()) ;
              }

              profileController.selectedAllergies.remove("Other");
              print("values ${profileController.selectedAllergies}");
              profileController.selectedAllergies.add(_otherController.text);
              profileController.other=_otherController.text;
              Get.back();
              setState(() {
              });
            },
          ),
          TextButton(
            child: Text("Cancel"),
            onPressed: () {
              Navigator.of(Get.context!).pop();
            },
          ),
        ],
      ),
    );

    if (userInput != null && userInput.isNotEmpty) {
      profileController.selectedAllergies.add(userInput);
      log("Custom allergy added: $userInput");
      // Call API to update profile with new allergy list
      updateProfileAllergies();
    }
  }

  // Method to update allergies in profile
  void updateProfileAllergies() {
    // Call your API to update the profile with selectedAllergies
    // Example (pseudo-code):
    // profileRepo.updateProfileAllergies(selectedAllergies).then((result) {
    //   if (result.success) {
    //     showToast("Profile updated successfully!");
    //   } else {
    //     showToast("Failed to update profile.");
    //   }
    // });
  }
}

