import 'dart:developer';
import 'package:Safeplate/screen/BottomNavBar/profile_screen.dart';
import 'package:Safeplate/screen/chat_screen/chat_screen.dart';
import 'package:Safeplate/screen/home/community_screen.dart';
import 'package:Safeplate/screen/home/setting.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import '../../controller/profile_controller.dart';
import '../../main.dart';
import '../comingsoon/coming_soon.dart';
import '../scan/scan.dart';


// String? profileData ;

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  static var route = "/homeScreen";

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {int _selectedIndex = 0;

  void _onItemTapped(int index) {
  setState(() {
    _selectedIndex = index;
  });
}

final List<Color> colorList = [
  const Color(0xffEF535E),
  const Color(0xffF0A72F),
  const Color(0xff6CB9EB),
  const Color(0xff9F91F3), ];


final List<String> images = [
  'assets/icons/scan.png',
  'assets/icons/community.png',
  'assets/icons/detection.png',
  'assets/icons/health.png',
  // Add more images as needed
];
final List<GridItem> items = [
  GridItem(
    color: const Color(0xffEF535E),
    images:  'assets/icons/scan.png',
    title: 'Scan',
    subtitle: 'Scan your food and packaged goods anywhere, anytime',
  ),
  GridItem(
    color: const Color(0xffF0A72F),
    images:  'assets/icons/community.png',
    title: 'Community',
    subtitle: 'Engage in articles, blog posts, and foodie discussions',
  ),
  GridItem(
    color: const Color(0xff6CB9EB),
    images:'assets/icons/detection.png',
    title: 'Start detection',
    subtitle: 'Connect to biosensor & perform tests',
    ),
    GridItem(
      color: const Color(0xff9F91F3),
      images: 'assets/icons/health.png',
      title: 'Health & Wellness',
      subtitle: 'Your Personal Safe and Healthy Eating Expert',
    ),
    // Add more items as needed
  ];

  final profileController = Get.put(ProfileController());

Future pushyRegister() async {
  try {
    // Register the user for push notifications
   // String deviceToken = await Pushy.register();

    // Print token to console/logcat
   // print('Device token: $deviceToken');

    // Display an alert with the device token
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text('Pushy'),
              content: Text('Pushy device token: $pushyToken'),
              actions: [ InkWell( child: Text('OK'), onTap: () { Navigator.of(context, rootNavigator: true).pop('dialog'); } )]
          );
        }
    );

    // Optionally send the token to your backend server via an HTTP GET request
    // ...
  } catch (error) {
    // Display an alert with the error message
    showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
              title: Text('Error'),
              content: Text(error.toString()),
              actions: [ InkWell( child: Text('OK'), onTap: () { Navigator.of(context, rootNavigator: true).pop('dialog'); } )]
          );
        }
    );
  }
}

  @override
  void initState() {
    super.initState();
    profileController.getProfile();
    // pushyRegister();
   // backgroundNotificationListener();


  }

  @override


  Widget build(BuildContext context) {
    var height = MediaQuery.sizeOf(context).height;
    var width = MediaQuery.sizeOf(context).width;
    return Stack(
      children: [
        RefreshIndicator(
        onRefresh: () async {
          profileController.getProfile();
    },
          child: Scaffold(body: Obx(() {
            return
              profileController.statusOfProfile.value.isSuccess?

              Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Stack(
                  children: [
                    Container(
                      height: height * 0.26,
                      // height: 200,
                      decoration: const BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage("assets/images/appbarbg.png"),
                              fit: BoxFit.fill)),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 16, vertical: 10),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            SizedBox(
                              height: height * 0.06,
                            ),
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.all(Radius.circular(20)),
                                  child: CircleAvatar(
                                    backgroundColor: Colors.white,
                                    child:
                                    Image.network(
                                      // "https://sgp1.vultrobjects.com/safeplate/ld32hnd9wk-safeplate/image%2033.png",
                                      "${userimage}",
                                      height: 40,
                                      width: 40,
                                      fit: BoxFit.fill,
                                      loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                        if (loadingProgress == null) {
                                          return child;
                                        } else {
                                          return Center(
                                            child: CircularProgressIndicator(
                                              value: loadingProgress.expectedTotalBytes != null
                                                  ? loadingProgress.cumulativeBytesLoaded / (loadingProgress.expectedTotalBytes ?? 1)
                                                  : null,
                                            ),
                                          );
                                        }
                                      },
                                      errorBuilder: (BuildContext context, Object exception, StackTrace? stackTrace) {
                                        return   CachedNetworkImage(
                                           height: 40,width: 40,
                                           imageUrl: "${
                                                userimage
                                             // profileController.image
                                           }",
                                           fit: BoxFit.fill,
                                           errorWidget:
                                               (context, url, error) =>
                                                   Image.asset(
                                             "assets/icons/addimage.png",
                                             fit: BoxFit.cover,),
                                         );
                                      },
                                    )

                                  ),
                                ),
                                Spacer(),
                                // //SizedBox(width: Get.width*0.5),
                                // GestureDetector(
                                //   onTap: () {
                                //     Get.toNamed(ProfileScreen.route);
                                //   },
                                //   child: Container(
                                //     decoration: BoxDecoration(
                                //         border: Border.all(
                                //             color: Colors.white, width: 2),
                                //         borderRadius: BorderRadius.circular(4)),
                                //     child: Padding(
                                //       padding: const EdgeInsets.symmetric(
                                //           horizontal: 8, vertical: 4),
                                //       child: Center(
                                //         child: Text(
                                //           "Profile",
                                //           style: GoogleFonts.roboto(
                                //               fontSize: 10,
                                //               fontWeight: FontWeight.w400,
                                //               color: Colors.white),
                                //         ),
                                //       ),
                                //     ),
                                //   ),
                                // ),
                                // SizedBox(width: Get.width * 0.04),
                                InkWell(
                                  onTap: () {
                                    Get.to(const SettingScreen());
                                  },
                                  child: ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.asset(
                                      "assets/icons/settingicon.png",
                                      height: 22,
                                      width: 22,
                                    ),
                                  ),
                                )
                              ],
                            ),
                            SizedBox(height: height * 0.016),
                            Row(
                              children: [
                                Text(
                                  "Hello ${usernaam} ",
                                  style: GoogleFonts.roboto(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w300,
                                      color: Colors.white),
                                ),
                                ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: Image.asset(
                                      "assets/icons/smile.png",
                                      height: 22,
                                      width: 22,
                                    ))
                              ],
                            ),
                            SizedBox(height: height * 0.006),
                            Text(
                              "Welcome To Safeplates",
                              style: GoogleFonts.roboto(
                                  fontSize: 18,
                                  fontWeight: FontWeight.w600,
                                  color: Colors.white),
                            )
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                // Container(height: 100,width: 100,color: Colors.red,)
                Padding(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 16, vertical: 0),
                  child: GridView.builder(
                    shrinkWrap: true,
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        crossAxisSpacing: 16,
                        mainAxisSpacing: 16,
                        childAspectRatio: 0.8 / 1),
                    itemCount: items.length,
                    itemBuilder: (context, index) {
                      return InkWell(
                        onTap: () {
                          print("jg${profileController.selectedAllergies.toString()}");
                          if (items[index].title == "Community") {
                            Get.to(const CommunityScreen());
                          } else if (items[index].title == "Scan") {
                            Get.to( SacanScreen(
                              name: profileController.nameController.text.toString(),
                              health: profileController.heathController.text.toString(),
                              age: profileController.ageController.text.toString(),
                              weight: profileController.weightController.text.toString()+profileController.selectUnit.toString(),
                              height: profileController.fitController.text.toString()+profileController.selectUnit1.toString(),
                              Gender: profileController.chooseGender.toString(),
                              allergy: profileController.selectedAllergies.toString(),

                              // name: profileController.nameController.text.toString(),
                              // health: profileController.heathController.text.toString(),
                              // age: profileController.ageController.text.toString(),
                              // weight: profileController.weightController.text.toString(),
                            ));
                          } else if (items[index].title == "Start detection") {
                            // Set up a notification listener
                            // Pushy.setNotificationListener((Map<String, dynamic> data) {
                            //   print('Received notification: $data');
                            //
                            //   showDialog(
                            //     context: context,
                            //     builder: (context) => AlertDialog(
                            //       title: Text('Pushy'),
                            //       content: Text(data['message'] ?? 'Hello World!'),
                            //       actions: <Widget>[
                            //         new TextButton(
                            //           onPressed: () {
                            //             Navigator.of(context).pop();
                            //           },
                            //           child: new Text('OK'),
                            //         ),
                            //       ],
                            //     ),
                            //   );
                            // });

                            Get.to(const CommingSoonScreen());
                          } else if (items[index].title == "Health & Wellness") {
                            _isUserProfileIncomplete() ?
                               _showProfileIncompleteDialog():

                            Get.to(ChatScreen(
                              name: profileController.nameController.text.toString(),
                              health: profileController.heathController.text.toString(),
                              age: profileController.ageController.text.toString(),
                              weight: profileController.weightController.text.toString(),
                              height: profileController.fitController.text.toString()+profileController.selectUnit1.toString(),
                              Gender: profileController.chooseGender.toString(),
                              allergy: profileController.selectedAllergies.toList(),


                            ));
                          }
                        },
                        child: Container(
                          decoration: BoxDecoration(
                              color: items[index].color,
                              borderRadius: BorderRadius.circular(10)),
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 16, vertical: 10),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                ClipRRect(
                                  borderRadius: BorderRadius.circular(50),
                                  child: CircleAvatar(
                                    backgroundColor: Colors.white,
                                    // maxRadius: 22,
                                    child: Image.asset(
                                      items[index].images,
                                      // height: 20,width: 20,
                                      height: height * 0.026,
                                      // width: width * 0.08,
                                    ),
                                  ),
                                ),
                                // Container(
                                //   decoration: BoxDecoration(
                                //       borderRadius: BorderRadius.circular(50),
                                //       color: Colors.white),
                                //   child: Padding(
                                //     padding: const EdgeInsets.all(16.0),
                                //     child:
                                //   ),
                                // ),
                                SizedBox(
                                  height: height * 0.02,
                                ),
                                Text(
                                   // profileController.nameController.text.toString()
                                   items[index].title
                                  ,
                                  style: GoogleFonts.roboto(
                                      fontSize: 22,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.white),
                                ),
                                SizedBox(
                                  height: height * 0.01,
                                ),
                                Text(
                                  items[index].subtitle
                                  ,
                                  style: GoogleFonts.roboto(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w400,
                                    color: Colors.white,
                                    height: 1,
                                  ),
                                  softWrap: true,
                                  // overflow: true,
                                  // maxLines: 2,
                                ),
                              ],
                            ),
                          ),
                        ),
                      );
                    },
                  ),
                )
              ],
            ):Center(child: CircularProgressIndicator());
          })),
        ),
    ],
  );
}

//pop in unfilldetatils in user//

bool _isUserProfileIncomplete() {
  return [

    profileController.nameController.text.toString(),
    profileController.heathController.text.toString(),
    profileController.ageController.text.toString(),
     profileController.weightController.text.toString(),
   profileController.fitController.text.toString()+profileController.selectUnit1.toString(),
    profileController.chooseGender.toString(),
    // profileController.selectedAllergies.toString()
    // widget.age,
    // widget.health,
    // widget.weight,
    // widget.height,
    // widget.Gender,
  ].any((field) => field == null || field.isEmpty);
}

void _showProfileIncompleteDialog() {
  showDialog(
    context: context,
    barrierDismissible: false,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text("Incomplete Profile"),
        content: const Text(
            "Your profile information is incomplete. Please fill out all the details to continue."),
        actions: [
          TextButton(
            onPressed: () {
              Get.back(); // Close the dialog
              Get.toNamed(ProfileScreen.route); // Redirect to the profile screen
            },
            child: const Text("Go to Profile Page"),
          ),
        ],
      );
    },
  );
}


}


class GridItem {
  final Color color;
  final String images;
  final String title;
  final String subtitle;

  GridItem({
    required this.color,
    required this.images,
    required this.title,
    required this.subtitle,
  });
}