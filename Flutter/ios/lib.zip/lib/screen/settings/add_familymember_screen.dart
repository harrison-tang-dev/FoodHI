import 'dart:developer';
import 'dart:io';
import 'package:Safeplate/screen/settings/communityandmyposts.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:Safeplate/resources/dimension.dart';
import 'package:Safeplate/widget/custom_textfield.dart';
import 'package:intl_phone_field/intl_phone_field.dart';

import '../../repo/addnew_family_repo.dart';
import '../../widget/helper.dart';

class AddFamilyMember extends StatefulWidget {
  const AddFamilyMember({super.key});
  static var route = "/addFamilyMember";

  @override
  State<AddFamilyMember> createState() => _AddFamilyMemberState();
}

class _AddFamilyMemberState extends State<AddFamilyMember> {
  final _formKey = GlobalKey<FormState>();

  bool showValidation = false;
  RxString dropdown = ''.obs ;

  TextEditingController nameController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  TextEditingController phonenumberController = TextEditingController();
  TextEditingController relationshipController = TextEditingController();
  String?countryCode;
  bool? _isValue = false;
  final RxStatus status = RxStatus.loading();
String? selectValue ='Mother';

  var tempValues;
  RxList<String> familyRelationship=['Mother','Father','Sister','Brother','Other' ].obs;

  void otherRealtion() async {
    final TextEditingController _otherController = TextEditingController();
    final String? userInput = await Get.dialog<String>(
      AlertDialog(
        title: Text("Specify Other Allergy"),
        content: TextFormField(
          controller: _otherController,
          decoration: InputDecoration(hintText: "Enter other allergy"),
        ),
        actions: <Widget>[
          TextButton(
            child: const Text("OK"),
            onPressed: () {
              selectValue =_otherController.text;
              familyRelationship.add(selectValue!);
              setState(() {

              });
              Navigator.of(Get.context!).pop();

            },
          ),
          TextButton(
            child: const Text("Cancel"),
            onPressed: () {
              Navigator.of(Get.context!).pop();
            },
          ),
        ],
      ),
    );

  }


  File? _image;
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImageFromGallery() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    } else {
      log('No image selected.');
    }
  }

  Future<void> _pickImageFromCamera() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    } else {
      log('No image selected.');
    }
  }



  @override
  Widget build(BuildContext context) {
    return  Scaffold(
      extendBody:false,
      resizeToAvoidBottomInset: false,

      appBar: AppBar(
        toolbarHeight: 80,
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: const Color(0xff75D051),
        leading: IconButton(
          onPressed: (){
            Get.back();
          },
          icon: const Icon(
            Icons.arrow_back_ios,color: Colors.white,
          ),
        ),
        title: Text("Add New Family Member", style: GoogleFonts.roboto(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color:Colors.white),),

      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 10,vertical: 10),
          child: Form(
            key: _formKey,
            child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: CircleAvatar(
                    maxRadius: 54,
                    backgroundColor:const Color(0xff75D051) ,
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(50),
                      child: InkWell(
                        onTap: (){

                          showDialog(
                            context: context,
                            builder: (BuildContext context) {
                              return Dialog(
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(horizontal:26,vertical: 18),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    mainAxisSize: MainAxisSize.min,
                                    children: <Widget>[
                                      Text("Choose Any One:",style: GoogleFonts.roboto(
                                          fontSize: 16,
                                          fontWeight: FontWeight.w500,
                                          color:Colors.black),),

                                      SizedBox(height: Get.height*0.04,),
                                      Padding(
                                        padding: const EdgeInsets.symmetric(horizontal: 16),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                          children: [
                                            InkWell(
                                              onTap: (){
                                                _pickImageFromCamera();
                                                Get.back();
                                              },
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  // Icon(Icons.camera_rear),
                                                  Image.asset("assets/icons/camera.png",height: 24,width: 24,),
                                                  Text("Camera",style: GoogleFonts.roboto(
                                                      fontSize: 15,
                                                      fontWeight: FontWeight.w400,
                                                      color:Colors.black),),
                                                ],
                                              ),
                                            ),
                                            InkWell(
                                              onTap: (){
                                                _pickImageFromGallery();
                                                Get.back();
                                              },
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                mainAxisAlignment: MainAxisAlignment.center,
                                                children: [
                                                  Image.asset("assets/icons/gallery.png",height: 24,width: 24,),
                                                  Text("Gallery",style: GoogleFonts.roboto(
                                                      fontSize: 15,
                                                      fontWeight: FontWeight.w400,
                                                      color:Colors.black),),
                                                ],
                                              ),
                                            )
                                          ],
                                        ),
                                      ),
                                      SizedBox(height: Get.height*0.04,),
                                    ],
                                  ),
                                ),
                              );
                            },
                          );

                        },
                        child:
                        Container(
                          height: 100,
                          width: 100,
                          decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(50)
                          ),
                          child:
                          _image == null
                              ? Image.asset("assets/icons/addimage.png",fit: BoxFit.cover,)
                              : Image.file(_image!,fit: BoxFit.cover,),


                        ),
                      ),
                    ),
                  ),
                ),

                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 14,vertical: 15),
                  child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        "Name",
                        style: GoogleFonts.roboto(
                            fontWeight: FontWeight.w500,
                            fontSize: 15),
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                       EditProfileTextFieldWidget(
                         textInputAction: TextInputAction.next,
                         keyboardType: TextInputType.name,
                        hint: "Enter Your Name",
                        controller: nameController,
                         validator: (value) {
                           if (value!.trim().isEmpty) {
                             return 'Name is required'.tr;
                           } else if (value.length >= 30) {
                             return 'Name cannot exceed 30 characters'.tr;
                           }
                           else if (RegExp(r'(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])').hasMatch(value)) {
                             return 'Name is not accept in emoji'.tr;
                           }
                           return null;
                         },

                      ),
                      const SizedBox(
                        height: 25,
                      ),
                      Text(
                        "Email",
                        style: GoogleFonts.roboto(
                            fontWeight: FontWeight.w500,
                            fontSize: 15),
                      ),
                      const SizedBox(
                        height: 12,
                      ),

                       EditProfileTextFieldWidget(
                        hint: "Enter Your Email",
                        controller:emailController,
                         keyboardType: TextInputType.emailAddress,
                         validator: (value) {
                           if (value == null || value.isEmpty) {
                             return "Email is required";
                           } else if (!RegExp(r"^[a-zA-Z0-9.a-zA-Z0-9.!#$%&'*+-/=?^_`{|}~]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(value)) {
                             return "Enter a valid email address";
                           } else {
                             return null;
                           }
                         },
                      ),
                      const SizedBox(
                        height: 25,
                      ),
                      Text(
                        "Phone Number",
                        style: GoogleFonts.roboto(
                            fontWeight: FontWeight.w500,
                            fontSize: 15),
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      IntlPhoneField(
                        decoration: InputDecoration(
                          hintText: 'Enter phone number',
                          focusColor: Colors.black,
                          hintStyle: const TextStyle(
                              height: 1.5,
                              color: Color(0xff181818), fontSize: 14,fontWeight: FontWeight.w400),
                          // labelText: label,
                          // labelStyle: TextStyle(color:Colors.black, fontSize: AddSize.font14),
                          filled: true,
                          fillColor: Colors.transparent,
                          contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 20),
                          // .copyWith(top: maxLines! > 4 ? AddSize.size18 : 0),

                          focusedBorder: OutlineInputBorder(
                            borderSide: const BorderSide(color: Color(0xffAFAFAF)),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: const OutlineInputBorder(
                              borderSide: BorderSide(color: Color(0xffAFAFAF)),
                              borderRadius: BorderRadius.all(Radius.circular(10))),
                          border: OutlineInputBorder(
                              borderSide: const BorderSide(color:  Color(0xffAFAFAF), width: 3.0),
                              borderRadius: BorderRadius.circular(10)),
                        ),
                        controller:phonenumberController,
                        keyboardType: TextInputType.number,
                        textInputAction: TextInputAction.next,
                        onCountryChanged: (country) {
                          countryCode = country.code;

                          log("numbeeee${country.code}");
                        },
                        initialCountryCode: countryCode,

                        // Default to India
                        onChanged: (phone) {
                          // Handle phone number changes
                          log("45454545454545${phone.completeNumber}");

                          setState(() {}); // +91 1234567890
                        },
                        validator: (value) {
                          if (value == null || value.number.isEmpty) {
                            return "Phone number is required";
                          } else if (value.number.length != 15) {
                            return 'Number must be exactly 15 digits';
                          }
                          return null;
                        },
                      ),
                      // EditProfileTextFieldWidget(
                      //   textInputAction: TextInputAction.next,
                      //   hint: 'Enter Your Phone Number',
                      //   keyboardType: TextInputType.number,
                      //   controller: phonenumberController,
                      //   validator: (value) {
                      //     if (value!.isEmpty
                      //     // || RegExp(r'^(?:\+?88|0088)?01[13-9]\d{8}$').hasMatch(value)
                      //     ) {
                      //       return "Phone number is required";
                      //     } else if  (value.length > 10 ||value.length < 10) {
                      //       return 'number cannot exceed 10 characters'.tr;
                      //     }
                      //     return null;
                      //   },
                      // ),
                      const SizedBox(
                        height: 10,
                      ),
                      Text(
                        "Relationship",
                        style: GoogleFonts.roboto(
                            fontWeight: FontWeight.w500,
                            fontSize: 15),
                      ),
                      const SizedBox(
                        height: 12,
                      ),
                      Obx(()  {
                        return  DropdownButtonFormField<String>(
                          value: selectValue!,
                          hint: Text("select relation"),
                          icon: const Icon(Icons.keyboard_arrow_down),
                          decoration: InputDecoration(
                            enabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: Color(0xffAFAFAF)),
                                borderRadius:
                                BorderRadius.circular(10)),
                            focusedBorder: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: Color(0xffAFAFAF)),
                                borderRadius:
                                BorderRadius.circular(10)),
                            disabledBorder: OutlineInputBorder(
                                borderSide: const BorderSide(
                                    color: Color(0xffAFAFAF)),
                                borderRadius:
                                BorderRadius.circular(10)),
                          ),
                          // onTap: (){
                          //   log("eeeeede${familyRelationship.length.toString()}");
                          //   if(familyRelationship.length==6){
                          //     familyRelationship.removeLast();
                          //     selectValue="Mother";
                          //     setState(() {
                          //     });
                          //   }
                          // },
                          items: familyRelationship.value.map((String item) {

                            return DropdownMenuItem<String>(
                              value: item,
                              child: Text(item),
                            );

                          }).toList(),
                          onChanged: (String? newValue) {
                            setState(() {
                              selectValue = newValue!;
                            });
                            // if(newValue!.contains("Other")){
                            //   otherRealtion();
                            // }
                          },
                        );
                      }),


                      const SizedBox(
                        height: 25,
                      ),
                      const SizedBox(
                        height: 60,
                      ),
                      ElevatedButton(
                          onPressed: () async {
                           if (_formKey.currentState!.validate()) {
                             addFamilyMemberRepo(
                                 countryCode:countryCode,
                               image:_image,
                                  name: nameController.text,
                                  email: emailController.text,
                                 phonenumber:phonenumberController.text,
                                  images:_image ?? "" ,
                                 relationship: selectValue,//relationshipController.text,
                                  context: context



                              ).then((value) {
                                if (value.success == true) {

                                  print("data${value.message}");
                                  showToast(value.message);
                                  // Get.back();
                                  Get.offAll(const AllFamilyMember());
                                  // Get.toNamed(AddFamilyMember.route);
                                  print("emailController${emailController.text}");

                                  //  Get.toNamed(LoginScreen.route);
                                }
                                else {
                                  print("data>>>>>>>");
                                  //Get.toNamed(SignupOtp.route, arguments: emailController.text);
                                  showToast(value.message);
                                }
                              });
                            }
                          },
                          style: ElevatedButton.styleFrom(
                            minimumSize:
                            Size(AddSize.screenWidth, AddSize.size60),
                            backgroundColor: const Color(0xffFBB742),
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12)),
                          ),
                          child: Text("Save".toUpperCase(),
                              style: GoogleFonts.roboto(
                                  fontWeight: FontWeight.w700,
                                  color: Colors.white,
                                  letterSpacing: .5,
                                  fontSize: 20))),

                    ],
                  ),
                ),



              ],
            ),
          ),
        ),
      ),
    );
  }
}
 