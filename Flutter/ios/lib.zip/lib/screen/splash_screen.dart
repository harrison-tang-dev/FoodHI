import 'dart:async';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:Safeplate/screen/onboarding_screen.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'BottomNavBar/bottomnavbar.dart';


class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});


  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {

  @override
  void initState() {

    super.initState();
    Timer(const Duration(seconds: 6), () async {

      SharedPreferences pref = await SharedPreferences.getInstance();
      String? userInfo = pref.getString('cookie');
      if (userInfo != null){
         Get.offAllNamed(BottomNavbar.route);

      } else {

         Get.offAllNamed(OnBoardingScreen.route);
      }


    });
  }
  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    return Scaffold(
        extendBody: true,  backgroundColor: Colors.white,
        body:  Container(
            height: Get.height,
            width: Get.width,
            child: Image.asset('assets/splas.gif',fit: BoxFit.fill,))

    );
  }
}
