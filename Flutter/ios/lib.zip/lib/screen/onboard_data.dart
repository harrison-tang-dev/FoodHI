class OnBoardModelResponse {
  final String? image, title, description;

  OnBoardModelResponse({
    this.image,
    this.title,
    this.description,
  });
}

List<OnBoardModelResponse> OnBoardData = [
  OnBoardModelResponse(
      image: "assets/images/Onbording 1.png",
      title: "Finish your plates safe with SafePlate",
      description: "Real-time Scanner, Personal Chatbot, and Global Community."),
  OnBoardModelResponse(
      image: "assets/images/Onbording 2.png",
      title: "Healthy and Safe food anywhere, anytime",
      description: "Keep track of your allergies, health conditions, and diet consumption."),
  OnBoardModelResponse(
      image:  "assets/images/Onbording 3.png",
      title: "Access to the global foodie community ",
      description: "Introduce, test, and solve food-related issues, all in one APP."),
];
