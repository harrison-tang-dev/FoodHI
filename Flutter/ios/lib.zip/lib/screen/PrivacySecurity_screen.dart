import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:Safeplate/resources/dimension.dart';

import '../model/terms_model.dart';
import '../repo/privacy_repo.dart';
import '../widget/helper.dart';

class PrivacyPolicy extends StatefulWidget {
  const PrivacyPolicy({super.key});

  static var route = "/privacyPolicy";

  @override
  State<PrivacyPolicy> createState() => _PrivacyPolicyState();
}

class _PrivacyPolicyState extends State<PrivacyPolicy> {

  Rx<TermsModel> dataPrivacy = TermsModel().obs;
  Rx<RxStatus> statusOfPrivacy = RxStatus
      .empty()
      .obs;

  privacyDataGet() {
    privacyRepo().then((value) {
      log("response.body.....    ${value}");
      dataPrivacy.value = value;
      if (value.success == true) {
        statusOfPrivacy.value = RxStatus.success();
        //   showToast(value.message);
        print("11111111111111111111111${value.message.toString()}");
      } else {
        showToast(value.message);
        print("222222222222222222222222${value.message.toString()}");
        statusOfPrivacy.value = RxStatus.error();
      }
    });
  }

  @override
  void initState() {
    super.initState();
    privacyDataGet();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: Color(0xff75D051),
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: Icon(
            Icons.arrow_back_ios, color: Colors.white,
          ),
        ),
        title: Text("Privacy & Security", style: GoogleFonts.roboto(
            fontSize: 16,
            fontWeight: FontWeight.w500,
            color: Colors.white),),

      ),
      body: Obx(() {
        return
          statusOfPrivacy.value.isSuccess?
          Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: SingleChildScrollView(
            child: Column(crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Html(
                  data:dataPrivacy.value.pagedata![0].content,
                  style: {'body':Style(color: Colors.black,fontSize: FontSize(14),fontWeight: FontWeight.w400,lineHeight: LineHeight(1.6),
                  fontFamily: GoogleFonts.roboto().fontFamily)},

                ),
              ],
            ),
          ),
        )
        :Center(child: CircularProgressIndicator(),)
        ;
      }),

    );
  }
}
