// import 'dart:async';
// import 'dart:io';
// import 'dart:typed_data';
// import 'package:flutter/material.dart';
// import 'package:flutter_ffmpeg/flutter_ffmpeg.dart';
// import 'package:get/get.dart';
// import 'package:shared_preferences/shared_preferences.dart';
// import 'package:video_player/video_player.dart';
//
// import 'BottomNavBar/bottomnavbar.dart';
// import 'onboarding_screen.dart';
//
// class VideoScreen extends StatefulWidget {
//   const VideoScreen({Key? key}) : super(key: key);
//
//   @override
//   State<VideoScreen> createState() => _VideoScreenState();
// }
//
// class _VideoScreenState extends State<VideoScreen> {
//   late VideoPlayerController _controller;
//   late Future<void> _initializeVideoPlayerFuture;
//   late bool _isInitialized;
//   // final FlutterFFmpeg _flutterFFmpeg = FlutterFFmpeg();
//
//   @override
//   void initState() {
//     super.initState();
//
//     _controller = VideoPlayerController.asset('assets/setting/splavideo.mp4');
//     _initializeVideoPlayerFuture = _controller.initialize();
//     _isInitialized = false;
//
//     _initializeVideoPlayerFuture.then((_) {
//       setState(() {
//         _isInitialized = true;
//       });
//       _controller.setLooping(false);
//       _controller.play();
//     });
//
//     _controller.addListener(() async {
//       if (_controller.value.position >= _controller.value.duration) {
//         await _convertVideoToGif('assets/setting/splavideo.mp4');
//         SharedPreferences pref = await SharedPreferences.getInstance();
//         String? userInfo = pref.getString('cookie');
//         if (userInfo != null) {
//           Get.toNamed(BottomNavbar.route);
//           // if (Platform.isAndroid)
//           //   Timer(Duration(seconds: 8), () {
//           //     Get.offAllNamed(BottomNavbar.route);
//           //   });
//           // if (Platform.isIOS)
//           //   Timer(Duration(seconds: 12), () {
//           //     Get.offAllNamed(BottomNavbar.route);
//           //   });
//         } else {
//           Get.offAllNamed(OnBoardingScreen.route);
//         }
//       }
//     });
//   }
//
//   Future<void> _convertVideoToGif(String videoPath) async {
//     final outputGifPath = videoPath.replaceAll('.mp4', '.gif');
//
//     // Extract frames from the video
//     await _flutterFFmpeg.execute(
//         '-i $videoPath -vf "fps=10,scale=320:-1:flags=lanczos" $outputGifPath'
//     );
//
//     // Optionally, you can load the GIF and use it in your app
//     final gifFile = File(outputGifPath);
//     if (gifFile.existsSync()) {
//       final gifBytes = await gifFile.readAsBytes();
//       // Do something with the GIF, such as displaying it
//     }
//   }
//
//   @override
//   void dispose() {
//     _controller.dispose();
//     super.dispose();
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       extendBody: true,
//       backgroundColor: Colors.white,
//       body: SizedBox(
//         height: Get.height,
//         width: Get.width,
//         child: FutureBuilder(
//           future: _initializeVideoPlayerFuture,
//           builder: (context, snapshot) {
//             if (snapshot.connectionState == ConnectionState.done) {
//               if (snapshot.hasError) {
//                 return Center(child: Text('Error: ${snapshot.error}'));
//               } else {
//                 return AspectRatio(
//                   aspectRatio: _controller.value.aspectRatio,
//                   child: VideoPlayer(_controller),
//                 );
//               }
//             } else {
//               return Center(child: CircularProgressIndicator()); // Show a loading spinner while initializing
//             }
//           },
//         ),
//       ),
//     );
//   }
// }
