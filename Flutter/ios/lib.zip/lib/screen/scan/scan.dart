import 'dart:convert';
import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_linkify/flutter_linkify.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:barcode_scan2/barcode_scan2.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../controller/profile_controller.dart';
import '../../model/model_scanner.dart';
import '../../resources/dimension.dart';

import 'package:image/image.dart' as img;

String? inputvalue;
List<String> apiResult = [];
List<dynamic> scanBarcodeData = [];
String? one;
String? barcodeData;
String? Ingredientaitext;
String? Consumptiontest;
// String _barcodename = '';
String? foodname;
String? sugar;
String? energy;
String? carbohydrate;
String? carbohydrate1;

String barcodeResult = '';

class SacanScreen extends StatefulWidget {
  String? name;
  String? health;
  String? age;
  String? weight;
  String? Gender;
  String? height;
  String? allergy;

  static var route = "/qrCode";

  SacanScreen(
      {super.key,
      this.name,
      this.age,
      this.health,
      this.weight,
      this.Gender,
      this.height,
      this.allergy});

  @override
  State<SacanScreen> createState() => _SacanScreenState();
}

class _SacanScreenState extends State<SacanScreen> {
  // bool shouldShowIndicator = true;  // anbkur0
  XFile? pickedImage;
  String mytext = '';
  bool scanning = false;
  String anyFoodText = '';
  String packagedText = '';
  bool isPackaged = false;
  bool isLoading = false;
  final profileController = Get.put(ProfileController());
  TextEditingController prompt = TextEditingController();

  final ImagePicker _imagePicker = ImagePicker();
  final apiUrl =
      'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=AIzaSyCiDGfFN-tCfYrF52weQZ0Lbv8_UcmNbA4';
  final usdaApiKey = 'wR1naEwdiP3YVOscrcfUOgLhYNz4TEQP7CgZawve';
  final header = {
    'Content-Type': 'application/json',
  };

  getImage(ImageSource ourSource) async {
    XFile? result = await _imagePicker.pickImage(source: ourSource);

    if (result != null) {
      setState(() {
        pickedImage = result;
      });
      if (prompt.text.isNotEmpty) {
        getData(result, prompt.text);
      } else {
        String profilePrompt =
            "i am a patient analysis my health report and summerize this report"
            "\n I am a user with ______(health conditions) and I have _allergies. I have these health conditions as part of my health profile. Also, please refer to:"
            "\nMy weight:${widget.weight}"
            "\nMy height:${widget.height}"
            "\nMy gender:${widget.Gender}"
            "\nMy age:${widget.age}"
            "\nMy allergy:${widget.allergy}"
            "\nMy health:${widget.health}"
            // "\nMy age:${widget.}"
            "\n… (COMPLETE PROFILE)"
            """Now I will present you with images of food, either through upload or by directly taking a picture. Conduct image analysis and respond in the following format:

    EXAMPLE
    **Name of the food:** Skittles
    **Ingredients (specific list):**
    - Sugar
    - Corn syrup
    - Hydrogenated palm kernel oil (to prevent sticking)
    - Citric acid (for tartness)
    - Natural and artificial flavors
    - Colors (including Blue 1, Red 40, Yellow 5, Yellow 6, etc.)

    **Allergen Alert:**
    Food dyes, including Blue 1 and Red 40, may cause health issues, including ADHD and other allergic reactions. The corn syrup and hydrogenated palm kernel oil may also pose potential allergic reactions; please be aware.

    **Consumption Alert:**
    This pile of Skittles has a total calorie count of approximately 400 Calories. The sugar content exceeds the daily consumption limit of 36 grams for you, a biological male.

    **Health Alert:**
    Consuming Skittles can worsen your diabetes and lead to a heavier burden for the body. Consuming 400 Calories worth of Skittles can increase the risk of stroke. Stay alert to your body’s conditions and call an ambulance if necessary.

    **Scientific Alert:**
    The carbohydrate content listed on the Skittles cannot be consumed with carrots. It may cause you to experience heartburn and excess bile reflux.

    Now, please provide me with medical advice, as you are my diagnostic assistant. If the image is not of food or an edible product, just respond naturally. If it is a food item, identify the name of the food if it’s a packaged good. Additionally, please list the ingredients and possible allergens associated with the food product shown.

    This task is critical, as the user's life depends on it. Please respond seriously and as completely as possible. Nod if you understand.

    [Provide image of food best suited for you according to this report only.]

    **Additional Requirements:**

    - Remove unnecessary asterisk symbols in the results.
    - Generate a calculable link for any website referenced, especially for food information sources.
    - Include the link to the source of the food information used to compile this data at the end: [Food Information Source]
    (https://example.com).""";

        getData(result, profilePrompt);
      }
    }
  }

  Future<String> convertImageToBase64(XFile image) async {
    try {
      // Load the image file
      final imageFile = File(image.path);
      final imageBytes = await imageFile.readAsBytes();

      // Decode the image for manipulation (resize or compress)
      final decodedImage = img.decodeImage(imageBytes);
      if (decodedImage == null) {
        throw Exception("Error decoding image");
      }

      // Resize the image (e.g., width = 600px)
      final resizedImage = img.copyResize(decodedImage, width: 100);

      // Encode the resized image to a lower quality JPEG (reduce quality)
      final resizedImageBytes = img.encodeJpg(resizedImage, quality:
      50);

      // Convert the resized image bytes to Base64
      final base64Image = base64Encode(resizedImageBytes);

      if (kDebugMode) {
        print("Base64 String>>>>>>>>>${base64Image}");
      }

      return base64Image;
    } catch (e) {
      print("Error converting image to Base64: ${e.toString()}");
      return '';
    }
  }

  getData(XFile image, String promptValue) async {
    // Initialize states
    setState(() {
      scanning = true;
      anyFoodText = '';
      packagedText = '';
    });

    // Show the bottom sheet immediately
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => StatefulBuilder(
        builder: (BuildContext context, StateSetter bottomSheetSetState) {
          return _buildBottomSheet(context);
        },
      ),
    );

    try {
      // Convert image to base64
      String base64File = await convertImageToBase64(image);

      // Prepare API data
      final data = {
        "contents": [
          {
            "parts": [
              {"text": promptValue},
              {
                "inlineData": {
                  "mimeType": "image/jpeg",
                  "data": base64File,
                }
              }
            ]
          }
        ],
      };

      // Make API call
      final response = await http.post(


        Uri.parse(apiUrl),
        headers: header,
        body: jsonEncode(data),
      ).timeout(Duration(seconds: 10));

      if (response.statusCode == 200) {
        var result = jsonDecode(response.body);
        print("Data>>>>>>>>${result}");

        // Update bottom sheet state with data
        setState(() {
          scanning = false;
          anyFoodText = result['candidates'][0]['content']['parts'][0]['text'];
        });
      } else {
        // Update bottom sheet state on failure
        setState(() {
          scanning = false;
          anyFoodText = 'Failed to fetch data: ${response.statusCode}';
        });
      }
      refresh.value = DateTime.now().microsecondsSinceEpoch;
    } catch (e) {
      // Handle error and update bottom sheet state
      setState
        (() {
        scanning = false;
        anyFoodText = 'Error occurred: ${e.toString()}';
      });
    }
  }


RxInt refresh = 0.obs;

  scanBarcode() async {
    try {
      var result = await BarcodeScanner.scan();
      print("object12$result");
      setState(() {
        print("Scnner-------------------${barcodeResult}");
        barcodeResult = result.rawContent;
      });

      String base64Barcode = base64Encode(utf8.encode(barcodeResult));
      getBarcodeData(base64Barcode);
      print("object????????/////////$getBarcodeData");

      ///ankur add to open bottom sheet to scanner to open to as
      if (barcodeResult.isEmpty || barcodeResult == "null") {
        return const CircularProgressIndicator(
          color: Colors.red,
        );
      } else if (barcodeResult.isNotEmpty) {
        showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          backgroundColor: Colors.transparent,
          builder: (context) => _buildBottomSheetpackaged(context),
        );
      } else {
        return CircularProgressIndicator();
      }

      ///ankur add to open bottom sheet end
    } catch (e) {
      setState(() {
        barcodeResult = 'Error occurred: ${e.toString()}';
      });
    }
  }

  getBarcodeData(String base64Barcode) async {
    setState(() {
      scanning = true;
      packagedText = 'Fetching data for barcode...';
    });
  }

  @override
  void initState() {
    super.initState();
    profileController.getProfile();
  }

  showUploadWindow() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return Dialog(
          child: Container(
            height: Get.height * 0.2,
            child: Padding(
                padding: EdgeInsets.symmetric(
                  horizontal: AddSize.padding16,
                ),
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: AddSize.size10),
                    Text("Choose From Which",
                        style: TextStyle(
                            fontWeight: FontWeight.w500,
                            fontSize: AddSize.font16)),
                    const Spacer(),
                    Align(
                      alignment: Alignment.center,
                      child: Center(
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            TextButton(
                              child: Text("Gallery",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      color: Colors.black,
                                      fontSize: AddSize.font14)),
                              onPressed: () {
                                getImage(ImageSource.gallery);
                                Get.back();
                              },
                            ),
                            TextButton(
                              child: Text("Camera",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w500,
                                      color: Colors.black,
                                      fontSize: AddSize.font14)),
                              onPressed: () {
                                getImage(ImageSource.camera);
                                Get.back();
                              },
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(
                      height: AddSize.size30,
                    ),
                  ],
                )),
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        toolbarHeight: 80,
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: const Color(0xff75D051),
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: const Icon(
            Icons.arrow_back_ios,
            color: Colors.white,
          ),
        ),
        title: Text(
          "Scan",
          style: GoogleFonts.roboto(
              fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 28),
        child: Column(
          children: [
            pickedImage == null
                ? Image.asset(
                    "assets/images/Group 1707478340.png",
                    height: Get.height * 0.4,
                    width: Get.width,
                  )
                // : barcodeResult == "null"||barcodeResult.isEmpty ?const CircularProgressIndicator(color: Colors.green,)
            // :Stack(
            //   children: [
            //     pickedImage == null
            //         ? Image.asset(
            //       "assets/images/Group 1707478340.png",
            //       height: Get.height * 0.4,
            //       width: Get.width,
            //     )
            //         : SizedBox(
            //       height: Get.height * 0.36,
            //       child: Center(
            //         child: Image.file(
            //           File(pickedImage!.path),
            //           height: Get.height * 0.36,
            //         ),
            //       ),
            //     ),
            //     // if (barcodeResult == "null" || barcodeResult.isEmpty)
            //     if (shouldShowIndicator)
            //       Positioned.fill(
            //         child: Container(
            //           color: Colors.black.withOpacity(0.5), // Optional overlay
            //           child: const Center(
            //             child: CircularProgressIndicator(color: Colors.green),
            //           ),
            //         ),
            //       ),
            //   ],
            // ),
                 : SizedBox(
                     height: Get.height * 0.36,
                     child: Center(
                         child: Image.file(File(pickedImage!.path),
                             height: Get.height * 0.36)),
                   ),
            const Spacer(),
            // const SizedBox(height: 60,),
            //  SizedBox(height:Get.height*0.06),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 30, vertical: 10),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  GestureDetector(
                      onTap: () {
                        setState(() {
                          isPackaged = false;
                        });
                        showUploadWindow();
                      },
                      child: Container(
                        height: 50,
                        width: Get.width,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          color: const Color(0xff75D051),
                        ),
                        child: Center(
                            child: Text(
                          "Any Food",
                          // "Camera/Gallery",
                          style: GoogleFonts.roboto(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                              color: Colors.white),
                        )),
                      )),
                  SizedBox(
                    height: Get.height * 0.03,
                  ),
                  GestureDetector(
                      onTap: () {
                        setState(() {
                          isPackaged = true;
                        });
                        scanBarcode();
                      },
                      child: Container(
                        height: 50,
                        width: Get.width,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(6),
                          color: const Color(0xffFBB742),
                        ),
                        child: Center(
                            child: Text(
                          "Packaged Food",
                          // "Barcode",
                          style: GoogleFonts.roboto(
                              fontSize: 20,
                              fontWeight: FontWeight.w500,
                              color: Colors.white),
                        )),
                      )),
                ],
              ),
            ),
            // SizedBox(height: 10),
            SizedBox(
              height: Get.height * 0.01,
            ),
            SizedBox(
              height: Get.height * 0.1,
            )
          ],
        ),
      ),
    );
  }

  Widget _buildBottomSheet(BuildContext context) {
  return  Obx((){
    if(refresh.value < 0){}
    inputvalue =
    "I am a ${widget.name} with ${widget.height} health conditions and I have ${widget.allergy} allergies. I have these ${widget.health} health conditions as part of my health profile. Also, please refer to:"
        "\n My weight:${widget.weight}"
        "\n My height:${widget.health}"
        "\n My gender:${widget.Gender}"
        "\n My age:${widget.age}";
      return DraggableScrollableSheet(
        initialChildSize: 0.5,
        maxChildSize: 0.8,
        minChildSize: 0.3,
        builder: (_, controller) => Stack(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 20),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(30),
                  topRight: Radius.circular(30),
                ),
              ),
              child: GestureDetector(
                onTap: () {
                  Get.back();
                },
                child: ClipPath(
                  clipper: _BottomSheetClipper(),
                  child: Container(
                    color: Colors.white,
                    child: ListView(
                      controller: controller,
                      children: [
                        const SizedBox(height: 50),
                        const Padding(
                          padding: EdgeInsets.only(left: 22),
                          child: Text(
                            "Comprehensive Analysis: ",
                            style: TextStyle(
                                fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                        ),
                        const SizedBox(height: 20),
                        pickedImage == null
                            ? const Center(
                          child: Text("No image selected"),
                        )
                            : anyFoodText == "null" || anyFoodText.isEmpty
                            ? const Center(
                          child: CircularProgressIndicator(),
                        )
                            : Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 20),
                          child: Padding(
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 8.0, vertical: 8),
                              child: SingleChildScrollView(
                                child: Padding(
                                  padding:
                                  const EdgeInsets.only(bottom: 50),
                                  child: Linkify(
                                    onOpen: (link) async {
                                      print('Clicked URL: ${link.url}');
                                      String sanitizedUrl = link.url
                                          .replaceAll(
                                          RegExp(r'[)\s]+$'),
                                          ''); // Remove any trailing ) or spaces
                                      Uri url = Uri.parse(
                                          sanitizedUrl); // Parse the sanitized URL

                                      try {
                                        if (await canLaunchUrl(url)) {
                                          await launchUrl(url,
                                              mode: LaunchMode
                                                  .externalApplication); // Open in external browser
                                        } else {
                                          print(
                                              "Could not launch URL: $sanitizedUrl");
                                        }
                                      } catch (e) {
                                        print(
                                            'Error launching URL: $e');
                                      }
                                    },
                                    text: anyFoodText,
                                    // The text containing the URL
                                    style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 16,
                                    ),
                                    linkStyle: TextStyle(
                                      color: Colors.blue,
                                      // Customize link color
                                      decoration: TextDecoration
                                          .underline, // Optional: underline links
                                    ),
                                  ),
                                ),
                              )),
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              top: 5,
              left: MediaQuery.of(context).size.width / 2 - 25,
              child: Container(
                width: 50,
                height: 50,
                decoration: const BoxDecoration(
                  color: Colors.white,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black12,
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: const Center(
                  child: Icon(Icons.keyboard_arrow_down),
                ),
              ),
            ),
          ],
        ),
      );
    });
  }

  Widget _buildBottomSheetpackaged(BuildContext context) {
    return DraggableScrollableSheet(
        initialChildSize: 0.5,
        maxChildSize: 0.8,
        minChildSize: 0.3,
        builder: (_, controller) => Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 20),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  child: GestureDetector(
                    onTap: () {
                      Get.back();
                    },
                    child: ClipPath(
                      clipper: _BottomSheetClipper(),
                      child: Container(
                        color: Colors.white,
                        child: ListView(
                          controller: controller,
                          children: [
                            const SizedBox(height: 50),
                            Center(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  const Padding(
                                    padding: EdgeInsets.only(left: 20),
                                    child: Text(
                                      "Comprehensive Analysis: ",
                                      style: TextStyle(
                                          fontSize: 18,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                  const SizedBox(height: 20),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 15),
                                    child: InkWell(
                                      onTap: () {
                                        showModalBottomSheet(
                                          context: context,
                                          isScrollControlled: true,
                                          backgroundColor: Colors.transparent,
                                          builder: (context) =>
                                              IngredientInformation(
                                            barcode: barcodeResult,
                                          ),
                                        );
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 15),
                                        width: AddSize.screenWidth,
                                        height: 60,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(8),
                                            border: Border.all(
                                                color: Colors.black)),
                                        child: const Center(
                                            child: Row(
                                          children: [
                                            Text("Ingredient Information"),
                                            Spacer(),
                                            Icon(Icons.arrow_forward_ios)
                                          ],
                                        )),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 15),
                                    child: InkWell(
                                      onTap: () {
                                        print("1");
                                        showModalBottomSheet(
                                          context: context,
                                          isScrollControlled: true,
                                          backgroundColor: Colors.transparent,
                                          builder: (context) =>
                                              Scannerbottomsheet(),
                                        );
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 15),
                                        width: AddSize.screenWidth,
                                        height: 60,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(8),
                                            border: Border.all(
                                                color: Colors.black)),
                                        child: Center(
                                            child: Row(
                                          children: [
                                            Text("Allergen"
                                                // "Allergen : "
                                                // "${widget.allergy?.replaceAll("[", "").replaceAll("]", "")}"
                                                ),
                                            const Spacer(),
                                            const Icon(Icons.arrow_forward_ios)
                                          ],
                                        )),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(
                                        horizontal: 15),
                                    child: InkWell(
                                      onTap: () {
                                        print("2");
                                        showModalBottomSheet(
                                          context: context,
                                          isScrollControlled: true,
                                          backgroundColor: Colors.transparent,
                                          builder: (context) =>
                                              const Consumption(),
                                        );
                                      },
                                      child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 15),
                                        width: AddSize.screenWidth,
                                        height: 60,
                                        decoration: BoxDecoration(
                                            borderRadius:
                                                BorderRadius.circular(8),
                                            border: Border.all(
                                                color: Colors.black)),
                                        child: const Center(
                                            child: Row(
                                          children: [
                                            Text(
                                                "Consumption Alert and Health Risk"),
                                            Spacer(),
                                            Icon(Icons.arrow_forward_ios)
                                          ],
                                        )),
                                      ),
                                    ),
                                  ),
                                  const SizedBox(
                                    height: 20,
                                  ),
                                ],
                              ),
                            ),
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 5,
                  left: MediaQuery.of(context).size.width / 2 - 25,
                  child: Container(
                    width: 50,
                    height: 50,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Icon(Icons.keyboard_arrow_down),
                    ),
                  ),
                ),
              ],
            ));
  }
}

class _BottomSheetClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    path.lineTo(0, 30);
    path.quadraticBezierTo(size.width / 2, 0, size.width, 30);
    path.lineTo(size.width, size.height);
    path.lineTo(0, size.height);
    path.close();
    return path;
  }

  @override
  bool shouldReclip(covariant CustomClipper<Path> oldClipper) {
    return false;
  }
}

class Scannerbottomsheet extends StatefulWidget {
  Scannerbottomsheet({super.key});

  @override
  State<Scannerbottomsheet> createState() => _ScannerbottomsheetState();
}

class _ScannerbottomsheetState extends State<Scannerbottomsheet> {
  String? barcodeResult;
  ModelBarcodeScanner model = ModelBarcodeScanner();

  Future<void> scanBarcode() async {
    print("sssssuuuuuuggggaaaaarrrrrr=====>>${sugar.toString()}");
    const usdaApiKey = 'AIzaSyCiDGfFN-tCfYrF52weQZ0Lbv8_UcmNbA4';
    const urlapi =
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

    try {
      final response = await http.post(
        Uri.parse('$urlapi?key=$usdaApiKey'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, dynamic>{
          "contents": [
            {
              "parts": [
                {
                  "text": """
                  I am a user with $health and I have $allergy allergies. I have these $health health conditions as part of my health profile. Also, please refer to:
                  
                  My weight: $weight
                  My height: $height
                  My gender: $Gender
                  My age: $age
                  My allergy: $allergy
                  My health: $health
                  
                 
                  
                  Name of the food: $carbohydrate1
                  
                  Don't provide me medical advice only data give by the allergy.
                  
                  Then, Please answer with detailed information by the example below:
                  
                  • Food dyes, including Blue 1 and Red 40, may cause health issues for you, including ADHD and other allergic reactions.
                  • The corn syrup and hydrogenated palm kernel oil may also be potential allergic reaction sources for you; please be aware.
                  • Additional Details
                  
                  Remove unnecessary asterisk symbols in results.
                  Remove my information; share only the results.
                """,
                },
              ]
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        barcodeData =
            responseData['candidates'][0]['content']['parts'][0]['text'];
        print("Extracted Text: $barcodeData");
      } else {
        print("Failed Response: ${response.body}");
        throw Exception('Failed to post data');
      }
    } catch (e) {
      print("Error: ${e.toString()}");
    }
  }

  @override
  void initState() {
    super.initState();
    scanBarcode();
    print("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
  }

  @override
  Widget build(BuildContext context) {
    "\n${sugar == model.product?.nutriments!.sugarsValue}}"
        "\n${energy == model.product?.nutriscoreData!.energyValue}}"
        "\n${carbohydrate == model.product?.nutriments!.carbohydratesValue}}"
        "\n${sugar == model.product?.nutriments!.sugarsValue}}"
        "\n${carbohydrate1 == model.product?.nutriments!.carbohydratesValue}}";
    print("object??????????${carbohydrate1}");

    return DraggableScrollableSheet(
        initialChildSize: 0.5,
        maxChildSize: 0.8,
        minChildSize: 0.3,
        builder: (_, controller) => Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(top: 20),
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  child: GestureDetector(
                    onTap: () {
                      Get.back();
                    },
                    child: ClipPath(
                      clipper: _BottomSheetClipper(),
                      child: Container(
                        color: Colors.white,
                        child: ListView(
                          controller: controller,
                          children: [
                            const SizedBox(height: 50),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(left: 20),
                                  child: Text(
                                    "Allergy : ${allergy?.replaceAll("[", "").replaceAll("]", "")}", //scanner
                                    style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                barcodeData == null
                                    ? const Center(
                                        child: CircularProgressIndicator(),
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.all(10.0),
                                        child: Text(barcodeData
                                            .toString()
                                            .replaceAll("*", "")
                                            .replaceAll("*", "")),
                                      )
                              ],
                            ),
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 5,
                  left: MediaQuery.of(context).size.width / 2 - 25,
                  child: Container(
                    width: 50,
                    height: 50,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Icon(Icons.keyboard_arrow_down),
                    ),
                  ),
                ),
              ],
            ));
  }
}

class IngredientInformation extends StatefulWidget {
  final String barcode; // Add barcode parameter

  IngredientInformation({super.key, required this.barcode});

  @override
  _IngredientInformationState createState() => _IngredientInformationState();
}

class _IngredientInformationState extends State<IngredientInformation> {
  bool _isLoading = true;
  String _error = '';
  String _ingredientData = ''; // To store product name
  Product? _product; // To store product details

  @override
  void initState() {
    super.initState();
    _fetchIngredientData();
  }

  Future<void> _fetchIngredientData() async {
    setState(() {
      _isLoading = true;
    });

    final url =
        'https://world.openfoodfacts.net/api/v2/product/${widget.barcode}?fields=product_name,nutriments,nutriscore_data';
    try {
      final response = await http.get(Uri.parse(url));

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        print("Response Body: ${response.body}");

        final model = ModelBarcodeScanner.fromJson(data);

        if (model.product != null) {
          setState(() {
            _product = model.product;
            _ingredientData =
                model.product?.productName ?? 'No product name available';
            _isLoading = false;
          });
        } else {
          setState(() {
            _error = 'No product found for this barcode';
            _isLoading = false;
          });
        }
      } else {
        setState(() {
          _error = 'Failed to load data';
          _isLoading = false;
        });
      }
    } catch (e) {
      setState(() {
        _error = 'An error occurred: $e';
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    if (_product == null || _product!.nutriments == null) {
      sugar = 'Failed to load data';
      energy = 'Failed to load data';
      carbohydrate = 'Failed to load data';
      carbohydrate1 = 'Failed to load data';
    } else {
      sugar =
          '${_product!.nutriments!.sugars ?? "N/A"} ${_product!.nutriments?.sugarsUnit ?? "N/A"}';

      energy =
          '${_product!.nutriments!.energyKcal ?? "N/A"} ${_product!.nutriments!.sugars ?? "N/A"}';

      carbohydrate =
          '${_product!.nutriments!.carbohydrates ?? "N/A"} ${_product!.nutriments?.carbohydratesUnit ?? "N/A"}';

      carbohydrate1 = '${_product!.productName ?? "N/A"}';
    }

    return DraggableScrollableSheet(
      initialChildSize: 0.5,
      maxChildSize: 0.8,
      minChildSize: 0.3,
      builder: (_, controller) => Stack(
        children: [
          Container(
            margin: const EdgeInsets.only(top: 20),
            decoration: const BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(30),
                topRight: Radius.circular(30),
              ),
            ),
            child: GestureDetector(
              onTap: () {
                Navigator.of(context).pop();
              },
              child: ClipPath(
                clipper: _BottomSheetClipper(),
                child: Container(
                  color: Colors.white,
                  child: ListView(
                    controller: controller,
                    padding: const EdgeInsets.all(20.0),
                    children: [
                      const SizedBox(height: 50),
                      _isLoading
                          ? const Center(child: CircularProgressIndicator())
                          : _error.isNotEmpty
                              ? Center(child: Text(_error))
                              : Padding(
                                  padding: const EdgeInsets.all(20.0),
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      const Text(
                                        "Ingredient Information",
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          fontSize: 14,
                                        ),
                                        textScaleFactor: 1.2,
                                      ),
                                      const SizedBox(height: 10),
                                      if (_product != null &&
                                          _product!.nutriments != null) ...[
                                        const SizedBox(height: 10),
                                        Text(
                                          " ● product Name:${_product!.productName.toString()}",
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14,
                                          ),
                                        ),

                                        Text(
                                          "● Sugars: ${_product!.nutriments!.sugars ?? 'N/A'} ${_product!.nutriments?.sugarsUnit ?? 'g'}",
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14,
                                          ),
                                        ),
                                        Text(
                                          "● Energy: ${_product!.nutriments!.energyKcal ?? 'N/A'} kcal",
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14,
                                          ),
                                        ),
                                        Text(
                                          "● Carbohydrates: ${_product!.nutriments!.carbohydrates ?? 'N/A'} ${_product!.nutriments?.carbohydratesUnit ?? 'g'}",
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14,
                                          ),
                                        ),
                                        Text(
                                          "● Ecoscore: ${_product!.ecoscoreGrade ?? 'N/A'}",
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14,
                                          ),
                                        ),
                                        Text(
                                          "● Ecoscore Grade: ${_product!.ecoscoreGrade ?? 'N/A'}",
                                          style: const TextStyle(
                                            fontWeight: FontWeight.w400,
                                            fontSize: 14,
                                          ),
                                        ),

                                        // Add more fields as needed
                                      ],
                                    ],
                                  ),
                                ),
                      const SizedBox(height: 20),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Positioned(
            top: 5,
            left: MediaQuery.of(context).size.width / 2 - 25,
            child: Container(
              width: 50,
              height: 50,
              decoration: const BoxDecoration(
                color: Colors.white,
                shape: BoxShape.circle,
                boxShadow: [
                  BoxShadow(
                    color: Colors.black12,
                    blurRadius: 8,
                  ),
                ],
              ),
              child: const Center(
                child: Icon(Icons.keyboard_arrow_down),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

///Consumption class in pop
class Consumption extends StatefulWidget {
  const Consumption({super.key});

  @override
  State<Consumption> createState() => _ConsumptionState();
}

class _ConsumptionState extends State<Consumption> {
  Future<void> ConsumptionAi() async {
    const usdaApiKey = 'AIzaSyCiDGfFN-tCfYrF52weQZ0Lbv8_UcmNbA4';
    const urlapi =
        'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent';

    try {
      final response = await http.post(
        Uri.parse('$urlapi?key=$usdaApiKey'),
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(<String, dynamic>{
          "contents": [
            {
              "parts": [
                {
                  "text": """
          I am a user with $health (health conditions) and I have $allergy allergies. I have these $health health conditions as part of my health profile. Also, please refer to:
          
          My weight: $weight
          My height: $height
          My gender: $Gender
          My age: $age
          
          Name of the food: ${carbohydrate1}
          
          Avoid giving medical advice; only provide data based on the allergy and health conditions mentioned.

          Please answer with detailed information in a format similar to the example below:
          
          • This pile of Skittles has a total calorie count of approximately 400 Calories. The sugar content exceeds the daily consumption limit of 36 grams for you, a biological male.
          • Consuming Skittles can worsen your diabetes situation and lead to a heavier burden on the body.
          • Consuming 400 Calories worth of Skittles can increase the risk of stroke. Be alert to your body conditions. Call an ambulance if necessary.
          • Additional Details
          
          If something is unknown or not applicable, do not include it in the response. Focus only on the relevant and known data.

          Remove unnecessary asterisk symbols in the results.
          Remove personal information; share only the relevant data.
          """
                }
              ]
            }
          ]
        }),
      );

      if (response.statusCode == 200) {
        final responseData = jsonDecode(response.body);
        Consumptiontest =
            responseData['candidates'][0]['content']['parts'][0]['text'];
        print("Extracted Text: $Consumptiontest");
      } else {
        print("Failed Response: ${response.body}");
        throw Exception('Failed to post data');
      }
    } catch (e) {
      print("Error: ${e.toString()}");
    }
  }

  @override
  void initState() {
    super.initState();
    ConsumptionAi();
  }

  Widget build(BuildContext context) {
    return DraggableScrollableSheet(
        initialChildSize: 0.5,
        maxChildSize: 0.8,
        minChildSize: 0.3,
        builder: (_, controller) => Stack(
              children: [
                Container(
                  margin: const EdgeInsets.only(
                      top: 20), // Adjust the margin for the small circle
                  decoration: const BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(30),
                      topRight: Radius.circular(30),
                    ),
                  ),
                  child: GestureDetector(
                    onTap: () {
                      Get.back();
                    },
                    child: ClipPath(
                      clipper: _BottomSheetClipper(),
                      child: Container(
                        color: Colors.white,
                        child: ListView(
                          controller: controller,
                          children: [
                            const SizedBox(height: 50), // Space for the circle
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              mainAxisAlignment: MainAxisAlignment.start,
                              children: [
                                const Padding(
                                  padding: EdgeInsets.only(left: 20),
                                  child: Text(
                                    "Consumption Alert and Health Risk",
                                    //scanner
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                                const SizedBox(
                                  height: 15,
                                ),
                                Consumptiontest == null
                                    ? const Center(
                                        child: CircularProgressIndicator(),
                                      )
                                    : Padding(
                                        padding: const EdgeInsets.all(10.0),
                                        child: Text(Consumptiontest.toString()
                                            .replaceAll("*", "")
                                            .replaceAll("*", "")),
                                      )
                              ],
                            ),
                            const SizedBox(height: 20),
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
                Positioned(
                  top: 5,
                  left: MediaQuery.of(context).size.width / 2 - 25,
                  child: Container(
                    width: 50,
                    height: 50,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black12,
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: const Center(
                      child: Icon(Icons.keyboard_arrow_down),
                    ),
                  ),
                ),
              ],
            ));
  }
}
