import 'dart:developer';
import 'dart:io';
import 'package:Safeplate/screen/home/singlepost.dart';
import 'package:Safeplate/screen/home/singleproduct_screen1.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_picker/image_picker.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../controller/profile_controller.dart';
import '../../model/like_post_model.dart';
import '../../model/mypostcommunity_model.dart';
import '../../repo/create_community_repo.dart';
import '../../repo/like_repo.dart';
import '../../repo/my_post_community_repo.dart';
import '../../widget/custom_textfield.dart';
import '../../widget/helper.dart';

class MyPostScreen extends StatefulWidget {
  const MyPostScreen({super.key});

  @override
  State<MyPostScreen> createState() => _MyPostScreenState();
}

class _MyPostScreenState extends State<MyPostScreen> {



  Rx<RxStatus> statusOfmypost = RxStatus.empty().obs;
  Rx<MyPostCommunity> model = MyPostCommunity().obs;
  Rx<RxStatus> statusOfmylike = RxStatus.empty().obs;
  Rx<LikePostModel> Likemodel = LikePostModel().obs;


  String? userName;

  void getData() async{
    SharedPreferences pref = await SharedPreferences.getInstance();
    userName = pref.getString("name");
    if (userName != null) {
      print(userName);  // This will print the value of userName, for example "ankur"
    } else {
      print("No username found");
    }
    myPostRepo().then((value) {
      model.value = value;
      if (value.success == true) {
        statusOfmypost.value = RxStatus.success();
      } else {
        statusOfmypost.value = RxStatus.error();
      }
    }).catchError((error) {
      statusOfmypost.value = RxStatus.error();
      log('Error in getFollower(): $error');
      // Handle the error as needed, e.g., show a toast message
      // showToast('Error fetching followers: $error');
    });
  }



  final profileController = Get.put(ProfileController());

  // void _showBottomSheet() {
  //   showModalBottomSheet(
  //     context: context,
  //     backgroundColor: Colors.transparent,
  //     isScrollControlled: true,
  //     shape: const RoundedRectangleBorder(
  //       borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
  //     ),
  //     builder: (context) {
  //       return Container(
  //         height: MediaQuery.of(context).size.height * 0.86,
  //         decoration: const BoxDecoration(
  //           borderRadius: BorderRadius.only(
  //             topRight: Radius.circular(30),
  //             topLeft: Radius.circular(30),
  //           ),
  //           color: Color(0xff75D051),
  //         ),
  //         child: Padding(
  //           padding: const EdgeInsets.symmetric(horizontal: 18.0,vertical: 16),
  //           child: SingleChildScrollView(
  //             child: Form(
  //               key: _formkey,
  //               child: Column(
  //                 crossAxisAlignment: CrossAxisAlignment.start,
  //                 mainAxisSize: MainAxisSize.min,
  //                 children: [
  //                   SizedBox(height: Get.height * 0.02,),
  //                   Text(
  //                     'Submit a piece',
  //                     style: GoogleFonts.roboto(
  //                       fontSize: 24,
  //                       fontWeight: FontWeight.w500,
  //                       color: Colors.white,
  //                     ),
  //                   ),
  //                   SizedBox(height: Get.height * 0.03),
  //                   Text(
  //                     "Title",
  //                     style: GoogleFonts.roboto(
  //                       fontSize: 15,
  //                       fontWeight: FontWeight.w500,
  //                       color: Colors.white,
  //                     ),
  //                   ),
  //                   SizedBox(height: Get.height * 0.006),
  //                   CommonTextFieldWidget(
  //                      controller: titleController,
  //                     textInputAction: TextInputAction.next,
  //                     hint: 'Enter Your Title',
  //                     validator: (value) {
  //                       if (value!.trim().isEmpty) {
  //                         return 'Title is required'.tr;
  //                       } else if (value.length >= 30) {
  //                         return 'Title cannot exceed 30 characters'.tr;
  //                       }
  //                       else if (RegExp(r'(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])').hasMatch(value)) {
  //                         return 'Title is not accept in emoji'.tr;
  //                       }
  //                       return null;
  //                     },
  //                   ),
  //                   SizedBox(height: Get.height * 0.02),
  //                   Text(
  //                     "Caption",
  //                     style: GoogleFonts.roboto(
  //                       fontSize: 15,
  //                       fontWeight: FontWeight.w500,
  //                       color: Colors.white,
  //                     ),
  //                   ),
  //                   SizedBox(height: Get.height * 0.006),
  //                   CommonTextFieldWidget(
  //                     controller: captionController,
  //                     textInputAction: TextInputAction.next,
  //                     hint: 'Caption',
  //                     validator: (value) {
  //                       if (value!.trim().isEmpty
  //                           // || RegExp(r"\s").hasMatch(captionController.text)
  //                       ) {
  //                         return 'Caption is required'.tr;
  //                       } else if (value.length >= 100) {
  //                         return 'Caption cannot exceed 30 characters'.tr;
  //                       }
  //                       return null;
  //                       // if (value!.isEmpty) {
  //                       //   return "Caption is required";
  //                       // } else {
  //                       //   return null;
  //                       // }
  //                     },
  //                   ),
  //                   SizedBox(height: Get.height * 0.02),
  //                   Text(
  //                     "Message",
  //                     style: GoogleFonts.roboto(
  //                       fontSize: 15,
  //                       fontWeight: FontWeight.w500,
  //                       color: Colors.white,
  //                     ),
  //                   ),
  //                   SizedBox(height: Get.height * 0.006),
  //                   CommonTextFieldWidget(
  //                     controller: messageController,
  //                     maxLines: 8,
  //                     minLines: 4,
  //                     textInputAction: TextInputAction.next,
  //                     hint: 'Submit Your Message',
  //                     validator: (value) {
  //                       if (value!.isEmpty
  //                           // || RegExp(r"\s").hasMatch(messageController.text)
  //                       ) {
  //                         return "Message is required";
  //                       }else if (value.length >= 500) {
  //                         return 'Cannot exceed 50 characters'.tr;
  //                       }
  //
  //                         return null;
  //
  //                     },
  //                   ),
  //                   SizedBox(height: Get.height * 0.02),
  //                   Text(
  //                     "Upload Photo",
  //                     style: GoogleFonts.roboto(
  //                       fontSize: 15,
  //                       fontWeight: FontWeight.w500,
  //                       color: Colors.white,
  //                     ),
  //                   ),
  //                   SizedBox(height: Get.height * 0.006),
  //                   GestureDetector(
  //                     onTap: (){
  //                       setState(() {
  //                         showDialog(
  //                           context: context,
  //                           builder: (BuildContext context) {
  //                             return Dialog(
  //                               elevation: 0,
  //                               shape: RoundedRectangleBorder(
  //                                 borderRadius: BorderRadius.circular(12),
  //                               ),
  //                               child: Padding(
  //                                 padding: const EdgeInsets.symmetric(horizontal:26,vertical: 18),
  //                                 child: Column(
  //                                   crossAxisAlignment: CrossAxisAlignment.start,
  //                                   mainAxisSize: MainAxisSize.min,
  //                                   children: <Widget>[
  //                                     Text("Choose Any One:",style: GoogleFonts.roboto(
  //                                         fontSize: 16,
  //                                         fontWeight: FontWeight.w500,
  //                                         color:Colors.black),),
  //
  //                                     SizedBox(height: Get.height*0.04,),
  //                                     Padding(
  //                                       padding: const EdgeInsets.symmetric(horizontal: 16),
  //                                       child: Row(
  //                                         mainAxisAlignment: MainAxisAlignment.spaceBetween,
  //                                         children: [
  //                                           InkWell(
  //                                             onTap: (){
  //                                               setState(() {
  //
  //                                               });
  //                                               _pickImageFromCamera();
  //                                               Get.back();
  //                                             },
  //                                             child: Column(
  //                                               crossAxisAlignment: CrossAxisAlignment.center,
  //                                               mainAxisAlignment: MainAxisAlignment.center,
  //                                               children: [
  //                                                 // Icon(Icons.camera_rear),
  //                                                 Image.asset("assets/icons/camera.png",height: 24,width: 24,),
  //                                                 Text("Camera",style: GoogleFonts.roboto(
  //                                                     fontSize: 15,
  //                                                     fontWeight: FontWeight.w400,
  //                                                     color:Colors.black),),
  //                                               ],
  //                                             ),
  //                                           ),
  //                                           InkWell(
  //                                             onTap: (){
  //                                               setState(() {
  //
  //                                               });
  //                                               _pickImageFromGallery();
  //                                               Get.back();
  //                                             },
  //                                             child: Column(
  //                                               crossAxisAlignment: CrossAxisAlignment.center,
  //                                               mainAxisAlignment: MainAxisAlignment.center,
  //                                               children: [
  //                                                 Image.asset("assets/icons/gallery.png",height: 24,width: 24,),
  //                                                 Text("Gallery",style: GoogleFonts.roboto(
  //                                                     fontSize: 15,
  //                                                     fontWeight: FontWeight.w400,
  //                                                     color:Colors.black),),
  //                                               ],
  //                                             ),
  //                                           )
  //                                         ],
  //                                       ),
  //                                     ),
  //                                     SizedBox(height: Get.height*0.04,),
  //                                   ],
  //                                 ),
  //                               ),
  //                             );
  //                           },
  //                         );
  //                       });
  //
  //                     },
  //                     child:
  //                     Container(
  //                       width: Get.width,
  //                       height: Get.height * 0.14,
  //                       decoration: BoxDecoration(
  //                         borderRadius: BorderRadius.circular(10),
  //                         color: Colors.white,
  //                       ),
  //                       child: _image == null
  //                           ?  Column(
  //                           mainAxisAlignment: MainAxisAlignment.center,
  //                           crossAxisAlignment: CrossAxisAlignment.center,
  //                           children: [
  //                             Image.asset(
  //                               "assets/icons/upload.png",
  //                               height: 36,
  //                               width: 36,
  //                             ),
  //                             Text(
  //                               "Upload Image",
  //                               style: GoogleFonts.roboto(
  //                                 fontSize: 14,
  //                                 fontWeight: FontWeight.w400,
  //                                 color: Colors.black,
  //                               ),
  //                             ),
  //                           ],
  //                         )
  //                           : Image.file(_image!,fit: BoxFit.cover,),
  //                       // child: Column(
  //                       //   mainAxisAlignment: MainAxisAlignment.center,
  //                       //   crossAxisAlignment: CrossAxisAlignment.center,
  //                       //   children: [
  //                       //     Image.asset(
  //                       //       "assets/icons/upload.png",
  //                       //       height: 36,
  //                       //       width: 36,
  //                       //     ),
  //                       //     Text(
  //                       //       "Upload Image",
  //                       //       style: GoogleFonts.roboto(
  //                       //         fontSize: 14,
  //                       //         fontWeight: FontWeight.w400,
  //                       //         color: Colors.black,
  //                       //       ),
  //                       //     ),
  //                       //   ],
  //                       // ),
  //                     ),
  //                   ),
  //                   SizedBox(height: Get.height * 0.04,),
  //                   ElevatedButton(
  //                       onPressed: () async {
  //                         if (_formkey.currentState!.validate() && _validateImage()) {
  //                           createCommunityRepo(
  //                              image:_image,
  //                             title:titleController.text,
  //                               name: usernaam,//nameController.text,
  //                               context: context,
  //                               message: messageController.text,
  //                               caption: captionController.text
  //
  //                           ).then((value) {
  //                             if(value.success == true){
  //                               print("data${value.message}");
  //                               showToast(value.message);
  //                               getData();
  //                               Get.back();
  //                               messageController.clear();captionController.clear();
  //                               titleController.clear();
  //
  //                             }
  //                             else {
  //                               print("data>>>>>>>");
  //                               showToast(value.message);
  //                             }
  //                           }
  //
  //
  //
  //                           );
  //                         }
  //                       },
  //                       style: ElevatedButton.styleFrom(
  //
  //                         minimumSize: Size(Get.width, 50),
  //                         backgroundColor: Color(0xffFBB742),
  //                         elevation: 0,
  //                         shape: RoundedRectangleBorder(
  //                             borderRadius: BorderRadius.circular(12)),
  //                       ),
  //                       child: Text("Submit".toUpperCase(),
  //                           style: GoogleFonts.roboto(
  //                               fontWeight: FontWeight.w700,
  //                               color: Colors.white,
  //                               letterSpacing: .5,
  //                               fontSize: 20))),
  //                   SizedBox(height: Get.height * 0.02),
  //                 ],
  //               ),
  //             ),
  //           ),
  //         ),
  //       );
  //     },
  //   );
  // }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getData();
  }

  RxInt refreshInt = 0.obs;

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.sizeOf(context).height;
    var width = MediaQuery.sizeOf(context).width;
    return Scaffold(
        appBar: AppBar(
          toolbarHeight: 80,
          elevation: 0,
          titleSpacing: 0,
          backgroundColor: const Color(0xff75D051),
          leading: IconButton(
            onPressed: () {
              Get.back();
            },
            icon: const Icon(
              Icons.arrow_back_ios,
              color: Colors.white,
            ),
          ),
          title: Text(
            "My Post",
            style: GoogleFonts.roboto(
                fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white),
          ),
          actions: [
            Padding(
              padding: const EdgeInsets.all(24.0),
              child: InkWell(
                onTap: () {
                  showModalBottomSheet(
                      context: context,
                      backgroundColor: Colors.transparent,
                      isScrollControlled: true,
                      shape: const RoundedRectangleBorder(
                        borderRadius: BorderRadius.vertical(top: Radius.circular(25.0)),
                      ),
                      builder: (context) {
                        return Popbottom();
                      }

                  );
                },
                child: Container(
                  decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(8),
                      color: Colors.white),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 14),
                    child: Center(
                      child: Text(
                        "Create Post",
                        style: GoogleFonts.roboto(
                            fontSize: 14,
                            fontWeight: FontWeight.w500,
                            color: Colors.black),
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
        body: SafeArea(
          child: SingleChildScrollView(
            child: RefreshIndicator(
              onRefresh: ()async{
                getData();
              },
              child: Padding(
                padding:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                child: Obx(() {
                  return statusOfmypost.value.isSuccess
                      ? Column(
                    children: [
                      SizedBox(
                        height: height * 0.01,
                      ),
                      Container(
                        decoration: BoxDecoration(
                            color: const Color(0xffE9F7E3),
                            borderRadius: BorderRadius.circular(2)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 16),
                          child: Row(
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xff75D051), width: 3), // Green border with width 2
                                  borderRadius: BorderRadius.all(Radius.circular(40)),
                                ),
                                child: ClipRRect(
                                    borderRadius: BorderRadius.all(Radius.circular(40)),
                                    child:
                                    Image.network(
                                      "${userimage}",
                                      height: 60,
                                      width: 60,
                                      fit: BoxFit.fill,
                                      loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                        if (loadingProgress == null) {
                                          return child;
                                        } else {
                                          return Center(
                                            child: CircularProgressIndicator(
                                              value: loadingProgress.expectedTotalBytes != null
                                                  ? loadingProgress.cumulativeBytesLoaded / (loadingProgress.expectedTotalBytes ?? 1)
                                                  : null,
                                            ),
                                          );
                                        }
                                      },
                                      errorBuilder: (BuildContext context, Object exception, StackTrace? stackTrace) {
                                        return Image.asset(
                                          "assets/icons/addimage.png",
                                          fit: BoxFit.cover,
                                          height: 60,
                                          width: 60,
                                        );
                                      },
                                    )
                                  // CachedNetworkImage(
                                  //   height: 71,
                                  //   width: 71,
                                  //   imageUrl: "http://207.148.68.65/api${profileController.image}",
                                  //   fit: BoxFit.fill,
                                  //   errorWidget: (context, url, error) => Image.asset(
                                  //     "assets/icons/addimage.png",
                                  //     fit: BoxFit.cover,
                                  //   ),
                                  // ),
                                ),
                              ),
                              SizedBox(width: width * 0.04),
                              SizedBox(
                                width: Get.width*0.57,
                                child: Text(
                                  // "Welcome ${userName}!".replaceAll("\"", ""),
                                  "Welcome ${usernaam}!",
                                  style: GoogleFonts.roboto(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.black),
                                  softWrap: true,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: height * 0.036),
                      model.value.post!.isNotEmpty?
                      ListView.builder(
                        physics: const NeverScrollableScrollPhysics(),
                        shrinkWrap: true,
                        itemCount: model.value.post!.length,
                        itemBuilder: (context, index) {
                          DateTime dateTime = DateTime.parse(model
                              .value.post![index].createdAt
                              .toString());
                          String formattedDate =
                          DateFormat('yyyy dd MMMM').format(dateTime);
                          return Padding(
                            padding: const EdgeInsets.only(bottom: 26),
                            child: InkWell(
                              onTap: () {
                                //  dynamic data = 66b45f8609648d3493847258 ;
                                print("IDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDDD${model.value.post![index].sId.toString()}");
                                // Get.toNamed(SinglePostScreen.route, id: model.value.post![index].sId,);
                                Get.to(SinglePostScreen1(id:model.value.post![index].sId.toString(),
                                    name: model.value.post![index].name.toString(),
                                    postImage: model.value.post![index].postimage.toString(),
                                    title:model.value.post![index].title.toString()
                                ));
                                // Get.to(()=>SinglePostScreen(
                                //     id: model.value.post![index].sId.toString(),
                                //
                                // )
                                // );
                                // Get.toNamed(SinglePostScreen.route,arguments: model.value.post![index].sId);
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                    borderRadius:
                                    BorderRadius.circular(8),
                                    color: Colors.white),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 20),
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          ClipRRect(
                                              borderRadius:
                                              BorderRadius.all(Radius.circular(20)),
                                              child:   Image.network(
                                                "${userimage}",
                                                height: 40,
                                                width: 40,
                                                fit: BoxFit.fill,
                                                loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                                  if (loadingProgress == null) {
                                                    return child;
                                                  } else {
                                                    return Center(
                                                      child: CircularProgressIndicator(
                                                        value: loadingProgress.expectedTotalBytes != null
                                                            ? loadingProgress.cumulativeBytesLoaded / (loadingProgress.expectedTotalBytes ?? 1)
                                                            : null,
                                                      ),
                                                    );
                                                  }
                                                },
                                                errorBuilder: (BuildContext context, Object exception, StackTrace? stackTrace) {
                                                  return Image.asset(
                                                    "assets/icons/addimage.png",
                                                    fit: BoxFit.cover,
                                                    height: 40,
                                                    width: 40,
                                                  );
                                                },
                                              )
                                            // CachedNetworkImage(
                                            //   height: 40,
                                            //   width: 40,
                                            //   imageUrl:
                                            //   "http://207.148.68.65/api${profileController.image}",
                                            //   fit: BoxFit.fill,
                                            //   errorWidget: (context, url, error) =>
                                            //       Image.asset(
                                            //         "assets/icons/addimage.png",
                                            //         fit: BoxFit.cover,
                                            //       ),
                                            // ),
                                          ),
                                          SizedBox(
                                            width: width * 0.06,
                                          ),
                                          Text(
                                            model.value.post![index].name.toString(),
                                            style: GoogleFonts.roboto(
                                                fontSize: 16,
                                                fontWeight:
                                                FontWeight.w500,
                                                color: Colors.black),
                                          ),
                                          const Spacer(),
                                          IconButton(
                                              onPressed: () {
                                                addToLike(productId: model.value.post![index].sId.toString(),
                                                )
                                                    .then((value) {
                                                  Likemodel.value = value;
                                                  if (value.success ==
                                                      true) {
                                                    // showToast(value.message);
                                                    statusOfmylike.value = RxStatus.success();
                                                    getData();
                                                  } else {
                                                    showToast(
                                                        value.message);
                                                    statusOfmylike.value =
                                                        RxStatus.error();
                                                  }
                                                });
                                              },
                                              icon: model.value.post![index].liked ==
                                                  false
                                                  ? Image.asset(
                                                "assets/icons/dislike.png",
                                                height: 22,
                                                width: 22,
                                                color: const Color(
                                                    0xffEF535E),
                                              )
                                                  : SvgPicture.asset(
                                                "assets/icons/fillheart.svg",
                                                height: 22,
                                                width: 22,
                                              )
                                            //Icon(Icons.heart_broken,color: Colors.red,size: 22,)
                                          )
                                        ],
                                      ),
                                      SizedBox(
                                        height: height * 0.016,
                                      ),
                                      ClipRRect(
                                          borderRadius:  BorderRadius.circular(10),
                                          child:
                                          Image.network(
                                            "${model.value.post![index].postimage}",
                                            height: 160,
                                            width: Get.width,
                                            fit: BoxFit.fill,
                                            loadingBuilder: (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                              if (loadingProgress == null) {
                                                return child;
                                              } else {
                                                return Center(
                                                  child: CircularProgressIndicator(
                                                    value: loadingProgress.expectedTotalBytes != null
                                                        ? loadingProgress.cumulativeBytesLoaded / (loadingProgress.expectedTotalBytes ?? 1)
                                                        : null,
                                                  ),
                                                );
                                              }
                                            },
                                            errorBuilder: (BuildContext context, Object exception, StackTrace? stackTrace) {
                                              return Image.asset(
                                                "assets/icons/addimage.png",
                                                fit: BoxFit.fill,
                                                height: 200,
                                                width: Get.width,
                                              );
                                            },
                                          )
                                        // CachedNetworkImage(
                                        //   height: 200,
                                        //   width: Get.width,
                                        //   imageUrl:
                                        //   "http://207.148.68.65/api${model.value.post![index].postimage}",
                                        //   fit: BoxFit.fill,
                                        //   errorWidget: (context, url, error) =>
                                        //       SizedBox(
                                        //         height: 30,
                                        //         width: 30,
                                        //         child: Image.asset(
                                        //           "assets/icons/addimage.png",
                                        //           fit: BoxFit.cover,
                                        //         ),
                                        //       ),
                                        // ),
                                      ),

                                      SizedBox(
                                        height: height * 0.016,
                                      ),
                                      model.value.post![index].title==null? SizedBox(height: 0,width: 0,):  Text(
                                        model.value.post![index].title.toString(),
                                        style: GoogleFonts.roboto(
                                            fontSize: 16,
                                            fontWeight: FontWeight.w500,
                                            color: Colors.black),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        softWrap: true,),
                                      SizedBox(height: height * 0.01),
                                      model.value.post![index].caption==null?const SizedBox(height: 0,width: 0,):    Text(
                                        model.value.post![index].caption
                                            .toString(),
                                        style: GoogleFonts.roboto(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w400,
                                            color: Colors.black),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        softWrap: true,),
                                      SizedBox(height: height * 0.01),
                                      model.value.post![index].message== null?const SizedBox(height: 0,width: 0,):  Text(
                                        model.value.post![index].message
                                            .toString(),
                                        style: GoogleFonts.roboto(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w400,
                                            color: Colors.black),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 2,softWrap: true,
                                      ),

                                      Row(
                                        children: [
                                          Text(
                                            formattedDate,
                                            style: GoogleFonts.outfit(
                                                fontSize: 16,
                                                fontWeight:
                                                FontWeight.w400,
                                                color: const Color(0xff273B4A)),
                                          ),
                                          const Spacer(),
                                          IconButton(
                                              onPressed: () {
                                                Get.to(SinglePostScreen(id:model.value.post![index].sId.toString(),));
                                              },
                                              icon: Image.asset(
                                                "assets/icons/comment.png",
                                                height: 22,
                                                width: 22,
                                                color: Colors.black,
                                              )),
                                          IconButton(
                                              onPressed: () async{
                                                await Share.share(
                                                    'https://wallpaperaccess.com/full/1401021.jpg',
                                                    subject: 'Welcome Message');
                                              },
                                              icon: Image.asset(
                                                "assets/icons/share.png",
                                                height: 22,
                                                width: 22,
                                                color: Colors.black,
                                              ))
                                        ],
                                      ),

                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ):Text("No Post Available")
                    ],
                  )
                      : Padding(
                    padding: const EdgeInsets.only(top: 300),
                    child: Align(
                        alignment: Alignment.center,
                        child: Center(child: CircularProgressIndicator())),
                  );
                }),
              ),
            ),
          ),
        ));
  }
}


class Popbottom extends StatefulWidget {
  const Popbottom({super.key});

  @override
  State<Popbottom> createState() => _PopbottomState();


}

class _PopbottomState extends State<Popbottom> {
  final _formkey = GlobalKey<FormState>();
  TextEditingController titleController = TextEditingController();
  TextEditingController captionController = TextEditingController();
  TextEditingController messageController = TextEditingController();
  bool _validateImage() {
    if (_image == null) {
      showToast("Image is required");
      return false;
    }
    return true;
  }
  File? _image;
  final ImagePicker _picker = ImagePicker();

  Future<void> _pickImageFromGallery() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    } else {
      log('No image selected.');
    }
  }

  Future<void> _pickImageFromCamera() async {
    final pickedFile = await _picker.pickImage(source: ImageSource.camera);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
    } else {
      log('No image selected.');
    }
  }

  String? userName;
  Rx<RxStatus> statusOfmypost = RxStatus.empty().obs;
  Rx<MyPostCommunity> model = MyPostCommunity().obs;
  Rx<RxStatus> statusOfmylike = RxStatus.empty().obs;
  Rx<LikePostModel> Likemodel = LikePostModel().obs;
  void getData() async{
    SharedPreferences pref = await SharedPreferences.getInstance();
    userName = pref.getString("name");
    if (userName != null) {
      print(userName);  // This will print the value of userName, for example "ankur"
    } else {
      print("No username found");
    }
    myPostRepo().then((value) {
      model.value = value;
      if (value.success == true) {
        statusOfmypost.value = RxStatus.success();
      } else {
        statusOfmypost.value = RxStatus.error();
      }
    }).catchError((error) {
      statusOfmypost.value = RxStatus.error();
      log('Error in getFollower(): $error');
      // Handle the error as needed, e.g., show a toast message
      // showToast('Error fetching followers: $error');
    });
  }
  @override
  void initState() {
    getData();
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return    Container(
      height: MediaQuery.of(context).size.height * 0.86,
      decoration: const BoxDecoration(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(30),
          topLeft: Radius.circular(30),
        ),
        color: Color(0xff75D051),
      ),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 18.0,vertical: 16),
        child: SingleChildScrollView(
          child: Form(
            key: _formkey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                SizedBox(height: Get.height * 0.02,),
                Text(
                  'Submit a piece',
                  style: GoogleFonts.roboto(
                    fontSize: 24,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: Get.height * 0.03),
                Text(
                  "Title",
                  style: GoogleFonts.roboto(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: Get.height * 0.006),
                CommonTextFieldWidget(
                  controller: titleController,
                  textInputAction: TextInputAction.next,
                  hint: 'Enter Your Title',
                  validator: (value) {
                    if (value!.trim().isEmpty) {
                      return 'Title is required'.tr;
                    } else if (value.length >= 30) {
                      return 'Title cannot exceed 30 characters'.tr;
                    }
                    else if (RegExp(r'(\u00a9|\u00ae|[\u2000-\u3300]|\ud83c[\ud000-\udfff]|\ud83d[\ud000-\udfff]|\ud83e[\ud000-\udfff])').hasMatch(value)) {
                      return 'Title is not accept in emoji'.tr;
                    }
                    return null;
                  },
                ),
                SizedBox(height: Get.height * 0.02),
                Text(
                  "Caption",
                  style: GoogleFonts.roboto(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: Get.height * 0.006),
                CommonTextFieldWidget(
                  controller: captionController,
                  textInputAction: TextInputAction.next,
                  hint: 'Caption',
                  validator: (value) {
                    if (value!.trim().isEmpty
                    // || RegExp(r"\s").hasMatch(captionController.text)
                    ) {
                      return 'Caption is required'.tr;
                    } else if (value.length >= 100) {
                      return 'Caption cannot exceed 30 characters'.tr;
                    }
                    return null;
                    // if (value!.isEmpty) {
                    //   return "Caption is required";
                    // } else {
                    //   return null;
                    // }
                  },
                ),
                SizedBox(height: Get.height * 0.02),
                Text(
                  "Message",
                  style: GoogleFonts.roboto(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: Get.height * 0.006),
                CommonTextFieldWidget(
                  controller: messageController,
                  maxLines: 8,
                  minLines: 4,
                  textInputAction: TextInputAction.next,
                  hint: 'Submit Your Message',
                  validator: (value) {
                    if (value!.isEmpty
                    // || RegExp(r"\s").hasMatch(messageController.text)
                    ) {
                      return "Message is required";
                    }else if (value.length >= 500) {
                      return 'Cannot exceed 50 characters'.tr;
                    }

                    return null;

                  },
                ),
                SizedBox(height: Get.height * 0.02),
                Text(
                  "Upload Photo",
                  style: GoogleFonts.roboto(
                    fontSize: 15,
                    fontWeight: FontWeight.w500,
                    color: Colors.white,
                  ),
                ),
                SizedBox(height: Get.height * 0.006),
                GestureDetector(
                  onTap: (){
                    setState(() {
                      showDialog(
                        context: context,
                        builder: (BuildContext context) {
                          return Dialog(
                            elevation: 0,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            child: Padding(
                              padding: const EdgeInsets.symmetric(horizontal:26,vertical: 18),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisSize: MainAxisSize.min,
                                children: <Widget>[
                                  Text("Choose Any One:",style: GoogleFonts.roboto(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500,
                                      color:Colors.black),),

                                  SizedBox(height: Get.height*0.04,),
                                  Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 16),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      children: [
                                        InkWell(
                                          onTap: (){
                                            setState(() {

                                            });
                                            _pickImageFromCamera();
                                            Get.back();
                                          },
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              // Icon(Icons.camera_rear),
                                              Image.asset("assets/icons/camera.png",height: 24,width: 24,),
                                              Text("Camera",style: GoogleFonts.roboto(
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.w400,
                                                  color:Colors.black),),
                                            ],
                                          ),
                                        ),
                                        InkWell(
                                          onTap: (){
                                            setState(() {

                                            });
                                            _pickImageFromGallery();
                                            Get.back();
                                          },
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.center,
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            children: [
                                              Image.asset("assets/icons/gallery.png",height: 24,width: 24,),
                                              Text("Gallery",style: GoogleFonts.roboto(
                                                  fontSize: 15,
                                                  fontWeight: FontWeight.w400,
                                                  color:Colors.black),),
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: Get.height*0.04,),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    });

                  },
                  child:
                  Container(
                    width: Get.width,
                    height: Get.height * 0.14,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(10),
                      color: Colors.white,
                    ),
                    child: _image == null
                        ?  Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Image.asset(
                          "assets/icons/upload.png",
                          height: 36,
                          width: 36,
                        ),
                        Text(
                          "Upload Image",
                          style: GoogleFonts.roboto(
                            fontSize: 14,
                            fontWeight: FontWeight.w400,
                            color: Colors.black,
                          ),
                        ),
                      ],
                    )
                        : Image.file(_image!,fit: BoxFit.cover,),
                    // child: Column(
                    //   mainAxisAlignment: MainAxisAlignment.center,
                    //   crossAxisAlignment: CrossAxisAlignment.center,
                    //   children: [
                    //     Image.asset(
                    //       "assets/icons/upload.png",
                    //       height: 36,
                    //       width: 36,
                    //     ),
                    //     Text(
                    //       "Upload Image",
                    //       style: GoogleFonts.roboto(
                    //         fontSize: 14,
                    //         fontWeight: FontWeight.w400,
                    //         color: Colors.black,
                    //       ),
                    //     ),
                    //   ],
                    // ),
                  ),
                ),
                SizedBox(height: Get.height * 0.04,),
                ElevatedButton(
                    onPressed: () async {
                      if (_formkey.currentState!.validate() && _validateImage()) {
                        createCommunityRepo(
                            image:_image,
                            title:titleController.text,
                            name: usernaam,//nameController.text,
                            context: context,
                            message: messageController.text,
                            caption: captionController.text

                        ).then((value) {
                          if(value.success == true){
                            print("data${value.message}");
                            showToast(value.message);
                            getData();
                            // Get.to(MyPostScreen());
                            Get.back();
                            messageController.clear();captionController.clear();
                            titleController.clear();

                          }
                          else {
                            print("data>>>>>>>");
                            showToast(value.message);
                          }
                        }



                        );
                      }
                    },
                    style: ElevatedButton.styleFrom(

                      minimumSize: Size(Get.width, 50),
                      backgroundColor: Color(0xffFBB742),
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12)),
                    ),
                    child: Text("Submit".toUpperCase(),
                        style: GoogleFonts.roboto(
                            fontWeight: FontWeight.w700,
                            color: Colors.white,
                            letterSpacing: .5,
                            fontSize: 20))),
                SizedBox(height: Get.height * 0.02),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

