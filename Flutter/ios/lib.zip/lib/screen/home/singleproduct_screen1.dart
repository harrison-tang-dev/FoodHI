import 'dart:developer';
import 'package:Safeplate/controller/profile_controller.dart';
import 'package:Safeplate/repo/reply_repo.dart';
import 'package:Safeplate/screen/home/my_post.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';
import '../../model/add_comment_model.dart';
import '../../model/reply_model.dart';
import '../../model/single_post_model.dart';
import '../../repo/add_comment_repo.dart';
import '../../repo/block_user_repo.dart';
import '../../repo/single_post_repo.dart';
import '../../widget/Api_url.dart';
import '../../widget/helper.dart';

import 'dart:convert';
import 'package:http/http.dart' as http;

class SinglePostScreen1 extends StatefulWidget {
  String? id;
  String? name;
  String? postImage;
  String? title;

  SinglePostScreen1({super.key, this.id, this.name, this.postImage, this.title});

  static var route = "/singlePostScreen";

  @override
  State<SinglePostScreen1> createState() => _SinglePostScreen1State();
}

class _SinglePostScreen1State extends State<SinglePostScreen1> {
  Rx<SinglePostModel> single = SinglePostModel().obs;
  Rx<RxStatus> statusOfSingle = RxStatus.empty().obs;
  final List<String> abusiveWords = [
    'abuse',
    'ass',
    'asshole',
    'bastard',
    'bitch',
    'bloody',
    'bullshit',
    'butthole',
    'crap',
    'cunt',
    'damn',
    'dick',
    'douche',
    'fag',
    'faggot',
    'fuck',
    'fucker',
    'fuckface',
    'goddamn',
    'idiot',
    'jerk',
    'kill yourself',
    'loser',
    'moron',
    'nigga',
    'nigger',
    'piss',
    'prick',
    'pussy',
    'scumbag',
    'shit',
    'shithead',
    'slut',
    'twat',
    'whore',
    'wanker',
    'dumbass',
    'dumbfuck',
    'jackass',
    'knobhead',
    'piss off',
    'freak',
    'tool',
    'cocksucker',
    'motherfucker',
    'bimbo',
    'chump',
    'clown',
    'dickhead',
    'fart',
    'freakshow',
    'gash',
    'git',
    'harlot',
    'hick',
    'ho',
    'imbecile',
    'incompetent',
    'loser',
    'lowlife',
    'moron',
    'numbnuts',
    'old hag',
    'pansy',
    'pisshead',
    'pissant',
    'rat',
    'retard',
    'scab',
    'scrub',
    'skank',
    'slutty',
    'snot',
    'snot-nose',
    'suck',
    'sucker',
    'trollop',
    'twit',
    'twitface',
    'yob',
    'douchebag',
    'fartknocker',
    'clit',
    'shitbag',
    'dickhead',
    'asswipe',
    'fud',
    'sore loser',
    'fucktard',
    'freakin',
    'cuntface',
    'piss ant',
    'fucker',
    'cock',
    'whiny',
    'sucker',
    'cocksucker',
    'dumbass',
    'tool',
    'lazy',
    'slut',
    'putz',
    'gook',
    'chink',
    'paki',
    'wetback',
    'kike',
    'bimbo',
    'nappy',
    'spic',
    'dyke',
    'bastard',
    'retard',
    'weirdo',
    'bitchass',
    'dumbfuck',
    'freakin',
    'gutter',
    'fartknocker',
    'dumbass',
    'idiot',
    'twat',
    'whore',
    'knobhead',
    'looser',
    'crackhead',
    'clown',
    'retard',
    'pansy',
    'douche',
    'scumbag',
    'sneak',
    'jock',
    'coward',
    'pigs',
    'fucker',
    'fatass',
    'cuntface',
    'freakin',
    'wuss',
    'freakshow',
    'hussy',
    'cocksucker',
    'slutbag',
    'skank',
    'rat',
    'douche',
    'toad',
    'runt',
    'lamebrain',
    'piss',
    'loser',
    'skank',
    'bimbo',
    'jackass',
    'cock',
    'blowjob',
    'blowhard',
    'muffdiver',
  ];

  String? _checkForAbusiveWords(String message) {
    for (String word in abusiveWords) {
      if (message.toLowerCase().contains(word.toLowerCase())) {
        return 'Your message contains abusive language';
      }
    }
    return null; // No abusive words found
  }

  final profileController = Get.put(ProfileController());

  singlePost() {
    singlePostRepo(id: widget.id.toString(), context: context).then((value) {
      log("response.body.....    ${value}");
      single.value = value;
      if (value.success == true) {
        // timesData();
        statusOfSingle.value = RxStatus.success();
        //   showToast(value.message);
        print("11111111111111111111111${value.message.toString()}");
        // Output will be in the desired time format, e.g., "10:21 AM"
      } else {
        showToast(value.message);
        print("222222222222222222222222${value.message.toString()}");
        statusOfSingle.value = RxStatus.error();
      }
    });
  }

  int data = 0;
  String? commentIDs;

  String formatTime(String dateTime) {
    DateTime parsedDate = DateTime.parse(dateTime).toLocal();
    DateFormat timeFormat = DateFormat.jm(); // You can use any desired time format here
    return timeFormat.format(parsedDate);
  }

  // dynamic time;

  TextEditingController commentController = TextEditingController();
  Rx<AddCommentModel> comment = AddCommentModel().obs;
  Rx<RxStatus> statusOfcomment = RxStatus.empty().obs;

  Rx<ReplyModel> reply = ReplyModel().obs;
  Rx<RxStatus> statusOfreply = RxStatus.empty().obs;

  @override
  void initState() {
    singlePost();

    super.initState();
  }

  // @override
  // void dispose() {
  //   data=1;
  //   super.dispose();
  // }
  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.sizeOf(context).height;
    var width = MediaQuery.sizeOf(context).width;

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        titleSpacing: 0,
        elevation: 0,
        backgroundColor: const Color(0xff75D051),
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: const Icon(
            Icons.arrow_back_ios,
            color: Colors.white,
          ),
        ),
        title: Text(
          widget.title.toString()
          // "Single Post"
          ,
          style: GoogleFonts.roboto(fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white),
        ),
      ),
      body: RefreshIndicator(
        onRefresh: () async {
          singlePost();
        },
        child: SafeArea(child: Obx(() {
          return statusOfSingle.value.isSuccess
              ?
              // model.value.success == true ?
              Stack(
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(top: 25, right: 5, left: 5, bottom: 80),
                      child: SingleChildScrollView(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment: MainAxisAlignment.start,
                          children: [
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 12),
                              child: Row(
                                children: [
                                  ClipRRect(
                                      borderRadius: BorderRadius.circular(20),
                                      child: Image.network(
                                        "${userimage}",
                                        height: 40,
                                        width: 40,
                                        fit: BoxFit.fill,
                                        loadingBuilder:
                                            (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                          if (loadingProgress == null) {
                                            return child;
                                          } else {
                                            return Center(
                                              child: CircularProgressIndicator(
                                                value: loadingProgress.expectedTotalBytes != null
                                                    ? loadingProgress.cumulativeBytesLoaded /
                                                        (loadingProgress.expectedTotalBytes ?? 1)
                                                    : null,
                                              ),
                                            );
                                          }
                                        },
                                        errorBuilder: (BuildContext context, Object exception, StackTrace? stackTrace) {
                                          return Image.asset(
                                            "assets/icons/addimage.png",
                                            fit: BoxFit.cover,
                                            height: 40,
                                            width: 40,
                                          );
                                        },
                                      )
                                      // CachedNetworkImage(
                                      //   height: 40,
                                      //   width: 40,
                                      //   imageUrl:
                                      //   "http://207.148.68.65/api${profileController.image}",
                                      //   fit: BoxFit.fill,
                                      //   errorWidget:
                                      //       (context, url, error) =>
                                      //       Image.asset(
                                      //         height: 40,
                                      //         width: 40,
                                      //         "assets/icons/addimage.png",
                                      //         fit: BoxFit.cover,
                                      //       ),
                                      // ),
                                      ),
                                  SizedBox(
                                    width: width * 0.04,
                                  ),
                                  Text(
                                    "${widget.name.toString()}",
                                    style: GoogleFonts.roboto(
                                        fontSize: 16, fontWeight: FontWeight.w500, color: Colors.black),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: height * 0.01,
                            ),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 12),
                              child: ClipRRect(
                                  borderRadius: BorderRadius.circular(10),
                                  child: Image.network(
                                    "${widget.postImage}",
                                    height: 200,
                                    width: Get.width,
                                    fit: BoxFit.fill,
                                    loadingBuilder:
                                        (BuildContext context, Widget child, ImageChunkEvent? loadingProgress) {
                                      if (loadingProgress == null) {
                                        return child;
                                      } else {
                                        return Center(
                                          child: CircularProgressIndicator(
                                            value: loadingProgress.expectedTotalBytes != null
                                                ? loadingProgress.cumulativeBytesLoaded /
                                                    (loadingProgress.expectedTotalBytes ?? 1)
                                                : null,
                                          ),
                                        );
                                      }
                                    },
                                    errorBuilder: (BuildContext context, Object exception, StackTrace? stackTrace) {
                                      return Image.asset(
                                        "assets/icons/addimage.png",
                                        fit: BoxFit.cover,
                                        height: 200,
                                        width: Get.width,
                                      );
                                    },
                                  )
                                  // CachedNetworkImage(
                                  //   height: 200,
                                  //   width: Get.width,
                                  //   imageUrl:
                                  //   "http://207.148.68.65/api${widget.postImage}",
                                  //   fit: BoxFit.fill,
                                  //   errorWidget: (context, url, error) =>
                                  //       SizedBox(
                                  //         height: 30,
                                  //         width: 30,
                                  //         child: Image.asset(
                                  //           "assets/icons/addimage.png",
                                  //           fit: BoxFit.cover,
                                  //         ),
                                  //       ),
                                  // ),
                                  ),
                            ),
                            SizedBox(height: height * 0.02),
                            SizedBox(
                              height: height * 0.016,
                            ),
                            single.value.post!.title == null
                                ? SizedBox(
                                    height: 0,
                                    width: 0,
                                  )
                                : Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 12),
                                    child: Text(
                                      single.value.post!.title.toString(),
                                      style: GoogleFonts.roboto(
                                          fontSize: 16, fontWeight: FontWeight.w500, color: Colors.black),
                                      overflow: TextOverflow.ellipsis, //huwcuewgucgcug
                                      maxLines: 1,
                                      softWrap: true,
                                    ),
                                  ),
                            SizedBox(height: height * 0.02), //g3fuyfg3yfg34y
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 12),
                              child: Text(
                                single.value.post!.caption.toString()
                                //"Why did the vegetable go to the doctor? Because it had a bad peeling. "
                                //model.value.post!.name.toString()
                                ,
                                style:
                                    GoogleFonts.roboto(fontSize: 15, fontWeight: FontWeight.w400, color: Colors.black),
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                softWrap: true,
                              ),
                            ),
                            SizedBox(height: height * 0.02),
                            Padding(
                              padding: const EdgeInsets.symmetric(horizontal: 12),
                              child: Text(
                                single.value.post!.message.toString(),
                                //"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,",
                                style: GoogleFonts.roboto(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w400,
                                  color: Colors.black,
                                ),
                                textAlign: TextAlign.start,
                              ),
                            ),

                            SizedBox(
                              height: height * 0.04,
                            ),
                            // Text( single.value.post!.comments!.length.toString()),
                            single.value.post!.comments!.length == 0
                                ? Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 13),
                                    child: Text(
                                      "No Comments",
                                      style: GoogleFonts.roboto(
                                          fontSize: 16, fontWeight: FontWeight.w500, color: Colors.black),
                                    ),
                                  )
                                : Padding(
                                    padding: const EdgeInsets.symmetric(horizontal: 13),
                                    child: Text(
                                      "Comments",
                                      style: GoogleFonts.roboto(
                                          fontSize: 16, fontWeight: FontWeight.w500, color: Colors.black),
                                    ),
                                  ),
                            SizedBox(
                              height: height * 0.02,
                            ),
                            single.value.post!.comments!.length == 0
                                ? SizedBox(
                                    height: 50,
                                    width: width,
                                    child: Text(""),
                                  )
                                : ListView.builder(
                                    shrinkWrap: true,
                                    physics: const NeverScrollableScrollPhysics(),
                                    itemCount: single.value.post!.comments!.length,
                                    itemBuilder: (context, index) {
                                      String formattedTime =
                                          formatTime(single.value.post!.comments![index].createdAt.toString());
                                      DateTime dateTime =
                                          DateTime.parse(single.value.post!.comments![index].createdAt.toString());
                                      String formattedDate = DateFormat('dd MMMM yyyy').format(dateTime);

                                      return Padding(
                                        padding: const EdgeInsets.only(bottom: 16, left: 10),
                                        child: Column(
                                          children: [
                                            Container(
                                              // color: Colors.red,
                                              child: Column(
                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                children: [
                                                  Row(
                                                    children: [
                                                      ClipRRect(
                                                          borderRadius: BorderRadius.circular(50),
                                                          child: Image.network(
                                                            "${single.value.post!.comments![index].profileImageUrl}",
                                                            height: 45,
                                                            width: 45,
                                                            fit: BoxFit.fill,
                                                            loadingBuilder: (BuildContext context, Widget child,
                                                                ImageChunkEvent? loadingProgress) {
                                                              if (loadingProgress == null) {
                                                                return child;
                                                              } else {
                                                                return Center(
                                                                  child: CircularProgressIndicator(
                                                                    value: loadingProgress.expectedTotalBytes != null
                                                                        ? loadingProgress.cumulativeBytesLoaded /
                                                                            (loadingProgress.expectedTotalBytes ?? 1)
                                                                        : null,
                                                                  ),
                                                                );
                                                              }
                                                            },
                                                            errorBuilder: (BuildContext context, Object exception,
                                                                StackTrace? stackTrace) {
                                                              return Image.asset(
                                                                "assets/icons/addimage.png",
                                                                fit: BoxFit.cover,
                                                                height: 45,
                                                                width: 45,
                                                              );
                                                            },
                                                          )
                                                          // Image.asset("assets/images/user.png",height:50,width:50,),
                                                          ),
                                                      SizedBox(width: width * 0.03),
                                                      Text(
                                                        single.value.post!.comments![index].name
                                                            .toString()
                                                            .replaceAll("\"", ""), //"Alex smith",
                                                        style: GoogleFonts.roboto(
                                                          fontSize: 14,
                                                          fontWeight: FontWeight.w500,
                                                          color: Colors.black,
                                                        ),
                                                      ),
                                                      Spacer(),
                                                      PopupMenuButton(
                                                        icon: Icon(Icons.more_vert_rounded),
                                                        onSelected: (value) {},
                                                        itemBuilder: (BuildContext context) {
                                                          return [
                                                            PopupMenuItem<String>(
                                                              child: GestureDetector(
                                                                  onTap: () {
                                                                    print(
                                                                        "object${single.value.post!.comments![index].userId.toString()}");

                                                                    blockUser(
                                                                        id: single.value.post!.comments![index].userId
                                                                            .toString());
                                                                    Get.back();
                                                                  },
                                                                  child: Text('Block')),
                                                            ),
                                                            PopupMenuItem<String>(
                                                              child: GestureDetector(
                                                                  onTap: () async {
                                                                    final Uri emailUri = Uri(
                                                                      scheme: 'mailto',
                                                                      path: 'harrisontang1204@gmail.com',
                                                                      queryParameters: {
                                                                        'subject': 'Report',
                                                                        'body': 'Content:',
                                                                      },
                                                                    );

                                                                    if (await canLaunchUrl(emailUri)) {
                                                                      await launchUrl(emailUri);
                                                                    } else {
                                                                      print('Could not launch email app');
                                                                    }
                                                                  },
                                                                  child: Text('Report')),
                                                            ),
                                                          ];
                                                        },
                                                      )
                                                    ],
                                                  ),
                                                  Row(
                                                    children: [
                                                      Padding(
                                                        padding: const EdgeInsets.only(left: 60),
                                                        child: Text(
                                                          single.value.post!.comments![index].message.toString(),
                                                          //"Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,",
                                                          style: GoogleFonts.roboto(
                                                            fontSize: 10,
                                                            fontWeight: FontWeight.w300,
                                                            color: Color(0xff545454),
                                                          ),
                                                        ),
                                                      ),
                                                      const Spacer(),
                                                      Text(
                                                        '${formattedTime} / ${formattedDate}',
                                                        style: GoogleFonts.roboto(
                                                          fontSize: 12,
                                                          fontWeight: FontWeight.w300,
                                                          color: Colors.black,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                  SizedBox(height: height * 0.01),
                                                  Padding(
                                                    padding: const EdgeInsets.only(left: 60),
                                                    child: Align(
                                                      alignment: Alignment.topLeft,
                                                      child: InkWell(
                                                          onTap: () {
                                                            setState(() {
                                                              data = 1;
                                                              commentIDs =
                                                                  single.value.post!.comments![index].sId.toString();
                                                            });

                                                            print("Data${data}");
                                                          },
                                                          child: Text(
                                                            "Reply",
                                                            style: GoogleFonts.roboto(
                                                                fontSize: 10,
                                                                fontWeight: FontWeight.w400,
                                                                color: Colors.black),
                                                          )),
                                                    ),
                                                  )
                                                ],
                                              ),
                                            ),
                                            single.value.post!.comments![index].replies!.isEmpty
                                                ? const SizedBox(
                                                    height: 0,
                                                    width: 0,
                                                  )
                                                : ListView.builder(
                                                    physics: NeverScrollableScrollPhysics(),
                                                    shrinkWrap: true,
                                                    itemCount: single.value.post!.comments![index].replies!.length,
                                                    //single.value.post!.comments![index].replies!.length,
                                                    itemBuilder: (context, index1) {
                                                      String formattedTime2 = formatTime(
                                                        single.value.post!.comments![index].replies![index1].createdAt
                                                            .toString(),
                                                      );

                                                      DateTime dateTime = DateTime.parse(
                                                        single.value.post!.comments![index].replies![index1].createdAt
                                                            .toString(),
                                                      );
                                                      String formattedDate1 =
                                                          DateFormat('dd MMMM yyyy').format(dateTime);

                                                      return Padding(
                                                        padding: const EdgeInsets.only(left: 30, top: 10),
                                                        child: Container(
                                                          // color: Colors.blue,
                                                          child: Padding(
                                                            padding:
                                                                const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                                                            child: Column(
                                                              crossAxisAlignment: CrossAxisAlignment.start,
                                                              children: [
                                                                Row(
                                                                  children: [
                                                                    ClipRRect(
                                                                        borderRadius: BorderRadius.circular(50),
                                                                        child: Image.network(
                                                                          "${single.value.post!.comments![index].replies![index1].profileImageUrl}",
                                                                          height: 35,
                                                                          width: 35,
                                                                          fit: BoxFit.fill,
                                                                          loadingBuilder: (BuildContext context,
                                                                              Widget child,
                                                                              ImageChunkEvent? loadingProgress) {
                                                                            if (loadingProgress == null) {
                                                                              return child;
                                                                            } else {
                                                                              return Center(
                                                                                child: CircularProgressIndicator(
                                                                                  value: loadingProgress
                                                                                              .expectedTotalBytes !=
                                                                                          null
                                                                                      ? loadingProgress
                                                                                              .cumulativeBytesLoaded /
                                                                                          (loadingProgress
                                                                                                  .expectedTotalBytes ??
                                                                                              1)
                                                                                      : null,
                                                                                ),
                                                                              );
                                                                            }
                                                                          },
                                                                          errorBuilder: (BuildContext context,
                                                                              Object exception,
                                                                              StackTrace? stackTrace) {
                                                                            return Image.asset(
                                                                              "assets/icons/addimage.png",
                                                                              fit: BoxFit.cover,
                                                                              height: 35,
                                                                              width: 35,
                                                                            );
                                                                          },
                                                                        )
                                                                        //Image.asset("assets/images/user.png",height:40,width:40),
                                                                        ),
                                                                    SizedBox(width: width * 0.03),
                                                                    Text(
                                                                      single.value.post!.comments![index]
                                                                          .replies![index1].name
                                                                          .toString()
                                                                          .replaceAll("\"", ""), //"Alex smith",
                                                                      style: GoogleFonts.roboto(
                                                                        fontSize: 14,
                                                                        fontWeight: FontWeight.w500,
                                                                        color: Colors.black,
                                                                      ),
                                                                    ),
                                                                    Spacer(),
                                                                    PopupMenuButton(
                                                                      icon: Icon(Icons.more_vert_rounded),

                                                                      itemBuilder: (BuildContext context) {
                                                                        return [
                                                                          PopupMenuItem<String>(
                                                                            child: GestureDetector(
                                                                                onTap: () {
                                                                                  print(
                                                                                      "object${single.value.post!.comments![index]..replies![index1].userId.toString()}");

                                                                                  blockUser(
                                                                                      id: single.value.post!.comments![index].replies![index1].userId
                                                                                          .toString());
                                                                                  Get.back();
                                                                                },
                                                                                child: Text('Block')),
                                                                          ),
                                                                          PopupMenuItem<String>(
                                                                            child: GestureDetector(
                                                                                onTap: () async {
                                                                                  final Uri emailUri = Uri(
                                                                                    scheme: 'mailto',
                                                                                    path: 'harrisontang1204@gmail.com',
                                                                                    queryParameters: {
                                                                                      'subject': 'Report',
                                                                                      'body': 'Content:',
                                                                                    },
                                                                                  );

                                                                                  if (await canLaunchUrl(emailUri)) {
                                                                                    await launchUrl(emailUri);
                                                                                  } else {
                                                                                    print('Could not launch email app');
                                                                                  }

                                                                                },
                                                                                child: Text('Report')),
                                                                          ),
                                                                        ];
                                                                      },
                                                                    )
                                                                  ],
                                                                ),
                                                                Row(
                                                                  children: [
                                                                    Padding(
                                                                      padding: const EdgeInsets.only(left: 50),
                                                                      child: Text(
                                                                        single.value.post!.comments![index]
                                                                            .replies![index1].message
                                                                            .toString(),
                                                                        style: GoogleFonts.roboto(
                                                                          fontSize: 10,
                                                                          fontWeight: FontWeight.w300,
                                                                          color: Color(0xff545454),
                                                                        ),
                                                                      ),
                                                                    ),
                                                                    const Spacer(),
                                                                    Text(
                                                                      '${formattedTime2} / ${formattedDate1}'
                                                                      // "",
                                                                      ,
                                                                      style: GoogleFonts.roboto(
                                                                        fontSize: 12,
                                                                        fontWeight: FontWeight.w300,
                                                                        color: Colors.black,
                                                                      ),
                                                                    )
                                                                  ],
                                                                ),
                                                              ],
                                                            ),
                                                          ),
                                                        ),
                                                      );
                                                    },
                                                  )
                                          ],
                                        ),
                                      );
                                    },
                                  ),

                            // SizedBox(height: height*0.05,),

                            // SizedBox(height: height*0.05,),
                          ],
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(bottom: 8.0, right: 10, left: 10),
                      child: Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          decoration: BoxDecoration(
                            color: Colors.white,
                            border: Border.all(color: Colors.green, width: 2),
                            borderRadius: BorderRadius.circular(4.0),
                          ),
                          padding: EdgeInsets.symmetric(horizontal: 20.0),
                          child: Row(
                            children: [
                              Expanded(
                                child: SizedBox(
                                  height: 60,
                                  child: Padding(
                                    padding: const EdgeInsets.only(top: 4.0),
                                    child: TextFormField(
                                      controller: commentController,
                                      validator: (value) {
                                        if (value!.isEmpty) {
                                          return "message is required";
                                        }
                                        return null;
                                      },
                                      decoration: InputDecoration(
                                        hintText: data == 0 ? 'Post Comment' : 'Post Reply',
                                        border: InputBorder.none,
                                        hintStyle: GoogleFonts.roboto(fontSize: 19, fontWeight: FontWeight.w400),
                                      ),
                                    ), //trtyryufyuft
                                  ),
                                ),
                              ),
                              // SvgPicture.asset("assets/icons/Emojis.svg"),
                              // SizedBox(width: 15,),

                              data == 0
                                  ? GestureDetector(
                                      onTap: () async {
                                        String message = commentController.text;
                                        String? abusiveCheck = _checkForAbusiveWords(message);
                                        if (abusiveCheck != null) {
                                          // Show an error message (for example, using a SnackBar)
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(content: Text(abusiveCheck)),
                                          );
                                        } else {
                                          print("Comment");
                                          SharedPreferences pref = await SharedPreferences.getInstance();
                                          String userName = pref.getString("name")!;
                                          print("name${single.value.post!.sId.toString()}");
                                          print("id${userName}");
                                          print("message:${commentController.text}");
                                          addComment(
                                                  postId: single.value.post!.sId.toString(),
                                                  // username: userName,
                                                  username: usernaam,
                                                  image: userimage,
                                                  message: commentController.text,
                                                  context: context)
                                              .then((value) {
                                            comment.value = value;

                                            if (value.success == true) {
                                              showToast(value.message);

                                              statusOfcomment.value = RxStatus.success();
                                              singlePost();
                                              commentController.clear();
                                            } else {
                                              // showToast("Message field is required");
                                              showToast(value.message);
                                              statusOfcomment.value = RxStatus.error();
                                            }
                                            //com.value = value;
                                          });
                                        }
                                        // print("iddddddddddddddd${widget.id.toString()}");
                                        //
                                        // commentPOst(
                                        //   name: model2.value.post.comments.,
                                        //     productId:  widget.id.toString(),
                                        //     context: context, message:commentController.text )
                                        //     .then((value) {
                                        //   model2.value = value;
                                        //   if (value.success == true) {
                                        //     showToast(value.message);
                                        //     statusOfcomment.value = RxStatus.success();
                                        //     getData();
                                        //   } else {
                                        //     showToast(value.message);
                                        //     statusOfcomment.value = RxStatus.error();
                                        //   }
                                        // });
                                      },
                                      child: SvgPicture.asset("assets/icons/Send.svg"))
                                  : GestureDetector(
                                      onTap: () async {

                                        String message = commentController.text;
                                        String? abusiveCheck = _checkForAbusiveWords(message);
                                        if (abusiveCheck != null) {
                                          // Show an error message (for example, using a SnackBar)
                                          ScaffoldMessenger.of(context).showSnackBar(
                                            SnackBar(content: Text(abusiveCheck)),
                                          );
                                        }else{
                                          SharedPreferences pref = await SharedPreferences.getInstance();
                                          String userName = pref.getString("name")!.toString();
                                          print("name${single.value.post!.sId.toString()}");
                                          print("id${userName}");
                                          print("message:${commentController.text}");
                                          print("commentid:${commentIDs.toString()}");
                                          replyRepo(
                                              image: userimage,
                                              postId: single.value.post!.sId.toString(),
                                              // username: userName,
                                              username: usernaam,
                                              commentID: commentIDs.toString(),
                                              message: commentController.text,
                                              context: context)
                                              .then((value) {
                                            reply.value = value;
                                            if (value.success == true) {
                                              showToast(value.message);
                                              statusOfreply.value = RxStatus.success();
                                              singlePost();
                                              commentController.clear();
                                              // Get.to(()=>const MyPostScreen());
                                            } else {
                                              showToast(value.message);
                                              statusOfreply.value = RxStatus.error();
                                            }
                                            //com.value = value;
                                          });
                                        }

                                      },
                                      child: SvgPicture.asset("assets/icons/Send.svg"))
                            ],
                          ),
                        ),
                      ),
                    ),
                  ],
                )
              : const Center(child: CircularProgressIndicator());
        })),
      ),
    );
  }

  Future<void> blockUser({required String id}) async {
    var map = <String, String>{};
    map["comment_user_id"] = id;
    // Token from the curl request
    // final String token = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6IjY3MDUzM2U5MmIyOThmNzhmYjJjNWZjYyIsInJvbGUiOiJ1c2VyIiwiZGlzYWJsZWQiOmZhbHNlLCJpYXQiOjE3Mjg5ODQ1NzMsImV4cCI6MTczMTE0NDU3M30.Ty6WvRUZ4eIsMf1SgzLu6DT32zo8PNNXNd2Rb8kz6Uc';

    try {
      // Make the POST request with headers and form data
      // final response = await http.post(
      //   url,
      //
      //   // headers: {
      //   //   'Authorization': 'Bearer $token',
      //   // },
      //   body: {
      //     'comment_user_id': id//'66dbdf1be614f53dd121c0b0',
      //   },
      // );
      http.Response response =
          await http.post(Uri.parse(ApiUrl.blockUser), body: jsonEncode(map), headers: await getAuthHeader());
      if (response.statusCode == 200) {
        // Parse response if needed
        var data = json.decode(response.body);
        final responseData = json.decode(response.body);
        print('User blocked successfully: ${responseData['message']}');

        showToast(responseData['message']);
        print('User blocked successfully: $data');
      } else {
        print('Failed to block user: ${response.statusCode} - ${response.body}');
      }
    } catch (e) {
      print('Error occurred: $e');
    }
  }
}
