import 'dart:developer';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';
import '../../controller/profile_controller.dart';
import '../../model/all_post_community_model.dart';
import '../../model/like_post_model.dart';
import '../../repo/all_post_community_repo.dart';
import '../../repo/like_repo.dart';
import '../../widget/helper.dart';
import 'my_post.dart';
import 'singlepost.dart';

class CommunityScreen extends StatefulWidget {
  const CommunityScreen({super.key});

  @override
  State<CommunityScreen> createState() => _CommunityScreenState();
}

class _CommunityScreenState extends State<CommunityScreen> {
  int _currentPage = 1;
  final int _pageSize = 5;
  bool _hasMore = true;

  bool paginating = false;

  Rx<RxStatus> statusOfpost = RxStatus.empty().obs;
  Rx<ModelAllCommunity> model = ModelAllCommunity().obs;

  Rx<LikePostModel> Likemodel = LikePostModel().obs;

  final ScrollController scrollController = ScrollController();
  String? userName;
  RxInt refes = 0.obs;

  void getData1(int page) async {
    SharedPreferences pref = await SharedPreferences.getInstance();
    userName = pref.getString("name");
    refes.value = DateTime.now().microsecondsSinceEpoch;

    if (userName != null) {
      print(userName);
    } else {
      print("No username found");
    }
    addScrollListener() {
      scrollController.addListener(() {
        if (scrollController.offset >
            (scrollController.position.maxScrollExtent - 10)) {
          getData1(page);
        }
      });
    }

    try {
      final value = await allPostRepo(page, _pageSize);
      if (value.post != null && value.post!.isNotEmpty) {
        if (model.value.post == null) {
          model.value.post = value.post;
        } else {
          model.value.post!.addAll(value.post!.where((newPost) => !model
              .value.post!
              .any((existingPost) => existingPost.sId == newPost.sId)));
        }
        _hasMore = value.post!.length == _pageSize;
        statusOfpost.value = RxStatus.success();
      } else {
        _hasMore = false;
        statusOfpost.value = RxStatus.empty(); // No more data
      }
    } catch (error) {
      statusOfpost.value = RxStatus.error();
      log('Error in getData1(): $error');
    } finally {
      refes.value = DateTime.now().microsecondsSinceEpoch;
    }
  }

  Future<void> _loadMore() async {
    if (_hasMore) {
      setState(() {
        _currentPage++;
      });
      getData1(_currentPage);
    }
  }

  final profileController = Get.put(ProfileController());
  Rx<RxStatus> statusOfmylike = RxStatus.empty().obs;

  @override
  void initState() {
    super.initState();
    getData1(_currentPage);
  }

  void shareProduct(String name, String description, String url) {
    final String text = 'Check out this product: $name\n\n$description\n\n$url';
    Share.share(text);
  }

  // String capitalizeName(String name) {
  //   return name.split(' ').map((word) {
  //     if (word.isEmpty) return word;
  //     return word[0].toUpperCase() + word.substring(1).toLowerCase();
  //   }).join(' ');
  // }

  @override
  Widget build(BuildContext context) {
    var height = MediaQuery.sizeOf(context).height;
    var width = MediaQuery.sizeOf(context).width;

    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: const Color(0xff75D051),
        leading: IconButton(
          onPressed: () {
            Get.back();
          },
          icon: const Icon(
            Icons.arrow_back_ios,
            color: Colors.white,
          ),
        ),
        title: Text(
          "Community",
          style: GoogleFonts.roboto(
              fontSize: 16, fontWeight: FontWeight.w500, color: Colors.white),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.all(24.0),
            child: InkWell(
              onTap: () {
                Get.to(const MyPostScreen());
              },
              child: Container(
                decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(8),
                    color: Colors.white),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  child: Center(
                    child: Text(
                      "My Posts",
                      style: GoogleFonts.roboto(
                          fontSize: 14,
                          fontWeight: FontWeight.w500,
                          color: Colors.black),
                    ),
                  ),
                ),
              ),
            ),
          )
        ],
      ),
      body: SafeArea(
        child: Obx(() {
          if (statusOfpost.value.isSuccess) {
            return NotificationListener<ScrollNotification>(
              onNotification: (ScrollNotification scrollInfo) {
                if (!_hasMore) {
                  return false;
                }
                if (scrollInfo.metrics.pixels ==
                    scrollInfo.metrics.maxScrollExtent) {
                  _loadMore();
                }
                return false;
              },
              child: SingleChildScrollView(
                child: Padding(
                  padding:
                  const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Column(
                    children: [
                      SizedBox(height: height * 0.01),
                      Container(
                        decoration: BoxDecoration(
                            color: const Color(0xffE9F7E3),
                            borderRadius: BorderRadius.circular(2)),
                        child: Padding(
                          padding: const EdgeInsets.symmetric(
                              horizontal: 10, vertical: 16),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  border: Border.all(
                                      color: Color(0xff75D051), width: 3),
                                  borderRadius:
                                  BorderRadius.all(Radius.circular(40)),
                                ),
                                child: ClipRRect(
                                  borderRadius:
                                  BorderRadius.all(Radius.circular(40)),
                                  child: Image.network(
                                    "${profileController.image}",
                                    height: 60,
                                    width: 60,
                                    fit: BoxFit.fill,
                                    loadingBuilder: (BuildContext context,
                                        Widget child,
                                        ImageChunkEvent? loadingProgress) {
                                      if (loadingProgress == null) {
                                        return child;
                                      } else {
                                        return Center(
                                          child: CircularProgressIndicator(
                                            value: loadingProgress
                                                .expectedTotalBytes !=
                                                null
                                                ? loadingProgress
                                                .cumulativeBytesLoaded /
                                                (loadingProgress
                                                    .expectedTotalBytes ??
                                                    1)
                                                : null,
                                          ),
                                        );
                                      }
                                    },
                                    errorBuilder: (BuildContext context,
                                        Object exception,
                                        StackTrace? stackTrace) {
                                      return Image.asset(
                                        "assets/icons/addimage.png",
                                        fit: BoxFit.cover,
                                        height: 60,
                                        width: 60,
                                      );
                                    },
                                  ),
                                ),
                              ),
                              SizedBox(width: width * 0.04),
                              SizedBox(
                                width: Get.width * 0.57,
                                child: Text(
                                  // "Welcome ${userName ?? "User"}!",
                                  "Welcome ${usernaam ?? "User"}!",
                                  style: GoogleFonts.roboto(
                                      fontSize: 20,
                                      fontWeight: FontWeight.w500,
                                      color: Colors.black),
                                  softWrap: true,
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      SizedBox(height: height * 0.036),
                      ListView.builder(
                        physics: NeverScrollableScrollPhysics(),
                        // physics: BouncingScrollPhysics(),
                        shrinkWrap: true,
                        itemCount:
                        model.value.post?.length ?? 0 + (_hasMore ? 1 : 0),
                        itemBuilder: (context, index) {
                          if (index >= (model.value.post?.length ?? 0)) {
                            return Center(
                              child: CircularProgressIndicator(),
                            );
                          }

                          final post = model.value.post![index];
                          DateTime dateTime =
                          DateTime.parse(post.createdAt.toString());
                          String formattedDate =
                          DateFormat('yyyy dd MMMM').format(dateTime);

                          return Padding(
                            padding: const EdgeInsets.only(bottom: 26),
                            child: InkWell(
                              onTap: () {
                                Get.to(SinglePostScreen(
                                  id: post.sId.toString(),
                                  name: post.name.toString(),
                                  image: post.profileImageUrl.toString(),
                                  postImage: post.postimage.toString(),
                                  title: post.title.toString(),
                                ));
                              },
                              child: Container(
                                decoration: BoxDecoration(
                                    borderRadius: BorderRadius.circular(8),
                                    color: Colors.white),
                                child: Padding(
                                  padding: const EdgeInsets.symmetric(
                                      horizontal: 16, vertical: 20),
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        children: [
                                          ClipRRect(
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(20)),
                                            child: Image.network(
                                              "${post.profileImageUrl}",
                                              height: 40,
                                              width: 40,
                                              fit: BoxFit.fill,
                                              loadingBuilder:
                                                  (BuildContext context,
                                                  Widget child,
                                                  ImageChunkEvent?
                                                  loadingProgress) {
                                                if (loadingProgress == null) {
                                                  return child;
                                                } else {
                                                  return Center(
                                                    child:
                                                    CircularProgressIndicator(
                                                      value: loadingProgress
                                                          .expectedTotalBytes !=
                                                          null
                                                          ? loadingProgress
                                                          .cumulativeBytesLoaded /
                                                          (loadingProgress
                                                              .expectedTotalBytes ??
                                                              1)
                                                          : null,
                                                    ),
                                                  );
                                                }
                                              },
                                              errorBuilder:
                                                  (BuildContext context,
                                                  Object exception,
                                                  StackTrace? stackTrace) {
                                                return Image.asset(
                                                  "assets/icons/addimage.png",
                                                  fit: BoxFit.cover,
                                                  height: 40,
                                                  width: 40,
                                                );
                                              },
                                            ),
                                          ),
                                          SizedBox(width: width * 0.05),
                                          Expanded(
                                            child: Text(
                                              post.name ?? "Admin",
                                              style: GoogleFonts.roboto(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w500,
                                                color: Colors.black,
                                              ),
                                              maxLines: 1,
                                              softWrap: true,
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          Obx(()=>  IconButton(
                                              onPressed: () {
                                                addToLike(productId: model.value.post![index].sId.toString())
                                                    .then((value) {
                                                  Likemodel.value = value;
                                                  if (value.success ==
                                                      true) {
                                                    model.value.post![index].liked!.value = !model.value.post![index].liked!.value;
                                                    statusOfmylike.value = RxStatus.success();

                                                    getData1(1);
                                                  } else {
                                                    showToast(value.message);
                                                    statusOfmylike.value = RxStatus.error();
                                                  }
                                                });

                                              },
                                              icon: model.value.post![index]
                                                  .liked!.value ==
                                                  false
                                                  ? Image.asset(
                                                "assets/icons/dislike.png",
                                                height: 22,
                                                width: 22,
                                                color:  Color(0xffEF535E),
                                              )
                                                  : Image.asset(
                                                "assets/icons/like.png",
                                                height: 22,
                                                width: 22,
                                              )

                                          ))
                                        ],
                                      ),
                                      SizedBox(height: height * 0.016),
                                      ClipRRect(
                                        borderRadius: BorderRadius.circular(10),
                                        child: Image.network(
                                          "${post.postimage}",
                                          height: 160,
                                          width: width,
                                          fit: BoxFit.fill,
                                          loadingBuilder: (BuildContext context,
                                              Widget child,
                                              ImageChunkEvent?
                                              loadingProgress) {
                                            if (loadingProgress == null) {
                                              return child;
                                            } else {
                                              return Center(
                                                child:
                                                CircularProgressIndicator(
                                                  value: loadingProgress
                                                      .expectedTotalBytes !=
                                                      null
                                                      ? loadingProgress
                                                      .cumulativeBytesLoaded /
                                                      (loadingProgress
                                                          .expectedTotalBytes ??
                                                          1)
                                                      : null,
                                                ),
                                              );
                                            }
                                          },
                                          errorBuilder: (BuildContext context,
                                              Object exception,
                                              StackTrace? stackTrace) {
                                            return Image.asset(
                                              "assets/icons/addimage.png",
                                              fit: BoxFit.fill,
                                            );
                                          },
                                        ),
                                      ),
                                      SizedBox(height: height * 0.016),
                                      if (post.title != null)
                                        Text(
                                          post.title.toString(),
                                          style: GoogleFonts.roboto(
                                              fontSize: 16,
                                              fontWeight: FontWeight.w500,
                                              color: Colors.black),
                                          overflow: TextOverflow.ellipsis,
                                          maxLines: 1,
                                          softWrap: true,
                                        ),
                                      SizedBox(height: height * 0.016),
                                      Text(
                                        post.caption ?? "",
                                        style: GoogleFonts.roboto(
                                            fontSize: 15,
                                            fontWeight: FontWeight.w400,
                                            color: Colors.black),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 1,
                                        softWrap: true,
                                      ),
                                      SizedBox(height: height * 0.016),
                                      Text(
                                        post.message.toString(),
                                        style: GoogleFonts.roboto(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w400,
                                            color: Colors.black),
                                        overflow: TextOverflow.ellipsis,
                                        maxLines: 2,
                                        softWrap: true,
                                      ),
                                      Row(
                                        children: [
                                          Text(
                                            formattedDate,
                                            style: GoogleFonts.outfit(
                                                fontSize: 16,
                                                fontWeight: FontWeight.w400,
                                                color: const Color(0xff273B4A)),
                                          ),
                                          Spacer(),
                                          IconButton(
                                            onPressed: () {
                                              Get.to(SinglePostScreen(
                                                id: post.sId.toString(),
                                                name: post.name.toString(),
                                                image: post.profileImageUrl
                                                    .toString(),
                                                postImage:
                                                post.postimage.toString(),
                                                title: post.title.toString(),
                                              ));
                                            },
                                            // onPressed: () {
                                            //   Get.to(SinglePostScreen(
                                            //     id: post.sId.toString(),
                                            //   ));
                                            // },
                                            icon: Image.asset(
                                              "assets/icons/comment.png",
                                              height: 22,
                                              width: 22,
                                              color: Colors.black,
                                            ),
                                          ),
                                          IconButton(
                                            onPressed: () async {
                                              await Share.share(
                                                  'https://foodhi.org/',
                                                  subject: 'Check this out!');
                                            },
                                            icon: Image.asset(
                                              "assets/icons/share.png",
                                              height: 22,
                                              width: 22,
                                              color: Colors.black,
                                            ),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              ),
            );
          } else if (statusOfpost.value.isError) {
            return Center(child: Text('No posts found'));
          } else {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        }),
      ),
    );
  }
}
