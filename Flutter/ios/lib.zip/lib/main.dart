// import 'package:Safeplate/routers/routers.dart';
// import 'package:firebase_core/firebase_core.dart';
// import 'package:flutter/material.dart';
// import 'package:flutter/services.dart';
// import 'package:get/get.dart';
// import 'package:overlay_support/overlay_support.dart';
// import 'package:pushy_flutter/pushy_flutter.dart';
//
// import 'noti.dart';  // Assuming this contains your notification methods
//
// String? pushyToken;
//
// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//
//   // Initialize Firebase
//   await Firebase.initializeApp();
//
//   // Set up Pushy
//   Pushy.setAppId('66b1fc0ca9865505291e5381');
//
//   // Register Pushy for push notifications and handle errors
//   try {
//     pushyToken = await Pushy.register();
//     print('Device token =>>: $pushyToken');
//   } catch (error) {
//     print('Pushy registration error =>>: $error');
//   }
//
//   // Start listening for push notifications
//   Pushy.listen();
//
//   // Set Pushy notification listener
//   Pushy.setNotificationClickListener((Map<String, dynamic> data) {
//     print('Notification received: $data');
//
//     // Show a local notification using OverlaySupport
//     showNotification('New Notification', data['message'] ?? 'Hello World!');
//
//     // Show dialog with push notification data
//     WidgetsBinding.instance.addPostFrameCallback((_) {
//       Get.dialog(
//         AlertDialog(
//           title: Text('Pushy Notification'),
//           content: Text(data['message'] ?? 'Hello World Ankur Chauhan !'),
//           actions: <Widget>[
//             TextButton(
//               onPressed: () {
//                 Get.back(); // Close the dialog
//               },
//               child: Text('OK'),
//             ),
//           ],
//         ),
//       );
//     });
//   });
//
//   runApp(MyApp());
// }
//
// class MyApp extends StatelessWidget {
//   const MyApp({super.key});
//
//   @override
//   Widget build(BuildContext context) {
//     // Lock the orientation to portrait mode
//     SystemChrome.setPreferredOrientations([
//       DeviceOrientation.portraitUp,
//       DeviceOrientation.portraitDown,
//     ]);
//
//     return OverlaySupport.global(
//       child: GetMaterialApp(
//         title: 'Safeplate Application',
//         theme: ThemeData(
//           fontFamily: 'Roboto',
//           primarySwatch: Colors.green,
//           useMaterial3: false,
//         ),
//         themeMode: ThemeMode.light,
//         debugShowCheckedModeBanner: false,
//         initialRoute: "/",
//         getPages: MyRouter.route,
//       ),
//     );
//   }
// }
//
//


import 'package:Safeplate/routers/routers.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:overlay_support/overlay_support.dart';
String? pushyToken;

Future<void> main() async {

  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  // Pushy.setAppId('66b1fc0ca9865505291e5381');
 print('Device token =>>: $pushyToken');  //token


  runApp(MyApp());
}


class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    SystemChrome.setPreferredOrientations([
      DeviceOrientation.portraitUp,
      DeviceOrientation.portraitDown,
    ]);

    return OverlaySupport.global(
      child: GetMaterialApp(
        color: Colors.white,
        title: 'Safeplate Application',
        theme: ThemeData(
          fontFamily: 'Roboto',
          primarySwatch: Colors.green,
          useMaterial3: false,
        ),
        themeMode: ThemeMode.light,
        debugShowCheckedModeBanner: false,
        initialRoute: "/",
        getPages: MyRouter.route,
        transitionDuration: const Duration(milliseconds: 500),
        builder: (context, widget) => MediaQuery(
          data: MediaQuery.of(context).copyWith(textScaleFactor: 1),
          child: Material(
            child: Stack(children: [
              widget!,
            ]),
          ),
        ),
      ),
    );
  }
}
